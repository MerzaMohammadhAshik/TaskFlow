/* ═══════════════════════════════════════
            UserResponseDTO.java (UPDATED)
═══════════════════════════════════════ */
package main.dto;

import java.time.LocalDateTime;
import main.entity.Role;

public class UserResponseDTO {

    private Long id;
    private String fullname;
    private String email;
    private Role role;
    private LocalDateTime createdAt;


    private boolean isActive;

    // ── Constructors ─────────────────────────

    public UserResponseDTO() {}

    // Basic constructor
    public UserResponseDTO(Long id, String fullname, String email, Role role, LocalDateTime createdAt) {
        this.id = id;
        this.fullname = fullname;
        this.email = email;
        this.role = role;
        this.createdAt = createdAt;
    }

    // With isActive
    public UserResponseDTO(Long id, String fullname, String email, Role role, LocalDateTime createdAt, boolean isActive) {
        this(id, fullname, email, role, createdAt);
        this.isActive = isActive;
    }



    // ── Getters & Setters ───────────────────

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

}