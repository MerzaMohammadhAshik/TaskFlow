/* ═══════════════════════════════════════
            AttachmentListDTO.java
═══════════════════════════════════════ */

package main.dto;

import java.time.LocalDateTime;

public class AttachmentListDTO {

    private Long id;
    private Long taskId;
    private Long uploaderId;
    private String originalName;
    private String mimeType;
    private Long fileSizeBytes;
    private LocalDateTime uploadedAt;

    public AttachmentListDTO(Long id, Long taskId, Long uploaderId,
                             String originalName, String mimeType,
                             Long fileSizeBytes, LocalDateTime uploadedAt) {
        this.id = id;
        this.taskId = taskId;
        this.uploaderId = uploaderId;
        this.originalName = originalName;
        this.mimeType = mimeType;
        this.fileSizeBytes = fileSizeBytes;
        this.uploadedAt = uploadedAt;
    }

    public Long getId() { return id; }
    public Long getTaskId() { return taskId; }
    public Long getUploaderId() { return uploaderId; }
    public String getOriginalName() { return originalName; }
    public String getMimeType() { return mimeType; }
    public Long getFileSizeBytes() { return fileSizeBytes; }
    public LocalDateTime getUploadedAt() { return uploadedAt; }
}