/* ═══════════════════════════════════════
                SubtaskSummaryDTO.java
   ═══════════════════════════════════════ */

package main.dto;

public class SubtaskSummaryDTO {

    /* ═══════════════════════════════════════
                    Fields
    ═══════════════════════════════════════ */

    private int total;
    private int completed;

    /* ═══════════════════════════════════════
                Constructors
    ═══════════════════════════════════════ */

    public SubtaskSummaryDTO() {}

    public SubtaskSummaryDTO(int total, int completed) {
        this.total = total;
        this.completed = completed;
    }

    /* ═══════════════════════════════════════
                Getters & Setters
    ═══════════════════════════════════════ */

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public int getCompleted() {
        return completed;
    }

    public void setCompleted(int completed) {
        this.completed = completed;
    }
}