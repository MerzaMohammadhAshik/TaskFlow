/* ═══════════════════════════════════════
            UserIdNameResponseDTO.java
═══════════════════════════════════════ */
// UserDTO.java
package main.dto;

public class UserIdNameResponseDTO {
	
	private Long id;
    private String fullname;
    
    
    
    
    public UserIdNameResponseDTO(Long id, String fullname) {
		super();
		this.id = id;
		this.fullname = fullname;
	}
	public String getFullname() { return fullname; }
    public void setFullname(String fullname) { this.fullname = fullname; }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
}