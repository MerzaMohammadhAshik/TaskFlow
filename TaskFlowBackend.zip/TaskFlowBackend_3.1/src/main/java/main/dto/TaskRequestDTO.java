/* ═══════════════════════════════════════
            TaskRequestDTO.java
═══════════════════════════════════════ */
package main.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import main.entity.TaskPriority;
import main.entity.TaskStatus;

import java.time.LocalDate;

public class TaskRequestDTO {

    @NotBlank(message = "Title is required")
    private String title;

    private String description;

    @NotNull(message = "Due date is required")
    private LocalDate dueDate;

    private TaskStatus status = TaskStatus.TODO;

    // Assigned user ID (nullable)
    private Long assignedToId;

    // Priority (default MEDIUM)
    private TaskPriority priority;

    // ── Getters & Setters ───────────────────────────────
    public String getTitle() { return title; }
    public void setTitle(String t) { this.title = t; }

    public String getDescription() { return description; }
    public void setDescription(String d) { this.description = d; }

    public LocalDate getDueDate() { return dueDate; }
    public void setDueDate(LocalDate d) { this.dueDate = d; }

    public TaskStatus getStatus() { return status; }
    public void setStatus(TaskStatus s) { this.status = s; }

    public Long getAssignedToId() { return assignedToId; }
    public void setAssignedToId(Long assignedToId) { this.assignedToId = assignedToId; }

    public TaskPriority getPriority() { return priority; }
    public void setPriority(TaskPriority priority) { this.priority = priority; }
	
    
    @Override
	public String toString() {
		return "TaskRequestDTO [title=" + title + ", description=" + description + ", dueDate=" + dueDate + ", status="
				+ status + ", assignedToId=" + assignedToId + ", priority=" + priority + "]";
	}
    
    
    
}