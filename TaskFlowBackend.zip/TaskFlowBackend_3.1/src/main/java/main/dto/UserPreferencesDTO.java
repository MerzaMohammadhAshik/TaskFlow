/* ═══════════════════════════════════════
        UserPreferencesDTO.java
═══════════════════════════════════════ */
package main.dto;

import main.entity.UserPreferencesEntity.Theme;

public class UserPreferencesDTO {

    private Theme theme;
    private boolean notifyAssigned;
    private boolean notifyComment;
    private boolean notifySubtask;
    private boolean notifyOverdue;
    private boolean notifyTeam;
    private String avatarColour;
    private String bio;

    public UserPreferencesDTO() {}

    // Getters & Setters
    public Theme getTheme() { return theme; }
    public void setTheme(Theme theme) { this.theme = theme; }

    public boolean isNotifyAssigned() { return notifyAssigned; }
    public void setNotifyAssigned(boolean notifyAssigned) { this.notifyAssigned = notifyAssigned; }

    public boolean isNotifyComment() { return notifyComment; }
    public void setNotifyComment(boolean notifyComment) { this.notifyComment = notifyComment; }

    public boolean isNotifySubtask() { return notifySubtask; }
    public void setNotifySubtask(boolean notifySubtask) { this.notifySubtask = notifySubtask; }

    public boolean isNotifyOverdue() { return notifyOverdue; }
    public void setNotifyOverdue(boolean notifyOverdue) { this.notifyOverdue = notifyOverdue; }

    public boolean isNotifyTeam() { return notifyTeam; }
    public void setNotifyTeam(boolean notifyTeam) { this.notifyTeam = notifyTeam; }

    public String getAvatarColour() { return avatarColour; }
    public void setAvatarColour(String avatarColour) { this.avatarColour = avatarColour; }

    public String getBio() { return bio; }
    public void setBio(String bio) { this.bio = bio; }
}