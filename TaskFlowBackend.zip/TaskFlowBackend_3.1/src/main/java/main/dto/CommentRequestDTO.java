/* ═══════════════════════════════════════
            CommentRequestDTO.java
═══════════════════════════════════════ */
package main.dto;



import java.time.LocalDateTime;

public class CommentRequestDTO {

 private Long id;
 private String body;
 private String authorName;
 private Long authorId;
 private LocalDateTime created;

 public CommentRequestDTO(Long id, String body, String authorName,Long authorId, LocalDateTime created) {
     this.id = id;
     this.body = body;
     this.authorName = authorName;
     this.authorId = authorId;
     this.created = created;
 }

 public Long getId() { return id; }
 public String getBody() { return body; }
 public String getAuthorName() { return authorName; }
 public Long getAuthorId() { return authorId; }
 public LocalDateTime getCreated() { return created; }
}