/* ═══════════════════════════════════════
            TeamResponseDto.java
════════════════════════════════════════ */
package main.dto;

import java.time.LocalDateTime;
import java.util.List;

public class TeamResponseDto {

    private Long id;
    private String name;
    private String description;
    private UserResponseDTO manager;
    private LocalDateTime createdAt;
    private List<UserResponseDTO> members;
    private List<Long> taskIds;

    // Constructors
    public TeamResponseDto() {}

    public TeamResponseDto(Long id, String name, String description,
    		UserResponseDTO manager, LocalDateTime createdAt,
                           List<UserResponseDTO> members, List<Long> taskIds) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.manager = manager;
        this.createdAt = createdAt;
        this.members = members;
        this.taskIds = taskIds;
    }

    // Getters & Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public UserResponseDTO getManager() { return manager; }
    public void setManager(UserResponseDTO manager) { this.manager = manager; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public List<UserResponseDTO> getMembers() { return members; }
    public void setMembers(List<UserResponseDTO> members) { this.members = members; }

    public List<Long> getTaskIds() { return taskIds; }
    public void setTaskIds(List<Long> taskIds) { this.taskIds = taskIds; }
}




//public UserResponseDTO mapToDTO(UserEntity user){
//
//    return new UserResponseDTO(
//        user.getId(),
//        user.getFullname(),
//        user.getEmail(),
//        user.getRole(),
//        user.getCreatedAt()
//    );
//
//}