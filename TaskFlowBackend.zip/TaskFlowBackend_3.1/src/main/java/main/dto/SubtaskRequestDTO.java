/* ═══════════════════════════════════════
                SubtaskRequestDTO.java
   ═══════════════════════════════════════ */

package main.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class SubtaskRequestDTO {

    /* ═══════════════════════════════════════
                    Fields
    ═══════════════════════════════════════ */

    @NotBlank(message = "Title is required")
    @Size(min = 1, max = 300, message = "Title must be between 1 and 300 characters")
    private String title;

    // Optional
    private Long assignedTo;

    /* ═══════════════════════════════════════
                Constructors
    ═══════════════════════════════════════ */

    public SubtaskRequestDTO() {}

    public SubtaskRequestDTO(String title, Long assignedTo) {
        this.title = title;
        this.assignedTo = assignedTo;
    }

    /* ═══════════════════════════════════════
                Getters & Setters
    ═══════════════════════════════════════ */

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Long getAssignedTo() {
        return assignedTo;
    }

    public void setAssignedTo(Long assignedTo) {
        this.assignedTo = assignedTo;
    }
}