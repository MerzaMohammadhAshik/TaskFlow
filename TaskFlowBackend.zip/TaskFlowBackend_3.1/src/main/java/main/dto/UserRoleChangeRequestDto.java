/* ═══════════════════════════════════════
        UserRoleChangeRequestDto.java
════════════════════════════════════════ */
package main.dto;

import jakarta.validation.constraints.NotNull;
import main.entity.Role;

public class UserRoleChangeRequestDto {

    @NotNull
    private Long userId;

    @NotNull
    private Role newRole;

    // Constructors
    public UserRoleChangeRequestDto() {}

    public UserRoleChangeRequestDto(Long userId, Role newRole) {
        this.userId = userId;
        this.newRole = newRole;
    }

    // Getters & Setters
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public Role getNewRole() { return newRole; }
    public void setNewRole(Role newRole) { this.newRole = newRole; }
}