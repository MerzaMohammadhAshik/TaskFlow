/* ═══════════════════════════════════════
                SubtaskResponseDTO.java
   ═══════════════════════════════════════ */

package main.dto;

import java.time.LocalDateTime;

public class SubtaskResponseDTO {

    /* ═══════════════════════════════════════
                    Fields
    ═══════════════════════════════════════ */

    private Long id;
    private Long taskId;
    private String title;
    private boolean isComplete;
    private Long assignedTo;
    private String assignedToName;
    private Long createdBy;
    private LocalDateTime createdAt;
    private LocalDateTime completedAt;

    /* ═══════════════════════════════════════
                Constructors 
    ═══════════════════════════════════════ */

    public SubtaskResponseDTO() {}

    public SubtaskResponseDTO(Long id, Long taskId, String title,
                              boolean isComplete, Long assignedTo,String assignedToName, 
                              Long createdBy, LocalDateTime createdAt,
                              LocalDateTime completedAt) {
        this.id = id;
        this.taskId = taskId;
        this.title = title;
        this.isComplete = isComplete;
        this.assignedTo = assignedTo;
        this.assignedToName=assignedToName;
        this.createdBy = createdBy;
        this.createdAt = createdAt;
        this.completedAt = completedAt;
    }

    /* ═══════════════════════════════════════
                Getters & Setters
    ═══════════════════════════════════════ */

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getTaskId() {
        return taskId;
    }

    public void setTaskId(Long taskId) {
        this.taskId = taskId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public boolean isComplete() {
        return isComplete;
    }

    public void setComplete(boolean complete) {
        isComplete = complete;
    }

    public Long getAssignedTo() {
        return assignedTo;
    }

    public void setAssignedTo(Long assignedTo) {
        this.assignedTo = assignedTo;
    }

    public String getAssignedToName() {
		return assignedToName;
	}

	public void setAssignedToName(String assignedToName) {
		this.assignedToName = assignedToName;
	}

	public Long getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Long createdBy) {
        this.createdBy = createdBy;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getCompletedAt() {
        return completedAt;
    }

    public void setCompletedAt(LocalDateTime completedAt) {
        this.completedAt = completedAt;
    }
}