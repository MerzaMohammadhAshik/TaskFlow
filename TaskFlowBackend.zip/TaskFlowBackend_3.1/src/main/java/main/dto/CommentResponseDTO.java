/* ═══════════════════════════════════════
            CommentResponseDTO.java
═══════════════════════════════════════ */
// TaskDTO.java
package main.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;


public class CommentResponseDTO {

//    private Long taskId;
    
//    @NotBlank(message = "AutherId is required")  //  find from jwt token
//    private String autherId;
    
    @NotNull(message = "Body is required")
    private String body;

//	public Long getTaskId() {
//		return taskId;
//	}
//
//	public void setTaskId(Long taskId) {
//		this.taskId = taskId;
//	}

//	public String getAutherId() {
//		return autherId;
//	}
//
//	public void setAutherId(String autherId) {
//		this.autherId = autherId;
//	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}


}