/* ═══════════════════════════════════════
        ProfileUpdateRequestDto.java
═══════════════════════════════════════ */
package main.dto;

import jakarta.validation.constraints.*;

//import lombok.Data;

//@Data
public class ProfileUpdateRequestDto {

    @NotBlank
    private String fullname;

    @NotBlank
    @Email
    private String email;

    private String avatarColour;

    @Size(max = 200)
    private String bio;

    // required only when email changes
    private String password;

	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAvatarColour() {
		return avatarColour;
	}

	public void setAvatarColour(String avatarColour) {
		this.avatarColour = avatarColour;
	}

	public String getBio() {
		return bio;
	}

	public void setBio(String bio) {
		this.bio = bio;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
    
    
    
    
    
    
}