/* ═══════════════════════════════════════
            TeamRequestDTO.java
════════════════════════════════════════ */
package main.dto;

import java.util.List;

public class TeamRequestDTO {

    private String name;
    private String description;
    private Long managerId;
    private List<Long> memberIds;
    private List<Long> taskIds;

    // Constructors
    public TeamRequestDTO() {}

    public TeamRequestDTO(String name, String description,
                          Long managerId, List<Long> memberIds,
                          List<Long> taskIds) {
        this.name = name;
        this.description = description;
        this.managerId = managerId;
        this.memberIds = memberIds;
        this.taskIds = taskIds;
    }

    // Getters & Setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public Long getManagerId() { return managerId; }
    public void setManagerId(Long managerId) { this.managerId = managerId; }

    public List<Long> getMemberIds() { return memberIds; }
    public void setMemberIds(List<Long> memberIds) { this.memberIds = memberIds; }

    public List<Long> getTaskIds() { return taskIds; }
    public void setTaskIds(List<Long> taskIds) { this.taskIds = taskIds; }
}