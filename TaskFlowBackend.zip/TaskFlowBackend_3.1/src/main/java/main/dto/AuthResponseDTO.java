/* ═══════════════════════════════════════
            AuthResponseDTO.java (UPDATED)
═══════════════════════════════════════ */
package main.dto;

import main.entity.Role;

public class AuthResponseDTO {

    private String token;
    private String message;
    private String email;
    private String fullname;
    private Long id;
    private Role role;

    private String avatarColour;
    private String bio;

    // ── Constructors ──────────────────────

    // Minimal constructor
    public AuthResponseDTO(String token, String message, String email, String fullname, Long id, Role role) {
        this.token    = token;
        this.message  = message;
        this.email    = email;
        this.fullname = fullname;
        this.id       = id;
        this.role     = role;
    }

    // Full constructor with profile fields
    public AuthResponseDTO(String token, String message, String email, String fullname, Long id,
                           Role role, String avatarColour, String bio) {
        this(token, message, email, fullname, id, role);
        this.avatarColour = avatarColour;
        this.bio = bio;
    }

    // ── Getters & Setters ─────────────────

    public String getToken() { return token; }
    public void setToken(String token) { this.token = token; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getFullname() { return fullname; }
    public void setFullname(String fullname) { this.fullname = fullname; }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Role getRole() { return role; }
    public void setRole(Role role) { this.role = role; }

    public String getAvatarColour() { return avatarColour; }
    public void setAvatarColour(String avatarColour) { this.avatarColour = avatarColour; }

    public String getBio() { return bio; }
    public void setBio(String bio) { this.bio = bio; }
}