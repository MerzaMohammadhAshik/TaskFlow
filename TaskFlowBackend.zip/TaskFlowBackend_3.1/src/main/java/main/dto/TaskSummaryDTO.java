/* ═══════════════════════════════════════
            TaskSummaryDTO.java
═══════════════════════════════════════ */
package main.dto;

public class TaskSummaryDTO {

    private int totalTasks;
    private StatusSummary byStatus;
    private PrioritySummary byPriority;
    private double completionRate;
    private int overdueCount;
    private int tasksThisWeek;

    public TaskSummaryDTO() {}

    public TaskSummaryDTO(int totalTasks, StatusSummary byStatus, PrioritySummary byPriority) {
        this.totalTasks = totalTasks;
        this.byStatus = byStatus;
        this.byPriority = byPriority;
    }

    // ===== One-line Getters & Setters =====

    public int getTotalTasks() { return totalTasks; }
    public void setTotalTasks(int totalTasks) { this.totalTasks = totalTasks; }

    public StatusSummary getByStatus() { return byStatus; }
    public void setByStatus(StatusSummary byStatus) { this.byStatus = byStatus; }

    public PrioritySummary getByPriority() { return byPriority; }
    public void setByPriority(PrioritySummary byPriority) { this.byPriority = byPriority; }

    public double getCompletionRate() { return completionRate; }
    public void setCompletionRate(double completionRate) { this.completionRate = completionRate; }

    public int getOverdueCount() { return overdueCount; }
    public void setOverdueCount(int overdueCount) { this.overdueCount = overdueCount; }

    public int getTasksThisWeek() { return tasksThisWeek; }
    public void setTasksThisWeek(int tasksThisWeek) { this.tasksThisWeek = tasksThisWeek; }
    
    // ================= INNER CLASSES =================

    public static class StatusSummary {

        private int todo;
        private int inProgress;
        private int done;

        public StatusSummary() {}

        public StatusSummary(int todo, int inProgress, int done) {
            this.todo = todo;
            this.inProgress = inProgress;
            this.done = done;
        }

        public int getTodo() { return todo; }
        public void setTodo(int todo) { this.todo = todo; }

        public int getInProgress() { return inProgress; }
        public void setInProgress(int inProgress) { this.inProgress = inProgress; }

        public int getDone() { return done; }
        public void setDone(int done) { this.done = done; }
    }

    public static class PrioritySummary {

        private int high;
        private int medium;
        private int low;

        public PrioritySummary() {}

        public PrioritySummary(int high, int medium, int low) {
            this.high = high;
            this.medium = medium;
            this.low = low;
        }

        public int getHigh() { return high; }
        public void setHigh(int high) { this.high = high; }

        public int getMedium() { return medium; }
        public void setMedium(int medium) { this.medium = medium; }

        public int getLow() { return low; }
        public void setLow(int low) { this.low = low; }
    }
}