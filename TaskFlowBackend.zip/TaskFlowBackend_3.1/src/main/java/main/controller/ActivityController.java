/* ═══════════════════════════════════════
            ActivityController.java
═══════════════════════════════════════ */
package main.controller;

import main.entity.ActivityLogEntity;
import main.service.ActivityLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/activity")
public class ActivityController {

    @Autowired
    private ActivityLogService activityLogService;

    @GetMapping
    public List<ActivityLogEntity> getActivity(Authentication auth) {
        return activityLogService.getRecentActivity(auth.getName());
    }
}