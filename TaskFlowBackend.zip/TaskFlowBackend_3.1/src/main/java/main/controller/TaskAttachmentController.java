/* ═══════════════════════════════════════
            TaskAttachmentController.java
═══════════════════════════════════════ */

package main.controller;

import main.service.TaskAttachmentService;
import main.dto.AttachmentListDTO;
import main.entity.TaskAttachmentEntity;

import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.net.Authenticator;
import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api")
public class TaskAttachmentController {

	private final TaskAttachmentService service;

	public TaskAttachmentController(TaskAttachmentService service) {
		this.service = service;
	}

	@PostMapping("/tasks/{taskId}/attachments")
	public ResponseEntity<?> upload(@PathVariable Long taskId, @RequestParam("file") MultipartFile file,
			Authentication auth) throws Exception {

//        Long uploaderId = 1L; // normally from JWT user

		try {
			service.upload(taskId, auth.getName(), file);

//            return ResponseEntity.ok("File uploaded");
			return ResponseEntity.status(200).body(Map.of("message", "File uploaded"));
		} catch (Exception e) {
			return ResponseEntity.status(403).body(Map.of("message", e.getMessage()));
		}

	}

	@GetMapping("/tasks/{taskId}/attachments")
	public List<AttachmentListDTO> list(@PathVariable Long taskId) {
		return service.listByTask(taskId);
	}

	@GetMapping("/attachments/{id}/download")
	public ResponseEntity<byte[]> download(@PathVariable Long id) {

		TaskAttachmentEntity file = service.getAttachment(id);

		return ResponseEntity.ok()
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getOriginalName() + "\"")
				.header(HttpHeaders.CONTENT_TYPE, file.getMimeType()).body(file.getFileData());
	}

	@DeleteMapping("/attachments/{id}")
	public ResponseEntity<String> delete(@PathVariable Long id) {

		service.delete(id);

		return ResponseEntity.ok("Attachment deleted");
	}
}