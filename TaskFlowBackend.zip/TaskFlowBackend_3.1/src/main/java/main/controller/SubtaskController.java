/* ═══════════════════════════════════════
                SubtaskController.java
   ═══════════════════════════════════════ */

package main.controller;

import jakarta.validation.Valid;
import main.dto.SubtaskResponseDTO;
import main.dto.*;
import main.service.SubtaskService;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api")
public class SubtaskController {

    private final SubtaskService service;

    public SubtaskController(SubtaskService service) {
        this.service = service;
    }

    /* ═══════════════════════════════════════
                    GET
    ═══════════════════════════════════════ */
    @GetMapping("/tasks/{taskId}/subtasks")
    public List<SubtaskResponseDTO> get(@PathVariable Long taskId) {
        return service.getByTask(taskId);
    }

    /* ═══════════════════════════════════════
                    CREATE
    ═══════════════════════════════════════ */
    @PostMapping("/tasks/{taskId}/subtasks")
    public SubtaskResponseDTO create(@PathVariable Long taskId,
                                     @Valid @RequestBody SubtaskRequestDTO dto,
                                     Authentication auth) {

        return service.create(taskId, dto, auth.getName());
    }

    /* ═══════════════════════════════════════
                    TOGGLE
    ═══════════════════════════════════════ */
    @PatchMapping("/subtasks/{id}/toggle")
    public SubtaskResponseDTO toggle(@PathVariable Long id) {
        return service.toggle(id);
    }

    /* ═══════════════════════════════════════
                    UPDATE
    ═══════════════════════════════════════ */
    @PutMapping("/subtasks/{id}")
    public SubtaskResponseDTO update(@PathVariable Long id,
                                     @Valid @RequestBody SubtaskRequestDTO dto) {

        return service.update(id, dto);
    }

    /* ═══════════════════════════════════════
                    DELETE
    ═══════════════════════════════════════ */
    @DeleteMapping("/subtasks/{id}")
    public void delete(@PathVariable Long id, Authentication auth) {
        service.delete(id, auth.getName());
    }

    /* ═══════════════════════════════════════
                    SUMMARY
    ═══════════════════════════════════════ */
    @GetMapping("/tasks/{taskId}/subtasks/summary")
    public SubtaskSummaryDTO summary(@PathVariable Long taskId) {
        return service.summary(taskId);
    }
}