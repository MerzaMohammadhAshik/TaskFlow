/* ═══════════════════════════════════════
        TaskTimerController.java
═══════════════════════════════════════ */

package main.controller;

import main.entity.ActiveTimerEntity;
import main.entity.TaskTimeLogEntity;
import main.service.TaskTimerService;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
@CrossOrigin("*")
public class TaskTimerController {

    private final TaskTimerService service;

    public TaskTimerController(TaskTimerService service) {
        this.service = service;
    }

    // ▶ FETCH PREVIOUS TIME
    @GetMapping("/tasks/{taskId}/timer/fetchBeforeTime")
    public ResponseEntity<?> fetchBeforeTime(@PathVariable Long taskId, Authentication auth) throws Exception {

        try {
            LocalDateTime time = service.fetchBeforeTime(taskId, auth.getName());
            return ResponseEntity.status(200).body(Map.of("time", time));

        } catch (Exception e) {
            return ResponseEntity.status(200).body(Map.of("time", ""));
        }
    }

    // ▶ START
    @PostMapping("/tasks/{taskId}/timer/start")
    public void start(@PathVariable Long taskId, Authentication auth) {
        service.startTimer(taskId, auth.getName());
    }

    // ⏹ STOP
    @PostMapping("/tasks/{taskId}/timer/stop")
    public void stop(@PathVariable Long taskId, Authentication auth) {
        service.stopTimer(taskId, auth.getName());
    }

    // 🔄 ACTIVE
    @GetMapping("/tasks/{taskId}/timer/active")
    public ActiveTimerEntity active(@PathVariable Long taskId, Authentication auth) {
        return service.getActiveTimer(taskId, auth.getName());
    }

    // ➕ MANUAL
    @PostMapping("/tasks/{taskId}/time-logs")
    public void manual(@PathVariable Long taskId,
                       @RequestBody Map<String, Object> body,
                       Authentication auth) {

        service.addManual(
                taskId,
                auth.getName(),
                (Integer) body.get("durationMinutes"),
                (String) body.get("logDate"),
                (String) body.get("note")
        );
    }

    // 📜 LOGS
    @GetMapping("/tasks/{taskId}/time-logs")
    public List<TaskTimeLogEntity> logs(@PathVariable Long taskId) {
        return service.getLogs(taskId);
    }

    // 🧮 TOTAL
    @GetMapping("/tasks/{taskId}/time-logs/total")
    public Map<String, Integer> total(@PathVariable Long taskId) {
        return Map.of("totalMinutes", service.getTotal(taskId));
    }

    // ❌ DELETE
    @DeleteMapping("/time-logs/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}