/* ═══════════════════════════════════════
            UserController.java
═══════════════════════════════════════ */
package main.controller;

import main.dto.PasswordChangeRequestDto;
import main.dto.ProfileUpdateRequestDto;
import main.dto.UserResponseDTO;
import main.dto.UserRoleChangeRequestDto;
import main.service.UserService;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api")
public class UserController {

	private final UserService service;

	public UserController(UserService service) {
		this.service = service;
	}

	/*
	 * ───────────────────────────────── Get All Users
	 * ─────────────────────────────────
	 */

	@GetMapping("/admin/users")
	public ResponseEntity<List<UserResponseDTO>> getAllUsers() {
		return ResponseEntity.ok(service.getAllUsers());
	}

	/*
	 * ───────────────────────────────── Change Role
	 * ─────────────────────────────────
	 */

	@PutMapping("/admin/users/change-role")
	public ResponseEntity<?> changeUserRole(@Valid @RequestBody UserRoleChangeRequestDto dto) {

		try {

			String message = service.changeUserRole(dto);

			return ResponseEntity.ok(Map.of("message", message));

		} catch (IllegalArgumentException e) {

			return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
		}
	}

	/*
	 * ───────────────────────────────── 
	 * Activate / Deactivate User
	 * ─────────────────────────────────
	 */

	@PutMapping("/admin/users/toggle-status/{id}")
	public ResponseEntity<?> toggleStatus(@PathVariable Long id) {

		try {

			String message = service.toggleUserStatus(id);

			return ResponseEntity.ok(Map.of("message", message));

		} catch (IllegalArgumentException e) {

			return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
		}
	}

	/*
	 * ───────────────────────────────── Delete User
	 * ─────────────────────────────────
	 */

	@DeleteMapping("/admin/users/{id}")
	public ResponseEntity<?> deleteUser(@PathVariable Long id) {

		try {

			String message = service.deleteUser(id);

			return ResponseEntity.ok(Map.of("message", message));

		} catch (IllegalArgumentException e) {

			return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
		}
	}

	@GetMapping("/admin/stats")
	public ResponseEntity<Map<String, Object>> getStats() {
		return ResponseEntity.ok(service.getUserStatistics());
	}

	/*
	 * ───────────────────────────────── Update Profile PATCH /api/users/me/profile
	 * ─────────────────────────────────
	 */

	@PatchMapping("/users/me/profile")
	public ResponseEntity<UserResponseDTO> updateProfile(@Valid @RequestBody ProfileUpdateRequestDto dto,Authentication auth) {

		return ResponseEntity.ok(service.updateProfile(dto,auth.getName()));
	}

	/*
	 * ───────────────────────────────── 
	 * Delete My Account DELETE /api/users/me
	 * ─────────────────────────────────
	 */

	@DeleteMapping("/users/me")
	public ResponseEntity<?> deleteMyAccount(Authentication auth) {

		service.deleteMyAccount(auth.getName());

		return ResponseEntity.ok().body("Account deleted successfully");
	}
	
	@PatchMapping("/users/me/password")
	public ResponseEntity<?> changePassword(@Valid @RequestBody PasswordChangeRequestDto dto, 
	                                        Authentication auth ) {
	    try {
	        service.changePassword(auth.getName(), dto);
	        return ResponseEntity.ok(Map.of("message", "Password changed successfully ✅"));
	    } catch (IllegalArgumentException e) {
	        return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
	    }
	}

}