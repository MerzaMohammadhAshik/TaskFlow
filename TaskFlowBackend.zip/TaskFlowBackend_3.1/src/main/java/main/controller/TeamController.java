/* ═══════════════════════════════════════
            TeamController.java
════════════════════════════════════════ */
package main.controller;

import jakarta.validation.Valid;
import main.dto.TeamRequestDTO;
import main.dto.TeamResponseDto;
import main.entity.TeamMemberEntity;
import main.service.TeamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import com.fasterxml.jackson.databind.JsonNode;

import java.security.Principal;
import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/teams")
public class TeamController {

    @Autowired
    private TeamService teamService;

    @PostMapping
    public ResponseEntity<TeamResponseDto> createTeam(@Valid @RequestBody TeamRequestDTO dto) {
        TeamResponseDto created = teamService.createTeam(dto);
        return ResponseEntity.status(201).body(created);
    }

    @GetMapping
    public ResponseEntity<List<TeamResponseDto>> getTeamsForUser(Authentication auth) {
        List<TeamResponseDto> teams = teamService.getTeamsForUser(auth.getName());
        return ResponseEntity.ok(teams);
    }

    @GetMapping("/{id}")
    public ResponseEntity<TeamResponseDto> getTeamDetail(@PathVariable Long id) {
        return teamService.getTeamDetail(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/{id}/members")
    public ResponseEntity<?> addMember(@PathVariable Long id,@RequestBody JsonNode body) {
        return ResponseEntity.status(201).body(Map.of("message",teamService.addMember( id, body.get("userId").asLong())));
    }
    

    @DeleteMapping("/{id}/members/{userId}")
    public ResponseEntity<?> removeMember(@PathVariable Long id, @PathVariable Long userId) {
        teamService.removeMember(id, userId);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteTeam(@PathVariable Long id) {
        teamService.deleteTeam(id);
        return ResponseEntity.noContent().build();
    }
}