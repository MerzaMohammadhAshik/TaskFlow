/* ═══════════════════════════════════════
            CommentsController.java
═══════════════════════════════════════ */
// TaskController.java
package main.controller;

import jakarta.validation.Valid;
import main.dto.CommentRequestDTO;
import main.dto.CommentResponseDTO;
import main.service.CommentsService;
import main.service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api")
public class CommentsController {

    @Autowired private CommentsService taskCommentsService;
    @Autowired private TaskService taskService;

    /**
     * GET /api/tasks/{taskId}/comments
     * Retrieve all comments for a specific task.
     */
    @GetMapping("/tasks/{taskId}/comments")
    public ResponseEntity<List<CommentRequestDTO>> getComments(@PathVariable Long taskId) {
        return ResponseEntity.ok(taskCommentsService.getAllComments(taskId));
    }

    /**
     * POST /api/tasks/{taskId}/comments
     * Create a new comment for the specified task.
     */
    @PostMapping("/tasks/{taskid}/comments")
    public ResponseEntity<?> createTask(@Valid @RequestBody CommentResponseDTO dto,
                                        @PathVariable Long taskid,
                                        Authentication auth) {

        if (!taskService.existsById(taskid)) {
            return ResponseEntity.status(403)
                    .body(Map.of("message", "Wrong Task Id "));
        }

        try {
            CommentRequestDTO task =
                    taskCommentsService.createTaskComment(dto, taskid, auth.getName());

            System.out.println("controller");
            return ResponseEntity.status(201).body(task);

        } catch (RuntimeException e) {
            return ResponseEntity.status(403)
                    .body(Map.of("message", e.getMessage()));
        }
    }

    /**
     * DELETE /api/comments/{commentId}
     * Delete a specific comment by its ID.
     */
    @DeleteMapping("/comments/{commentId}")
    public ResponseEntity<?> deleteComment(@PathVariable Long commentId,
                                           Authentication auth) {
        try {
            taskCommentsService.deleteTaskComment(commentId, auth.getName());
            return ResponseEntity.noContent().build(); // 204

        } catch (RuntimeException e) {
            return ResponseEntity.status(403)
                    .body(Map.of("message", e.getMessage()));
        }
    }
}