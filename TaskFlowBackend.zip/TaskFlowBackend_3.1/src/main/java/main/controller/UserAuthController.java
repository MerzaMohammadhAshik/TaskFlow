/* ═══════════════════════════════════════
            UserController.java
═══════════════════════════════════════ */
// UserController.java
package main.controller;

import jakarta.validation.Valid;
import main.dto.AuthResponseDTO;
import main.dto.UserRequestDTO;
import main.dto.UserRoleChangeRequestDto;
import main.dto.UserIdNameResponseDTO;
import main.entity.Role;
//import main.entity.AuthResponse;
import main.entity.UserEntity;
//import main.entity.UserDTO;
import main.service.UserAuth;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import java.util.List;
import java.util.Map;
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api")
public class UserAuthController {

    @Autowired
    private UserAuth service;
    
    @GetMapping("/auth/hello")
    public ResponseEntity<String> testApi(){
    	return ResponseEntity.ok("API work Successfull");
    }
    
    @GetMapping("/users")
    public ResponseEntity<List<UserIdNameResponseDTO>> findUsersForAssign(){
    	return ResponseEntity.ok(service.findAllUsers());
    }
    
    @GetMapping("/users/{userRole}")
    public ResponseEntity<List<UserIdNameResponseDTO>> findAllManagerTeam(@PathVariable Role userRole){
    	return ResponseEntity.ok(service.findAllByRole(userRole));
    }
    
    @PostMapping("/auth/register")
    public ResponseEntity<?> register(@Valid @RequestBody UserRequestDTO dto) {
        String result = service.register(dto);
        if ("EMAIL_EXISTS".equals(result)) {
            return ResponseEntity.badRequest()
                    .body(Map.of("message", "Email already exists. Please use a different email."));
        }
        return ResponseEntity.status(201)
                .body(Map.of("message", "Registered successfully! Please log in."));
    }

    @PostMapping("/auth/login")
    public ResponseEntity<?> login(@RequestBody UserEntity user) {
        AuthResponseDTO res = service.login(user.getEmail(), user.getPassword());
        if (res != null) {
            return ResponseEntity.ok(res);
        }
        return ResponseEntity.status(401)
                .body(Map.of("message", "Invalid email or password. Please try again."));
    }
    
    @PutMapping("/users/change-role")
    public ResponseEntity<?> changeUserRole(@Valid @RequestBody UserRoleChangeRequestDto dto) {
        try {
            String message = service.changeUserRole(dto);
            return ResponseEntity.ok(Map.of("message", message));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

}