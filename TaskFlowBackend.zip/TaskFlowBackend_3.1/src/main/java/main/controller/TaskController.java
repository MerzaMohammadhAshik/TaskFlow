/* ═══════════════════════════════════════
            TaskController.java
═══════════════════════════════════════ */
// TaskController.java
package main.controller;

import jakarta.validation.Valid;
import main.dto.TaskRequestDTO;
import main.dto.TaskResponseDTO;
import main.dto.TaskSummaryDTO;
import main.entity.TaskEntity;
//import main.entity.TaskDTO;
import main.service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/tasks")
public class TaskController {

    @Autowired
    private TaskService taskService;
    
    @GetMapping("/summary")
    public ResponseEntity<TaskSummaryDTO> getTaskSummary(Authentication auth) {
        String email = auth.getName(); // from JWT
        TaskSummaryDTO summary = taskService.getTaskSummary(email);
        return ResponseEntity.ok(summary);
    }

    /** GET /api/tasks — all tasks for logged-in user */
    @GetMapping
    public ResponseEntity<List<TaskResponseDTO>> getAllTasks(Authentication auth) {
        return ResponseEntity.ok(taskService.getAllTasks(auth.getName()));
    }
    
    /** GET /api/tasks — all tasks for logged-in user */
    @GetMapping("/assigntome")
    public ResponseEntity<List<TaskResponseDTO>> getAllTasksAssignToMe(Authentication auth) {
        return ResponseEntity.ok(taskService.getAllTasksAssignToMe(auth.getName()));
    }

    /** POST /api/tasks — create a new task */
    @PostMapping
    public ResponseEntity<?> createTask(@Valid @RequestBody TaskRequestDTO dto,
                                        Authentication auth) {
        TaskEntity task = taskService.createTask(dto, auth.getName());
        return ResponseEntity.status(201).body(task.getId());
    }

    /** GET /api/tasks/{id} — get a specific task */
    @GetMapping("/{id}")
    public ResponseEntity<?> getTask(@PathVariable Long id,
                                     Authentication auth) {
        return taskService.getTaskById(id, auth.getName())
                .<ResponseEntity<?>>map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    /** PUT /api/tasks/{id} — update a task */
    @PutMapping("/{id}")
    public ResponseEntity<?> updateTask(@PathVariable Long id,
                                         @RequestBody TaskRequestDTO dto,
                                        Authentication auth) {
        try {System.out.println("Task Id : "+id+dto.toString());
            TaskEntity updated = taskService.updateTask(id, dto, auth.getName());
            System.out.println("update complit");
            return ResponseEntity.ok(updated);
        } catch (RuntimeException e) {
            return ResponseEntity.status(403)
                    .body(Map.of("message", e.getMessage()));
        }
    }

    /** DELETE /api/tasks/{id} — delete a task */
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteTask(@PathVariable Long id,
                                        Authentication auth) {
        try {System.out.println("delet request");
            taskService.deleteTask(id, auth.getName());
            return ResponseEntity.noContent().build(); // 204
        } catch (RuntimeException e) {
            return ResponseEntity.status(403)
                    .body(Map.of("message", e.getMessage()));
        }
    }
}