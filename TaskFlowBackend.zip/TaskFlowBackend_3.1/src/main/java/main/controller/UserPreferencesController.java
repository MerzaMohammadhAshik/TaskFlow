/* ═══════════════════════════════════════
        UserPreferencesController.java
═══════════════════════════════════════ */
package main.controller;

import main.dto.UserPreferencesDTO;
import main.service.UserPreferencesService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api")
public class UserPreferencesController {

    private final UserPreferencesService service;

    public UserPreferencesController(UserPreferencesService service) {
        this.service = service;
    }

    /* ── Get Preferences ── */
    @GetMapping("/preferences")
    public ResponseEntity<UserPreferencesDTO> getPreferences(Authentication auth) {
        return ResponseEntity.ok(service.getPreferences(auth.getName()));
    }

    /* ── Update Preferences ── */
    @PatchMapping("/preferences")
    public ResponseEntity<UserPreferencesDTO> updatePreferences(
            @Valid @RequestBody UserPreferencesDTO dto,
            Authentication auth) {
        return ResponseEntity.ok(service.updatePreferences(auth.getName(), dto));
    }
    
    
}