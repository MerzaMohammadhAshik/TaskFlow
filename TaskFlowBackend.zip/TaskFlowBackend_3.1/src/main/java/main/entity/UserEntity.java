/* ═══════════════════════════════════════
            UserEntity.java
═══════════════════════════════════════ */

package main.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "users")
public class UserEntity {

    /* ───────── PRIMARY KEY ───────── */

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;


    /* ───────── SOFT DELETE FLAG ───────── */

    @Column(name = "is_delete")
    private boolean isDelete = false;


    /* ───────── USER BASIC INFO ───────── */

    @Column(name = "full_name", nullable = false, length = 100)
    private String fullname;

    @Column(unique = true, nullable = false, length = 150)
    private String email;


    /* ───────── SECURITY ───────── */

    @Column(name = "password_hash", nullable = false, length = 255)
    private String password;


    /* ───────── AUDIT FIELD ───────── */

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;


    /* ───────── USER ROLE ───────── */

    @Enumerated(EnumType.STRING)
    @Column(name = "role", nullable = false)
    private Role role = Role.MEMBER;


    /* ───────── ACCOUNT STATUS ───────── */

    @Column(name = "is_active", nullable = false)
    private boolean isActive = true;



    /* ─────────────────────────────────────
                CONSTRUCTORS
    ───────────────────────────────────── */

    public UserEntity() {}

    public UserEntity(String fullname, String email, String password, Role role) {
        this.fullname = fullname;
        this.email = email;
        this.password = password;
        this.role = role;
    }



    /* ─────────────────────────────────────
            AUTO SET CREATED DATE
    ───────────────────────────────────── */

    @PrePersist
    public void prePersist() {
        this.createdAt = LocalDateTime.now();
    }



    /* ─────────────────────────────────────
                GETTERS & SETTERS
    ───────────────────────────────────── */

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public boolean isDelete() {
        return isDelete;
    }

    public void setDelete(boolean delete) {
        this.isDelete = delete;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        this.isActive = active;
    }



    /* ─────────────────────────────────────
                    TO STRING
    ───────────────────────────────────── */

    @Override
    public String toString() {
        return "UserEntity [id=" + id +
                ", fullname=" + fullname +
                ", email=" + email +
                ", createdAt=" + createdAt +
                ", role=" + role +
                ", isActive=" + isActive +
                ", isDelete=" + isDelete +
                "]";
    }
}