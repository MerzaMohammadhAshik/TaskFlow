/* ═══════════════════════════════════════
            Role.java
═══════════════════════════════════════ */
package main.entity;


public enum Role {
    ADMIN,
    MANAGER,
    MEMBER,
    VIEWER
}