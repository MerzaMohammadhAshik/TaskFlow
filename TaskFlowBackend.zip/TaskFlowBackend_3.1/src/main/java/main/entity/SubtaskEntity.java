/* ═══════════════════════════════════════
            SubtaskEntity.java
═══════════════════════════════════════ */

package main.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

import org.hibernate.annotations.Formula;

@Entity
@Table(name = "subtasks")
public class SubtaskEntity {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "task_id", nullable = false)
    private TaskEntity task;

    @Column(name = "title", nullable = false, length = 300)
    private String title;

    @Column(name = "is_complete", nullable = false)
    private boolean isComplete = false;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "assigned_to")
    private UserEntity assignedTo;
    
    /* Auto fetch fullname using subquery */
    @Formula("(SELECT u.full_name FROM users u WHERE u.id = assigned_to)")
    private String assignedToName;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "created_by", nullable = false)
    private UserEntity createdBy;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "completed_at")
    private LocalDateTime completedAt;

    @PrePersist
    public void prePersist() {
        this.createdAt = LocalDateTime.now();
    }

    /* ═══════════════════════════════════════
                Constructors
    ═══════════════════════════════════════ */
    public SubtaskEntity() {}

    public SubtaskEntity(Long id, TaskEntity task, String title, boolean isComplete,
                         UserEntity assignedTo, UserEntity createdBy,
                         LocalDateTime createdAt, LocalDateTime completedAt) {
        this.id = id;
        this.task = task;
        this.title = title;
        this.isComplete = isComplete;
        this.assignedTo = assignedTo;
        this.createdBy = createdBy;
        this.createdAt = createdAt;
        this.completedAt = completedAt;
    }

    /* ═══════════════════════════════════════
                Getters & Setters
    ═══════════════════════════════════════ */
    public Long getId() {
        return id;
    }

    public TaskEntity getTask() {
        return task;
    }

    public void setTask(TaskEntity task) {
        this.task = task;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public boolean isComplete() {
        return isComplete;
    }

    public void setComplete(boolean complete) {
        isComplete = complete;
    }

    public UserEntity getAssignedTo() {
        return assignedTo;
    }

    public void setAssignedTo(UserEntity assignedTo) {
        this.assignedTo = assignedTo;
    }

    public String getAssignedToName() {
		return assignedToName;
	}

	public void setAssignedToName(String assignedToName) {
		this.assignedToName = assignedToName;
	}

	public UserEntity getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(UserEntity createdBy) {
        this.createdBy = createdBy;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public LocalDateTime getCompletedAt() {
        return completedAt;
    }

    public void setCompletedAt(LocalDateTime completedAt) {
        this.completedAt = completedAt;
    }
}