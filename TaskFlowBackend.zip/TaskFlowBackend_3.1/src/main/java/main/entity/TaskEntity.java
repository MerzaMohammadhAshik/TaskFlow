/* ═══════════════════════════════════════
            TaskEntity.java
═══════════════════════════════════════ */
// Task.java
package main.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import org.hibernate.annotations.Formula;

@Entity
@Table(name = "tasks")
public class TaskEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Title is required")
    @Column(nullable = false, length = 200)
    private String title;

    @Column(columnDefinition = "TEXT")
    private String description;

    @NotNull(message = "Due date is required")
    @Column(name = "due_date", nullable = false)
    private LocalDate dueDate;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TaskStatus status = TaskStatus.TODO;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    @JsonIgnore
    private UserEntity user;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    @Column(name = "updated_at")
    private LocalDateTime updatedAt = LocalDateTime.now();
    
    // New field: assigned_to (nullable, FK → users.id, ON DELETE SET NULL)
//    @ManyToOne(fetch = FetchType.LAZY)
//    @JoinColumn(name = "assigned_to", foreignKey = @ForeignKey(name = "fk_task_assigned_user"))
//    @JsonIgnore
//    private UserEntity assignedTo;
    
    @Column(name ="assigned_to")
//    @Formula("(assigned_to)") 
    private Long assignedToId;   //  change assignedToId

    @Formula("(select u.full_name from users u where u.id = assigned_to)")
    private String assignedToName;
    

    // New field: priority ENUM('HIGH','MEDIUM','LOW') with default MEDIUM
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TaskPriority priority = TaskPriority.MEDIUM;
    
//    @OneToMany(mappedBy = "task", cascade = CascadeType.ALL, orphanRemoval = true)
//    @JsonIgnore
//    private List<CommentEntity> comments;
    
    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="team_id", foreignKey=@ForeignKey(name="fk_task_team"))
    private TeamEntity team;

    @PreUpdate
    public void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }

    // ── Getters & Setters ─────────────────────────────────
    public Long getId()             { return id; }
    public void setId(Long id)      { this.id = id; }

    public String getTitle()        { return title; }
    public void setTitle(String t)  { this.title = t; }

    public String getDescription()       { return description; }
    public void setDescription(String d) { this.description = d; }

    public LocalDate getDueDate()        { return dueDate; }
    public void setDueDate(LocalDate d)  { this.dueDate = d; }

    public TaskStatus getStatus()          { return status; }
    public void setStatus(TaskStatus s)    { this.status = s; }

    public UserEntity getUser()            { return user; }
    public void setUser(UserEntity u)      { this.user = u; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }
    
//    public UserEntity getAssignedTo() { return assignedTo; }
//    public void setAssignedTo(UserEntity assignedTo) { this.assignedTo = assignedTo; }

    public TaskPriority getPriority() { return priority; }
    public void setPriority(TaskPriority priority) { this.priority = priority; }
    
    //////////////////////////////////
    public Long getAssignedToId() {
        return assignedToId;
    }

    public void setAssignedToId(Long assignedToId) {
        this.assignedToId = assignedToId;
    }

    public String getAssignedToName() {
        return assignedToName;
    }

    public void setAssignedToName(String assignedToName) {
        this.assignedToName = assignedToName;
    }
    ///////////////////////////////////
    

	@Override
	public String toString() {
		return "Task [id=" + id + ", title=" + title + ", description=" + description + ", dueDate=" + dueDate
				+ ", status=" + status + ", user=" + user.toString() + ", createdAt=" + createdAt + ", updatedAt=" + updatedAt
//				+ ", assignedTo=" + assignedTo 
				+ ", priority=" + priority + "]";
	}

    
}