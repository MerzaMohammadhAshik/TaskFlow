/* ═══════════════════════════════════════
            ActivityLogEntity.java
═══════════════════════════════════════ */
package main.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Entity
@Table(name = "activity_log")
public class ActivityLogEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Nullable FK → tasks.id (ON DELETE SET NULL)
//    @ManyToOne(fetch = FetchType.LAZY)
//    @JoinColumn(name = "task_id", foreignKey = @ForeignKey(name = "fk_activity_task"))
//    @JsonIgnore
//    private TaskEntity task;
    
    @Column(name = "task_id", updatable = false)
    private Long taskId;

    // FK → users.id (ON DELETE CASCADE)
    @NotNull(message = "Actor is required")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "actor_id", nullable = false, foreignKey = @ForeignKey(name = "fk_activity_user"))
    @JsonIgnore
    private UserEntity actor;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "action_code", nullable = false, length = 50)
    private ActionCode actionCode;

    @NotBlank(message = "Message is required")
    @Column(name = "message", nullable = false, length = 500)
    private String message;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    // ── Lifecycle hook to set timestamp ─────────────────────
    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
    }

    // ── Getters & Setters ──────────────────────────────────
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

//    public TaskEntity getTask() { return task; }
//    public void setTask(TaskEntity task) { this.task = task; }
    
    public Long getTaskId() { return taskId; }
    public void setTaskId(Long taskId) {this.taskId = taskId;}

    public UserEntity getActor() { return actor; }
    public void setActor(UserEntity actor) { this.actor = actor; }

    public ActionCode getActionCode() { return actionCode; }
    public void setActionCode(ActionCode actionCode) { this.actionCode = actionCode; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public LocalDateTime getCreatedAt() { return createdAt; }
}