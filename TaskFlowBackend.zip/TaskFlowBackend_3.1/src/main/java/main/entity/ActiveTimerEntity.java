/* ═══════════════════════════════════════
            ActiveTimerEntity.java
═══════════════════════════════════════ */

package main.entity;

import java.time.LocalDateTime;

import jakarta.persistence.*;

@Entity
@Table(name = "active_timers",
       uniqueConstraints = @UniqueConstraint(columnNames = {"taskId", "userId"}))
public class ActiveTimerEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long taskId;

    private Long userId;

    private LocalDateTime startTime;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getTaskId() {
		return taskId;
	}

	public void setTaskId(Long taskId) {
		this.taskId = taskId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public LocalDateTime getStartTime() {
		return startTime;
	}

	public void setStartTime(LocalDateTime startTime) {
		this.startTime = startTime;
	}

    // getters/setters
    
	
	
    
}
