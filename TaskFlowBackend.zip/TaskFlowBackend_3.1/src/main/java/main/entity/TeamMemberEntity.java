/* ═══════════════════════════════════════
            TeamMemberEntity.java
═══════════════════════════════════════ */
package main.entity;

import java.time.LocalDateTime;
import jakarta.persistence.*;

@Entity
@Table(name = "team_members")
@IdClass(TeamMemberId.class)
public class TeamMemberEntity {

    @Id
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "team_id", foreignKey = @ForeignKey(name = "fk_member_team"))
    private TeamEntity team;

    @Id
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", foreignKey = @ForeignKey(name = "fk_member_user"))
    private UserEntity user;

    @Column(name = "joined_at", updatable = false)
    private LocalDateTime joinedAt = LocalDateTime.now();

    // Getters & Setters
    public TeamEntity getTeam() { return team; }
    public void setTeam(TeamEntity team) { this.team = team; }

    public UserEntity getUser() { return user; }
    public void setUser(UserEntity user) { this.user = user; }

    public LocalDateTime getJoinedAt() { return joinedAt; }
    public void setJoinedAt(LocalDateTime joinedAt) { this.joinedAt = joinedAt; }

    @Override
    public String toString() {
        return "TeamMemberEntity [team=" + (team != null ? team.getId() : null) +
               ", user=" + (user != null ? user.getId() : null) +
               ", joinedAt=" + joinedAt + "]";
    }
}