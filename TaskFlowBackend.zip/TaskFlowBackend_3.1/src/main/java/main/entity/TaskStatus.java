/* ═══════════════════════════════════════
            TaskStatus.java
═══════════════════════════════════════ */
// TaskStatus.java
package main.entity;

public enum TaskStatus {
    TODO,
    IN_PROGRESS,
    DONE
}