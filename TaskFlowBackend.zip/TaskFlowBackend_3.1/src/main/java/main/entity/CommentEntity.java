/* ═══════════════════════════════════════
            CommentEntity.java
═══════════════════════════════════════ */
// TaskComments.java
package main.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;

import org.hibernate.annotations.Formula;

@Entity
@Table(name = "task_comments")
public class CommentEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

//    @NotNull(message = "Task is required")
//    @ManyToOne(fetch = FetchType.LAZY)
//    @JoinColumn(name = "task_id", nullable = false)
//    @JsonIgnore
//    private TaskEntity task;
    
    @NotNull(message = "Task is required")
    @Column(name = "task_id")
    private Long task;

    @NotNull(message = "Author is required")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "author_id", nullable = false)
    @JsonIgnore
    private UserEntity author;
    
    @Formula("author_id")
    private Long authorId;

    @Formula("(select u.full_name from users u where u.id = author_id)")
    private String authorName;
    

    @NotBlank(message = "Comment body is required")
    @Column(name = "body", nullable = false, columnDefinition = "TEXT")
    private String body;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    // ── Lifecycle hook to set timestamp ─────────────────────
    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
    }

    // ── Getters & Setters ──────────────────────────────────
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

//    public TaskEntity getTask() { return task; }
//    public void setTask(TaskEntity task) { this.task = task; }
    
    public Long getTask() { return task; }
    public void setTask(Long task) { this.task = task; }

    public UserEntity getAuthor() { return author; }
    public void setAuthor(UserEntity author) { this.author = author; }

    public String getBody() { return body; }
    public void setBody(String body) { this.body = body; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    
    ///////////////////////////////////////
    public Long getAuthorId() {
        return authorId;
    }

    public void setAuthorId(Long authorId) {
        this.authorId = authorId;
    }

    public String getAuthorName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }
    
    //////////////////////////////////////
}