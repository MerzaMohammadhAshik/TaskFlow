/* ═══════════════════════════════════════
            TaskPriority.java
═══════════════════════════════════════ */
package main.entity;

public enum TaskPriority {
    HIGH,
    MEDIUM,
    LOW
}