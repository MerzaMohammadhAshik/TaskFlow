/* ═══════════════════════════════════════
        UserPreferencesEntity.java
═══════════════════════════════════════ */

package main.entity;

import jakarta.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "user_preferences")
public class UserPreferencesEntity implements Serializable {

    /* ───────── PRIMARY KEY ───────── */
    @Id
    @Column(name = "user_id")
    private Long userId;

    @OneToOne(fetch = FetchType.LAZY)
    @MapsId
    @JoinColumn(name = "user_id", referencedColumnName = "id")
    private UserEntity user;

    /* ───────── THEME ───────── */
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Theme theme = Theme.LIGHT;

    /* ───────── NOTIFICATIONS ───────── */
    @Column(name = "notify_assigned", nullable = false)
    private boolean notifyAssigned = true;

    @Column(name = "notify_comment", nullable = false)
    private boolean notifyComment = true;

    @Column(name = "notify_subtask", nullable = false)
    private boolean notifySubtask = true;

    @Column(name = "notify_overdue", nullable = false)
    private boolean notifyOverdue = true;

    @Column(name = "notify_team", nullable = false)
    private boolean notifyTeam = true;

    /* ───────── AVATAR & BIO ───────── */
    @Column(name = "avatar_colour", nullable = false, length = 7)
    private String avatarColour = "#2563EB";

    @Column(length = 200)
    private String bio;

    /* ───────── CONSTRUCTORS ───────── */
    public UserPreferencesEntity() {}

    public UserPreferencesEntity(UserEntity user) {
        this.user = user; // ✅ ONLY THIS
    }

    /* ───────── GETTERS & SETTERS ───────── */
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public UserEntity getUser() { return user; }
    public void setUser(UserEntity user) { this.user = user; }

    public Theme getTheme() { return theme; }
    public void setTheme(Theme theme) { this.theme = theme; }

    public boolean isNotifyAssigned() { return notifyAssigned; }
    public void setNotifyAssigned(boolean notifyAssigned) { this.notifyAssigned = notifyAssigned; }

    public boolean isNotifyComment() { return notifyComment; }
    public void setNotifyComment(boolean notifyComment) { this.notifyComment = notifyComment; }

    public boolean isNotifySubtask() { return notifySubtask; }
    public void setNotifySubtask(boolean notifySubtask) { this.notifySubtask = notifySubtask; }

    public boolean isNotifyOverdue() { return notifyOverdue; }
    public void setNotifyOverdue(boolean notifyOverdue) { this.notifyOverdue = notifyOverdue; }

    public boolean isNotifyTeam() { return notifyTeam; }
    public void setNotifyTeam(boolean notifyTeam) { this.notifyTeam = notifyTeam; }

    public String getAvatarColour() { return avatarColour; }
    public void setAvatarColour(String avatarColour) { this.avatarColour = avatarColour; }

    public String getBio() { return bio; }
    public void setBio(String bio) { this.bio = bio; }

    /* ───────── THEME ENUM ───────── */
    public enum Theme {
        LIGHT, DARK, SYSTEM
    }
}