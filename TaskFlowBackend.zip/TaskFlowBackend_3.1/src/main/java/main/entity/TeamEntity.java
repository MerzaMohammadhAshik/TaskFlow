/* ═══════════════════════════════════════
            TeamEntity.java
═══════════════════════════════════════ */
package main.entity;

import java.time.LocalDateTime;
import java.util.List;
import jakarta.persistence.*;

@Entity
@Table(name = "teams")
public class TeamEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable=false, unique=true, length=100)
    private String name;

    @Column(columnDefinition="TEXT")
    private String description;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="manager_id", nullable=false, foreignKey=@ForeignKey(name="fk_team_manager"))
    private UserEntity manager;

    @Column(name="created_at", updatable=false)
    private LocalDateTime createdAt = LocalDateTime.now();

    @OneToMany(mappedBy="team", cascade=CascadeType.ALL, orphanRemoval=true)
    private List<TeamMemberEntity> members;

    @OneToMany(mappedBy="team", cascade=CascadeType.ALL, orphanRemoval=true)
    private List<TaskEntity> tasks;

    // Getters & Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public UserEntity getManager() { return manager; }
    public void setManager(UserEntity manager) { this.manager = manager; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public List<TeamMemberEntity> getMembers() { return members; }
    public void setMembers(List<TeamMemberEntity> members) { this.members = members; }

    public List<TaskEntity> getTasks() { return tasks; }
    public void setTasks(List<TaskEntity> tasks) { this.tasks = tasks; }

    @Override
    public String toString() {
        return "TeamEntity [id=" + id + ", name=" + name +
               ", description=" + description +
               ", manager=" + (manager != null ? manager.getId() : null) +
               ", createdAt=" + createdAt + "]";
    }
}