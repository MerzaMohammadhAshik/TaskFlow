/* ═══════════════════════════════════════
            TeamMemberId.java
═══════════════════════════════════════ */
package main.entity;

import java.io.Serializable;
import java.util.Objects;

public class TeamMemberId implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long team;
    private Long user;
    
    // ✅ Required by Hibernate
    public TeamMemberId() {}

    public TeamMemberId(Long team, Long user) {
		super();
		this.team = team;
		this.user = user;
	}
	// Getters & Setters
    public Long getTeam() { return team; }
    public void setTeam(Long team) { this.team = team; }

    public Long getUser() { return user; }
    public void setUser(Long user) { this.user = user; }
    
    @Override
    public int hashCode() { return Objects.hash(team, user); }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        TeamMemberId other = (TeamMemberId) obj;
        return Objects.equals(team, other.team) && Objects.equals(user, other.user);
    }

    @Override
    public String toString() {
        return "TeamMemberId [team=" + team + ", user=" + user + "]";
    }
}