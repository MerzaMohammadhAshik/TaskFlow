/* ═══════════════════════════════════════
            ActivityLogRepository.java
═══════════════════════════════════════ */
package main.repository;

import main.entity.ActivityLogEntity;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ActivityLogRepository
        extends JpaRepository<ActivityLogEntity, Long> {

//	@Query("""
//		    SELECT a
//		    FROM ActivityLogEntity a
//		    LEFT JOIN a.task t
//		    WHERE
//		          a.actor.email = :email
//		       OR t.user.email = :email
//		       OR t.assignedTo.email = :email
//		    ORDER BY a.createdAt DESC
//		""")
//		List<ActivityLogEntity> findRecentActivityForUser(
//		        @Param("email") String email,
//		        Pageable pageable
//		);
	 @Query("""
		        SELECT a
		        FROM ActivityLogEntity a
		        WHERE a.actor.email = :email
		        ORDER BY a.createdAt DESC
		    """)
		    List<ActivityLogEntity> findRecentActivityForUser(
		            @Param("email") String email,
		            Pageable pageable
		    );
}