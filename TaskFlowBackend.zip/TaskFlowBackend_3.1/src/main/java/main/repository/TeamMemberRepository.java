/* ═══════════════════════════════════════
            TeamMemberRepository.java
═══════════════════════════════════════ */
package main.repository;

import main.entity.TeamMemberEntity;
import main.entity.TeamMemberId;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface TeamMemberRepository extends JpaRepository<TeamMemberEntity, TeamMemberId> {

    // Find all team memberships for a given user
    List<TeamMemberEntity> findByUser_Id(Long userId);

    // Optionally, find all team memberships for a given team
    List<TeamMemberEntity> findByTeam_Id(Long teamId);
}