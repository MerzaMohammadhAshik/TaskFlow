/* ═══════════════════════════════════════
        TaskTimeLogRepository.java
═══════════════════════════════════════ */


package main.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import main.entity.TaskTimeLogEntity;

public interface TaskTimeLogRepository extends JpaRepository<TaskTimeLogEntity, Long> {

    List<TaskTimeLogEntity> findByTaskIdOrderByLogDateDesc(Long taskId);

}