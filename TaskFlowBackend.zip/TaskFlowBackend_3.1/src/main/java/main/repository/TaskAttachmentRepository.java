package main.repository;

import main.entity.TaskAttachmentEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface TaskAttachmentRepository extends JpaRepository<TaskAttachmentEntity, Long> {

    List<TaskAttachmentEntity> findByTaskId(Long taskId);

    long countByTaskId(Long taskId);
}



//SELECT * FROM taskflow_db_new_3_0.task_attachments;
//
//SELECT * FROM taskflow_db_new_3_0.tasks;
//
//SHOW CREATE TABLE taskflow_db_new_3_0.task_attachments;
//
//use taskflow_db_new_3_0;
//
//ALTER TABLE task_attachments
//MODIFY file_data LONGBLOB NOT NULL;
//
//DESCRIBE task_attachments;