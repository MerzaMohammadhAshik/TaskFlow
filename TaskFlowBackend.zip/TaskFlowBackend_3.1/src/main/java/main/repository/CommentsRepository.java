/* ═══════════════════════════════════════
            CommentsRepository.java
═══════════════════════════════════════ */
// TaskRepository.java
package main.repository;

import main.entity.CommentEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CommentsRepository extends JpaRepository<CommentEntity, Long> {
//	List<TaskComments> findAllByTaskOrderByCreatedAtAsc(Task task); 
	List<CommentEntity> findAllByTaskOrderByCreatedAtAsc(Long taskId);   // Change findAllByTask_IdOrderByCreatedAtAsc
	Optional<CommentEntity> findByIdAndAuthor_Email(Long taskId,String email);
	
	
	// change  c.task.id   => c.task
	@Query("""
	           SELECT c FROM CommentEntity c
	           JOIN FETCH c.author
	           WHERE c.task = :taskId                   
	           ORDER BY c.createdAt DESC
	           """)
	    List<CommentEntity> findAllCommentsWithAuthor(@Param("taskId") Long taskId);
	
}