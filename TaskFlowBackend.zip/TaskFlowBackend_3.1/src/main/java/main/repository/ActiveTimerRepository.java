/* ═══════════════════════════════════════
        ActiveTimerRepository.java
═══════════════════════════════════════ */

package main.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import main.entity.ActiveTimerEntity;

public interface ActiveTimerRepository extends JpaRepository<ActiveTimerEntity, Long> {

    Optional<ActiveTimerEntity> findByTaskIdAndUserId(Long taskId, Long userId);

}