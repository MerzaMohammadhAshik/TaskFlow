/* ═══════════════════════════════════════
            UserRepository.java
═══════════════════════════════════════ */
package main.repository;

import main.entity.Role;
import main.entity.UserEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<UserEntity, Long> {

    Optional<UserEntity> findByEmail(String email);

    Optional<UserEntity> findByEmailAndIsDeleteFalse(String email);

    List<UserEntity> findAllByRole(Role role);

    List<UserEntity> findByIsDeleteFalse();
    
    long countByIsDeleteFalse();

    long countByRole(Role role);

    long countByIsActiveFalse();
}