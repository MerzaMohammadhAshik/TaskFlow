/* ═══════════════════════════════════════
            TaskRepository.java
═══════════════════════════════════════ */
// TaskRepository.java
package main.repository;

import main.entity.TaskEntity;
import main.entity.TaskPriority;
import main.entity.TaskStatus;
import main.entity.UserEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TaskRepository extends JpaRepository<TaskEntity, Long> {
    List<TaskEntity>     findByUser(UserEntity user);
    Optional<TaskEntity> findByIdAndUser(Long id, UserEntity user);
    List<TaskEntity> findByAssignedToId(Long id);   // hange findByAssignedTo  and UserEntity user
    
    Optional<TaskEntity> findById(Long id);
    
    // TOTAL  //  IF YOU Want To Add assign add =>  OR t.assignedTo.email = :email    // If Add Assign To User
    @Query("SELECT COUNT(t) FROM TaskEntity t WHERE t.user.email = :email")
    long countTotal(@Param("email") String email);

    // STATUS COUNTS
    @Query("SELECT COUNT(t) FROM TaskEntity t WHERE t.user.email = :email AND t.status = 'TODO'")
    long countTodo(@Param("email") String email);

    @Query("SELECT COUNT(t) FROM TaskEntity t WHERE t.user.email = :email AND t.status = 'IN_PROGRESS'")
    long countInProgress(@Param("email") String email);

    @Query("SELECT COUNT(t) FROM TaskEntity t WHERE t.user.email = :email AND t.status = 'DONE'")
    long countDone(@Param("email") String email);

    // PRIORITY COUNTS
    @Query("SELECT COUNT(t) FROM TaskEntity t WHERE t.user.email = :email AND t.priority = 'HIGH'")
    long countHigh(@Param("email") String email);

    @Query("SELECT COUNT(t) FROM TaskEntity t WHERE t.user.email = :email AND t.priority = 'MEDIUM'")
    long countMedium(@Param("email") String email);

    @Query("SELECT COUNT(t) FROM TaskEntity t WHERE t.user.email = :email AND t.priority = 'LOW'")
    long countLow(@Param("email") String email);

    // OVERDUE
    @Query("""
           SELECT COUNT(t)
           FROM TaskEntity t
           WHERE t.user.email = :email
           AND t.dueDate < CURRENT_DATE
           AND t.status <> 'DONE'
           """)
    long countOverdue(@Param("email") String email);

    // TASKS THIS WEEK
    @Query("""
    	       SELECT COUNT(t)
    	       FROM TaskEntity t
    	       WHERE t.user.email = :email
    	       AND t.createdAt >= :sevenDaysAgo
    	       """)
    	long countTasksThisWeek(@Param("email") String email,
    	                        @Param("sevenDaysAgo") java.time.LocalDateTime sevenDaysAgo);
}