/* ═══════════════════════════════════════
            TeamRepository.java
═══════════════════════════════════════ */
package main.repository;

import main.entity.TeamEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface TeamRepository extends JpaRepository<TeamEntity, Long> {

    boolean existsByName(String name);

    List<TeamEntity> findByManagerId(Long managerId);
}