/* ═══════════════════════════════════════
        UserPreferencesRepository.java
═══════════════════════════════════════ */
package main.repository;

import main.entity.UserPreferencesEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface UserPreferencesRepository extends JpaRepository<UserPreferencesEntity, Long> {
    Optional<UserPreferencesEntity> findByUserId(Long userId);
}