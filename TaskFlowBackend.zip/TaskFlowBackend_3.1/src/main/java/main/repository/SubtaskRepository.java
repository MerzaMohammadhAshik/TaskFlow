/* ═══════════════════════════════════════
                SubtaskRepository.java
   ═══════════════════════════════════════ */

package main.repository;

import main.entity.SubtaskEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SubtaskRepository extends JpaRepository<SubtaskEntity, Long> {

    /* ═══════════════════════════════════════
            Find all subtasks by Task
    ═══════════════════════════════════════ */
    List<SubtaskEntity> findByTaskIdOrderByCreatedAtAsc(Long taskId);

    /* ═══════════════════════════════════════
            Count total subtasks
    ═══════════════════════════════════════ */
    int countByTaskId(Long taskId);

    /* ═══════════════════════════════════════
        Count completed subtasks
    ═══════════════════════════════════════ */
    int countByTaskIdAndIsCompleteTrue(Long taskId);
}