/* ═══════════════════════════════════════
            TaskAttachmentService.java
═══════════════════════════════════════ */

package main.service;

import main.entity.TaskAttachmentEntity;
import main.entity.TaskEntity;
import main.entity.UserEntity;
import main.repository.TaskAttachmentRepository;
import main.repository.TaskRepository;
import main.repository.UserRepository;
import main.dto.AttachmentListDTO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class TaskAttachmentService {

    private final TaskAttachmentRepository repo;
    
    @Autowired private UserRepository userRepo;
    @Autowired private TaskRepository taskRepo;

    private static final long MAX_FILE_SIZE = 5 * 1024 * 1024;

    private static final Set<String> ALLOWED_TYPES = Set.of(
            "image/jpeg",
            "image/png",
            "image/gif",
            "application/pdf",
            "application/msword",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "text/plain",
            "application/zip"
    );

    public TaskAttachmentService(TaskAttachmentRepository repo) {
        this.repo = repo;
    }

    public void upload(Long taskId, String email, MultipartFile file) throws Exception {
    	
    	UserEntity user=userRepo.findByEmail(email).orElseThrow(()-> new RuntimeException("User Not Found"));
    	
    	TaskEntity task=taskRepo.findById(taskId).orElseThrow(()->new RuntimeException("Task Not Found "));
    	
        if (file.getSize() > MAX_FILE_SIZE)
            throw new RuntimeException("File exceeds 5MB");

        if (!ALLOWED_TYPES.contains(file.getContentType()))
            throw new RuntimeException("Invalid file type");

        long count = repo.countByTaskId(taskId);
        if (count >= 5)
            throw new RuntimeException("Maximum 5 attachments allowed");

        TaskAttachmentEntity entity = new TaskAttachmentEntity();

        entity.setTaskId(taskId);
        entity.setUploaderId(user.getId());
        entity.setOriginalName(file.getOriginalFilename());
        entity.setMimeType(file.getContentType());
        entity.setFileSizeBytes(file.getSize());
        entity.setFileData(file.getBytes());

        repo.save(entity);
    }

    public List<AttachmentListDTO> listByTask(Long taskId) {

        return repo.findByTaskId(taskId)
                .stream()
                .map(a -> new AttachmentListDTO(
                        a.getId(),
                        a.getTaskId(),
                        a.getUploaderId(),
                        a.getOriginalName(),
                        a.getMimeType(),
                        a.getFileSizeBytes(),
                        a.getUploadedAt()
                ))
                .collect(Collectors.toList());
    }

    public TaskAttachmentEntity getAttachment(Long id) {
        return repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Attachment not found"));
    }

    public void delete(Long id) {
        repo.deleteById(id);
    }
}