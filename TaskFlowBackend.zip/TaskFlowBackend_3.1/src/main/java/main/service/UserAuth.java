/* ═══════════════════════════════════════
            UserAuth.java
═══════════════════════════════════════ */
// UserAuth.java
package main.service;

import main.config.JwtUtil;
import main.dto.AuthResponseDTO;
import main.dto.UserRequestDTO;
import main.dto.UserRoleChangeRequestDto;
import main.dto.UserIdNameResponseDTO;
import main.entity.Role;
//import main.entity.AuthResponse;
import main.entity.UserEntity;
//import main.entity.UserDTO;
import main.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class UserAuth {

    @Autowired private UserRepository userRepository;
    @Autowired private PasswordEncoder passwordEncoder;
    @Autowired private JwtUtil jwtUtil;

    /**
     * Register a new user.
     * Returns success message or error string.
     */
    public String register(UserRequestDTO dto) {
        // Check if email already exists in active accounts
        if (userRepository.findByEmail(dto.getEmail()).isPresent()) {
            return "EMAIL_EXISTS";
        }

        // Check if email exists but account is marked deleted
        if (userRepository.findByEmailAndIsDeleteFalse(dto.getEmail()).isPresent()) {
            return "EMAIL_EXISTS_BUT_ACCOUNT_CLOSE";
        }

        UserEntity user = new UserEntity();
        user.setFullname(dto.getFullname());
        user.setEmail(dto.getEmail());
        user.setPassword(passwordEncoder.encode(dto.getPassword())); // BCrypt hash

        // If this is the first user in the system, assign ADMIN role
        if (userRepository.count() == 0) {
            user.setRole(Role.ADMIN);
        } else {
            user.setRole(Role.MEMBER); // default role for subsequent users
        }

        user = userRepository.save(user);
        return "OK:" + user.getId();
    }

    /**
     * Login — returns AuthResponse on success, null on failure.
     */
    public AuthResponseDTO login(String email, String rawPassword) {
        Optional<UserEntity> opt = userRepository.findByEmailAndIsDeleteFalse(email);           //   change findByEmail
        if (opt.isPresent()) {
            UserEntity user = opt.get();
            if (passwordEncoder.matches(rawPassword, user.getPassword())) {
//                String token = jwtUtil.generateToken(email);
            	
            	String token = jwtUtil.generateToken(user.getEmail(), user.getRole().name());  // Added
                
            	return new AuthResponseDTO(token, "Login Successful",
                        user.getEmail(), user.getFullname(),user.getId(),user.getRole());
            }
        }
        return null;
    }
    
    public List<UserIdNameResponseDTO> findAllByRole(Role role){
    	List<UserIdNameResponseDTO> list=new ArrayList<>();
    	List<UserEntity> userList= userRepository.findAllByRole(role);
    	for (UserEntity user : userList) {
			list.add(new UserIdNameResponseDTO(user.getId(),user.getFullname()));
		}
    	return list;
    }
    
    public List<UserIdNameResponseDTO> findAllUsers(){
    	List<UserIdNameResponseDTO> list=new ArrayList<>();
    	List<UserEntity> userList= userRepository.findAll();
    	for (UserEntity user : userList) {
			list.add(new UserIdNameResponseDTO(user.getId(),user.getFullname()));
		}
    	return list;
    }
    
    @PreAuthorize("hasRole('ADMIN')")
    public String changeUserRole(UserRoleChangeRequestDto dto) {
        return userRepository.findById(dto.getUserId())
                .map(user -> {
                    user.setRole(dto.getNewRole());
                    userRepository.save(user);
                    return "Role updated successfully for user ID " + user.getId();
                })
                .orElseThrow(() -> new IllegalArgumentException("User not found with ID: " + dto.getUserId()));
    }
    	
}