/* ═══════════════════════════════════════
                SubtaskService.java
   ═══════════════════════════════════════ */

package main.service;

import main.dto.SubtaskResponseDTO;
import main.dto.SubtaskSummaryDTO;
import main.dto.*;
import main.entity.*;
import main.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class SubtaskService {

    private final SubtaskRepository subtaskRepo;
    private final TaskRepository taskRepo;
    private final UserRepository userRepo;

    public SubtaskService(SubtaskRepository subtaskRepo,
                          TaskRepository taskRepo,
                          UserRepository userRepo) {
        this.subtaskRepo = subtaskRepo;
        this.taskRepo = taskRepo;
        this.userRepo = userRepo;
    }

    /* ═══════════════════════════════════════
                    GET ALL
    ═══════════════════════════════════════ */
    public List<SubtaskResponseDTO> getByTask(Long taskId) {
        return subtaskRepo.findByTaskIdOrderByCreatedAtAsc(taskId)
                .stream().map(this::mapToDTO).toList();
    }

    /* ═══════════════════════════════════════
                    CREATE
    ═══════════════════════════════════════ */
    public SubtaskResponseDTO create(Long taskId, SubtaskRequestDTO dto, String email) {

        TaskEntity task = taskRepo.findById(taskId)
                .orElseThrow(() -> new RuntimeException("Task not found"));

        UserEntity creator = userRepo.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        UserEntity assignedUser = null;
        if (dto.getAssignedTo() != null) {
            assignedUser = userRepo.findById(dto.getAssignedTo())
                    .orElseThrow(() -> new RuntimeException("Assigned user not found"));
        }

        SubtaskEntity subtask = new SubtaskEntity();
        subtask.setTask(task);
        subtask.setTitle(dto.getTitle());
        subtask.setCreatedBy(creator);
        subtask.setAssignedTo(assignedUser);

        return mapToDTO(subtaskRepo.save(subtask));
    }

    /* ═══════════════════════════════════════
                    TOGGLE
    ═══════════════════════════════════════ */
    public SubtaskResponseDTO toggle(Long id) {

        SubtaskEntity s = subtaskRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Subtask not found"));

        if (s.isComplete()) {
            s.setComplete(false);
            s.setCompletedAt(null);
        } else {
            s.setComplete(true);
            s.setCompletedAt(LocalDateTime.now());
        }

        return mapToDTO(subtaskRepo.save(s));
    }

    /* ═══════════════════════════════════════
                    UPDATE
    ═══════════════════════════════════════ */
    public SubtaskResponseDTO update(Long id, SubtaskRequestDTO dto) {

        SubtaskEntity s = subtaskRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Subtask not found"));

        s.setTitle(dto.getTitle());

        if (dto.getAssignedTo() != null) {
            UserEntity user = userRepo.findById(dto.getAssignedTo())
                    .orElseThrow(() -> new RuntimeException("User not found"));
            s.setAssignedTo(user);
        } else {
            s.setAssignedTo(null);
        }

        return mapToDTO(subtaskRepo.save(s));
    }

    /* ═══════════════════════════════════════
                    DELETE
    ═══════════════════════════════════════ */
    @Transactional
    public void delete(Long id, String email) {

        SubtaskEntity s = subtaskRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Subtask not found"));

        if (!s.getCreatedBy().getEmail().equals(email)) {
            throw new RuntimeException("Not authorized");
        }

        subtaskRepo.delete(s);
    }

    /* ═══════════════════════════════════════
                    SUMMARY
    ═══════════════════════════════════════ */
    public SubtaskSummaryDTO summary(Long taskId) {

        int total = subtaskRepo.countByTaskId(taskId);
        int completed = subtaskRepo.countByTaskIdAndIsCompleteTrue(taskId);

        return new SubtaskSummaryDTO(total, completed);
    }

    /* ═══════════════════════════════════════
                    MAPPER
    ═══════════════════════════════════════ */
    private SubtaskResponseDTO mapToDTO(SubtaskEntity s) {

        SubtaskResponseDTO dto = new SubtaskResponseDTO();
        dto.setId(s.getId());
        dto.setTaskId(s.getTask().getId());
        dto.setTitle(s.getTitle());
        dto.setComplete(s.isComplete());
        dto.setCreatedBy(s.getCreatedBy().getId());

        if (s.getAssignedTo() != null) {
            dto.setAssignedTo(s.getAssignedTo().getId());
            dto.setAssignedToName(s.getAssignedToName());
        }

        dto.setCreatedAt(s.getCreatedAt());
        dto.setCompletedAt(s.getCompletedAt());

        return dto;
    }
}