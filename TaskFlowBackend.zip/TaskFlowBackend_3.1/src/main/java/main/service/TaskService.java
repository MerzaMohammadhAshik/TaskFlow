/* ═══════════════════════════════════════
            TaskService.java
═══════════════════════════════════════ */
package main.service;

import main.dto.TaskRequestDTO;
import main.dto.TaskResponseDTO;
import main.dto.TaskSummaryDTO;
import main.entity.ActionCode;
import main.entity.TaskEntity;
import main.entity.TaskPriority;
import main.entity.TaskStatus;
import main.entity.UserEntity;
import main.repository.TaskRepository;
import main.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class TaskService {

    @Autowired private TaskRepository taskRepository;
    @Autowired private UserRepository userRepository;
    @Autowired private ActivityLogService activityLogService;

    // ── Helper ────────────────────────────────────────────
    private UserEntity requireUser(String email) {
        return userRepository.findByEmailAndIsDeleteFalse(email)         //   change findByEmail
                .orElseThrow(() -> new RuntimeException("User not found: " + email));
    }
   
    public boolean existsById(Long id) {
    	return taskRepository.existsById(id);
    }
    // ── CRUD ──────────────────────────────────────────────
    @Transactional(readOnly = true)
    public TaskSummaryDTO getTaskSummary(String email) {

        long total = taskRepository.countTotal(email);

        long todo = taskRepository.countTodo(email);
        long inProgress = taskRepository.countInProgress(email);
        long done = taskRepository.countDone(email);

        long high = taskRepository.countHigh(email);
        long medium = taskRepository.countMedium(email);
        long low = taskRepository.countLow(email);

        long overdue = taskRepository.countOverdue(email);

        LocalDateTime sevenDaysAgo = LocalDateTime.now().minusDays(7);

        long thisWeek = taskRepository.countTasksThisWeek(email, sevenDaysAgo);
        
        double completionRate = 0.0;

        if (total > 0) {
            completionRate = ((double) done / total) * 100.0;
            completionRate = Math.round(completionRate * 10.0) / 10.0; // 1 decimal
        }

        TaskSummaryDTO.StatusSummary statusSummary =new TaskSummaryDTO.StatusSummary((int) todo, (int) inProgress, (int) done);

        TaskSummaryDTO.PrioritySummary prioritySummary =new TaskSummaryDTO.PrioritySummary((int) high, (int) medium, (int) low);

        TaskSummaryDTO summary =new TaskSummaryDTO((int) total, statusSummary, prioritySummary);

        summary.setCompletionRate(completionRate);
        summary.setOverdueCount((int) overdue);
        summary.setTasksThisWeek((int) thisWeek);

        return summary;
    }
    
    public List<TaskResponseDTO> getAllTasksAssignToMe(String email) {
        List<TaskResponseDTO> taskRes = new LinkedList<>();
        
        // Fetch tasks for the given user
        List<TaskEntity> tasks = taskRepository.findByAssignedToId(requireUser(email).getId());  // Change findByAssignedTo   and requireUser(email) => requireUser(email).getId()
        
        // Convert each Task entity into a TaskResponse DTO
        for (TaskEntity task : tasks) {
            TaskResponseDTO response = new TaskResponseDTO(
                task.getId(),
                task.getTitle(),
                task.getDescription(),
                task.getDueDate(),
                task.getStatus(),
                task.getUser() != null ? task.getUser().getId() : null,
//                      task.getAssignedTo() != null ? task.getAssignedTo().getId() : null,
//                      task.getAssignedTo() != null ? task.getAssignedTo().getFullname():null,
                      task.getAssignedToId(),
                      task.getAssignedToName(),
                task.getPriority(),
                task.getCreatedAt(),
                task.getUpdatedAt()
            );
            taskRes.add(response);
        }
        
        return taskRes;
    }
    
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER','MEMBER','VIEWER')")
    public List<TaskResponseDTO> getAllTasks(String email) {
        List<TaskResponseDTO> taskRes = new LinkedList<>();
        
        // Fetch tasks for the given user
        List<TaskEntity> tasks = taskRepository.findByUser(requireUser(email));
        
        // Convert each Task entity into a TaskResponse DTO
        for (TaskEntity task : tasks) {
            TaskResponseDTO response = new TaskResponseDTO(
                task.getId(),
                task.getTitle(),
                task.getDescription(),
                task.getDueDate(),
                task.getStatus(),
                task.getUser() != null ? task.getUser().getId() : null,
//                task.getAssignedTo() != null ? task.getAssignedTo().getId() : null,
//                task.getAssignedTo() != null ? task.getAssignedTo().getFullname():null,
                task.getAssignedToId(),
                task.getAssignedToName(),
                task.getPriority(),
                task.getCreatedAt(),
                task.getUpdatedAt()
            );
            taskRes.add(response);
        }
        
        return taskRes;
    }

    @PreAuthorize("hasAnyRole('ADMIN','MANAGER','MEMBER')")
    public TaskEntity createTask(TaskRequestDTO dto, String email) {
        // Validate required fields
        if (dto.getTitle() == null || dto.getTitle().isBlank()) {
            throw new IllegalArgumentException("Title is required");
        }
        if (dto.getDueDate() == null) {
            throw new IllegalArgumentException("Due date is required");
        }

        TaskEntity task = new TaskEntity();
        task.setTitle(dto.getTitle());
        task.setDescription(dto.getDescription());
        task.setDueDate(dto.getDueDate());

        // Set priority (default MEDIUM if null)
        task.setPriority(dto.getPriority() != null ? dto.getPriority() : TaskPriority.MEDIUM);

        // Set assigned user if provided
        if (dto.getAssignedToId() != null) {
            UserEntity assignedTo = userRepository.findById(dto.getAssignedToId())
                    .orElseThrow(() -> new IllegalArgumentException("Assigned user not found"));
            task.setAssignedToId(assignedTo.getId());   // change task.setAssignedTo(assignedTo);
        }

        // Set status (default TODO if null)
        task.setStatus(dto.getStatus() != null ? dto.getStatus() : TaskStatus.TODO);

        // Set owner user
        task.setUser(requireUser(email));

        task = taskRepository.save(task);
        
        activityLogService.logAction(
                task.getId(),
                email,
                ActionCode.TASK_CREATED,
                requireUser(email).getFullname()+ " created task \"" + task.getTitle() + "\""
        );
        return task;
    }
//    getTaskAssignToMe

    public Optional<TaskEntity> getTaskById(Long id, String email) {
        return taskRepository.findByIdAndUser(id, requireUser(email));
    }
    
    public void deleteTask(Long id, String email) {
        TaskEntity task = getTaskById(id, email)
                .orElseThrow(() -> new RuntimeException("Task not found or access denied"));
        activityLogService.logAction(
                0l, // task_id must be NULL
                email,
                ActionCode.TASK_DELETED,
                requireUser(email).getFullname() + " deleted task \"" + task.getTitle() + "\""
        );
        taskRepository.delete(task);
    }
    @Transactional
    public TaskEntity updateTask(Long taskId, TaskRequestDTO dto, String email) {

        TaskEntity task = taskRepository.findById(taskId)
                .orElseThrow(() -> new RuntimeException("Task not found"));

        boolean isOwner = task.getUser().getEmail().equals(email);
        UserEntity taskAssignUser=new UserEntity();
        if(task.getAssignedToId() != null&&userRepository.existsById(task.getAssignedToId())) {
        	taskAssignUser=userRepository.findById(task.getAssignedToId()).get();
        }
        boolean isAssignedUser = task.getAssignedToId() != null &&       //change  task.getAssignedTo()
//                task.getAssignedTo().getEmail().equals(email); change
        		  taskAssignUser.getEmail().equals(email);

        if (!isOwner && !isAssignedUser) {
            throw new RuntimeException("Task not found or access denied");
        }

        UserEntity actor = requireUser(email);

        // ===============================
        // 🔹 ASSIGNED USER (Status Only)
        // ===============================
        if (isAssignedUser && !isOwner) {

            if (dto.getStatus() == null) {
                throw new IllegalArgumentException("Only status can be updated");
            }

            if (!task.getStatus().equals(dto.getStatus())) {

                task.setStatus(dto.getStatus());

                activityLogService.logAction(
                        task.getId(),
                        email,
                        ActionCode.TASK_STATUS_CHANGED,
                        actor.getFullname() +
                                " changed status of \"" +
                                task.getTitle() +
                                "\" to " + dto.getStatus()
                );
            }

            return taskRepository.save(task);
        }

        // ===============================
        // 🔹 OWNER (Full Update)
        // ===============================

        if (dto.getTitle() == null || dto.getTitle().isBlank()) {
            throw new IllegalArgumentException("Title is required");
        }
        task.setTitle(dto.getTitle());

        if (dto.getDescription() != null) {
            task.setDescription(dto.getDescription());
        }

        if (dto.getDueDate() == null) {
            throw new IllegalArgumentException("Due date is required");
        }
        task.setDueDate(dto.getDueDate());

        // 🔹 STATUS CHANGE
        if (dto.getStatus() != null &&
                !task.getStatus().equals(dto.getStatus())) {

            task.setStatus(dto.getStatus());

            activityLogService.logAction(
                    task.getId(),
                    email,
                    ActionCode.TASK_STATUS_CHANGED,
                    actor.getFullname() +
                            " changed status of \"" +
                            task.getTitle() +
                            "\" to " + dto.getStatus()
            );
        }

        // 🔹 ASSIGNMENT CHANGE
        if (dto.getAssignedToId() != null) {

            UserEntity newAssignee = userRepository.findById(dto.getAssignedToId())
                    .orElseThrow(() ->
                            new IllegalArgumentException("Assigned user not found"));

            if (!Objects.equals(task.getAssignedToId(), newAssignee)) {  // change getAssignedTo

                task.setAssignedToId(newAssignee.getId());

                activityLogService.logAction(
                        task.getId(),
                        email,
                        ActionCode.TASK_ASSIGNED,
                        actor.getFullname() +
                                " assigned \"" +
                                task.getTitle() +
                                "\" to " +
                                newAssignee.getFullname()
                );
            }
        }

        // 🔹 PRIORITY CHANGE
        if (dto.getPriority() != null &&
                !task.getPriority().equals(dto.getPriority())) {

            task.setPriority(dto.getPriority());

            activityLogService.logAction(
                    task.getId(),
                    email,
                    ActionCode.TASK_PRIORITY_CHANGED,
                    actor.getFullname() +
                            " changed priority of \"" +
                            task.getTitle() +
                            "\" to " +
                            dto.getPriority()
            );
        }

        return taskRepository.save(task);
    }
    

}