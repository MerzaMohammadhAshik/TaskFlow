/* ═══════════════════════════════════════
            CommentsService.java
═══════════════════════════════════════ */
// TaskService.java
package main.service;

import main.dto.CommentRequestDTO;
import main.dto.CommentResponseDTO;
import main.dto.TaskRequestDTO;
import main.entity.TaskEntity;
import main.entity.ActionCode;
import main.entity.CommentEntity;
//import main.entity.TaskDTO;
import main.entity.TaskStatus;
import main.entity.UserEntity;
import main.repository.CommentsRepository;
import main.repository.TaskRepository;
import main.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CommentsService {

    @Autowired private TaskRepository taskRepository;
    @Autowired private UserRepository userRepository;
    @Autowired private CommentsRepository taskCommentsRepository;
    @Autowired private ActivityLogService activityLogService;

    // ── Helper ────────────────────────────────────────────
    private UserEntity requireUser(String email) {
        return userRepository.findByEmailAndIsDeleteFalse(email)		//   change findByEmail
                .orElseThrow(() -> new RuntimeException("User not found: " + email));
    }

    // ── CRUD ──────────────────────────────────────────────

//    public List<TaskComments> getAllComments(Long taskId) {
//        return taskCommentsRepository.findAllByTask_IdOrderByCreatedAtAsc(taskId);
//    }
    
    public List<CommentRequestDTO> getAllComments(Long taskId) {

        List<CommentEntity> comments =
//                taskCommentsRepository.findAllCommentsWithAuthor(taskId);
        		  taskCommentsRepository.findAllByTaskOrderByCreatedAtAsc(taskId);

        return comments.stream()
                .map(c -> new CommentRequestDTO(
                        c.getId(),
                        c.getBody(),
//                        c.getAuthor().getFullname(), // now safe ✅
//                        c.getAuthor().getId(),
                        c.getAuthorName(),
                        c.getAuthorId(),
                        c.getCreatedAt()
                ))
                .toList();
    }

    public CommentRequestDTO createTaskComment(CommentResponseDTO dto,
            Long taskid,
            String authorEmail) {

// 1️⃣ Get Task safely
TaskEntity task = taskRepository.findById(taskid)
.orElseThrow(() -> new RuntimeException("Task not found"));

// 2️⃣ Get User from email
UserEntity author = requireUser(authorEmail);

// 3️⃣ Create Comment
CommentEntity comment = new CommentEntity();
comment.setAuthor(author);
comment.setBody(dto.getBody());
comment.setTask(task.getId());    // change task =>  task.getId()

System.out.println("service");

// 4️⃣ Save Comment
CommentEntity saved = taskCommentsRepository.save(comment);
activityLogService.logAction(
        task.getId(),
        author.getEmail(),
        ActionCode.COMMENT_ADDED,
        author.getFullname() + " commented on \"" + task.getTitle() + "\""
);
// 5️⃣ Return Response DTO
return new CommentRequestDTO(
saved.getId(),
saved.getBody(),
//saved.getAuthor().getFullname(), // now safe ✅
//saved.getAuthor().getId(),
saved.getAuthorName(),
saved.getAuthorId(),
saved.getCreatedAt()
);
}

    public void deleteTaskComment(Long id, String email) {
        CommentEntity comment = taskCommentsRepository.findByIdAndAuthor_Email(id, email)
                .orElseThrow(() -> new RuntimeException("Comment not found or access denied"));
        taskCommentsRepository.delete(comment);
    }
}