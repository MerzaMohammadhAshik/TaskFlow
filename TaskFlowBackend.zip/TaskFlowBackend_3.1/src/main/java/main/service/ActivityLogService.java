/* ═══════════════════════════════════════
            ActivityLogService.java
═══════════════════════════════════════ */
package main.service;

import main.entity.ActionCode;
import main.entity.ActivityLogEntity;
import main.entity.TaskEntity;
import main.entity.UserEntity;
import main.repository.ActivityLogRepository;
import main.repository.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class ActivityLogService {

    @Autowired
    private ActivityLogRepository repository;

    @Autowired
    private UserRepository userRepository;

    // ============================
    // CENTRAL LOG METHOD
    // ============================
    @Transactional
    public void logAction(
            Long task,
            String actorEmail,
            ActionCode actionCode,
            String message
    ) {
    	System.out.println(task);

        UserEntity actor = userRepository
                .findByEmailAndIsDeleteFalse(actorEmail)          // change  findByEmail
                .orElseThrow(() -> new RuntimeException("User not found"));

        ActivityLogEntity log = new ActivityLogEntity();
        log.setTaskId(task); // can be null for deleted
        log.setActor(actor);
        log.setActionCode(actionCode);
        log.setMessage(message);

        repository.save(log);
    }

    // ============================
    // FETCH RECENT
    // ============================
    public List<ActivityLogEntity> getRecentActivity(String email) {
        return repository.findRecentActivityForUser(
                email,
                PageRequest.of(0, 20)
        );
    }
}