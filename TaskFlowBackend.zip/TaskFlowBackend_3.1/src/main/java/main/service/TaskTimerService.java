/* ═══════════════════════════════════════
        TaskTimerService.java
═══════════════════════════════════════ */

package main.service;

import main.entity.*;
import main.repository.*;

import org.springframework.stereotype.Service;

import java.time.*;
import java.util.List;

@Service
public class TaskTimerService {

    private final ActiveTimerRepository activeRepo;
    private final TaskTimeLogRepository logRepo;
    private final UserRepository userRepo;

    public TaskTimerService(ActiveTimerRepository activeRepo,
                            TaskTimeLogRepository logRepo,
                            UserRepository userRepo) {

        this.activeRepo = activeRepo;
        this.logRepo = logRepo;
        this.userRepo = userRepo;
    }

    // ✅ GET USER ID FROM EMAIL
    private Long getUserId(String email) {
        return userRepo.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("USER_NOT_FOUND"))
                .getId();
    }

    public LocalDateTime fetchBeforeTime(Long taskId, String email) {

        UserEntity user = userRepo.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User Not Found"));

        activeRepo.findByTaskIdAndUserId(taskId, user.getId())
                .orElseThrow(() -> new RuntimeException("No Previous time found"));

        if (activeRepo.findByTaskIdAndUserId(taskId, user.getId()).get() != null) {

            ActiveTimerEntity active = activeRepo
                    .findByTaskIdAndUserId(taskId, user.getId())
                    .get();

            return active.getStartTime();
        }

        return null;
    }

    // ▶ START TIMER
    public void startTimer(Long taskId, String email) {

        Long userId = getUserId(email);

        if (activeRepo.findByTaskIdAndUserId(taskId, userId).isPresent()) {
            throw new RuntimeException("TIMER_ALREADY_RUNNING");
        }

        ActiveTimerEntity timer = new ActiveTimerEntity();
        timer.setTaskId(taskId);
        timer.setUserId(userId);
        timer.setStartTime(LocalDateTime.now());

        activeRepo.save(timer);
    }

    // ⏹ STOP TIMER
    public void stopTimer(Long taskId, String email) {

        UserEntity user = userRepo.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("USER_NOT_FOUND"));

        Long userId = getUserId(email);

        ActiveTimerEntity timer = activeRepo
                .findByTaskIdAndUserId(taskId, userId)
                .orElseThrow(() -> new RuntimeException("NO_ACTIVE_TIMER"));

        long minutes = Duration
                .between(timer.getStartTime(), LocalDateTime.now())
                .toMinutes();

        TaskTimeLogEntity log = new TaskTimeLogEntity();
        log.setTaskId(taskId);
        log.setLoggedBy(userId);
        log.setLoggedusername(user.getFullname());
        log.setDurationMinutes((int) minutes);
        log.setLogDate(LocalDate.now());
        log.setIsManual(false);

        logRepo.save(log);
        activeRepo.delete(timer);
    }

    // 🔄 ACTIVE TIMER
    public ActiveTimerEntity getActiveTimer(Long taskId, String email) {
        Long userId = getUserId(email);
        return activeRepo.findByTaskIdAndUserId(taskId, userId).orElse(null);
    }

    // ➕ MANUAL LOG
    public void addManual(Long taskId, String email, int duration, String date, String note) {

        UserEntity user = userRepo.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("USER_NOT_FOUND"));

        Long userId = getUserId(email);

        TaskTimeLogEntity log = new TaskTimeLogEntity();
        log.setTaskId(taskId);
        log.setLoggedBy(userId);
        log.setLoggedusername(user.getFullname());
        log.setDurationMinutes(duration);
        log.setLogDate(LocalDate.parse(date));
        log.setNote(note);
        log.setIsManual(true);

        logRepo.save(log);
    }

    // 📜 GET LOGS
    public List<TaskTimeLogEntity> getLogs(Long taskId) {
        return logRepo.findByTaskIdOrderByLogDateDesc(taskId);
    }

    // 🧮 TOTAL
    public int getTotal(Long taskId) {

        return logRepo.findByTaskIdOrderByLogDateDesc(taskId)
                .stream()
                .mapToInt(l -> l.getDurationMinutes() == null ? 0 : l.getDurationMinutes())
                .sum();
    }

    // ❌ DELETE
    public void delete(Long id) {

        TaskTimeLogEntity log = logRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("NOT_FOUND"));

        if (!log.getIsManual()) {
            throw new RuntimeException("CANNOT_DELETE_TIMER_LOG");
        }

        logRepo.delete(log);
    }
}