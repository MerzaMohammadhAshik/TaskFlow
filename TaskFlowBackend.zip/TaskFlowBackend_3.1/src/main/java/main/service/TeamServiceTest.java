/* ═══════════════════════════════════════
            TeamServiceTest.java
═══════════════════════════════════════ */
package main.service;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class TeamServiceTest {

    private static final Logger logger = LoggerFactory.getLogger(TeamServiceTest.class);

    @PreAuthorize("hasRole('ADMIN') or hasRole('MANAGER')")
    public String createTeam() {
        logger.info("createTeam run work");
        // existing logic to create team
        return "createTeam run success";
    }
}