/* ═══════════════════════════════════════
            TeamService.java
════════════════════════════════════════ */
package main.service;

import main.dto.TeamRequestDTO;
import main.dto.TeamResponseDto;
import main.dto.UserResponseDTO;
import main.entity.TeamEntity;
import main.entity.TeamMemberEntity;
import main.entity.TeamMemberId;
import main.entity.UserEntity;
import main.entity.Role;
import main.repository.TeamRepository;
import main.repository.TeamMemberRepository;
import main.repository.UserRepository;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class TeamService {

    private final TeamRepository teamRepo;
    private final TeamMemberRepository memberRepo;
    private final UserRepository userRepo;

    public TeamService(TeamRepository teamRepo, TeamMemberRepository memberRepo, UserRepository userRepo) {
        this.teamRepo = teamRepo;
        this.memberRepo = memberRepo;
        this.userRepo = userRepo;
    }
    
    
    // Mapper utility
    private TeamResponseDto toResponseDto(TeamEntity team) {

        UserResponseDTO managerDto = null;

        if (team.getManager() != null) {
            managerDto = mapUser(team.getManager());
        }

        List<UserResponseDTO> memberDtos = team.getMembers() != null
                ? team.getMembers()
                        .stream()
                        .map(m -> mapUser(m.getUser()))
                        .toList()
                : List.of();

        List<Long> taskIds = team.getTasks() != null
                ? team.getTasks()
                        .stream()
                        .map(t -> t.getId())
                        .toList()
                : List.of();

        return new TeamResponseDto(
                team.getId(),
                team.getName(),
                team.getDescription(),
                managerDto,
                team.getCreatedAt(),
                memberDtos,
                taskIds
        );
    }
    
    private UserResponseDTO mapUser(UserEntity user) {

        return new UserResponseDTO(
                user.getId(),
                user.getFullname(),
                user.getEmail(),
                user.getRole(),
                user.getCreatedAt()
        );

    }
    
    

    @PreAuthorize("hasRole('ADMIN') or hasRole('MANAGER')")
    public TeamResponseDto createTeam(TeamRequestDTO dto) {
        if (teamRepo.existsByName(dto.getName())) {
            throw new IllegalArgumentException("Team name already exists: " + dto.getName());
        }

        UserEntity manager = userRepo.findById(dto.getManagerId())
                .orElseThrow(() -> new IllegalArgumentException("Manager not found"));

        TeamEntity team = new TeamEntity();
        team.setName(dto.getName());
        team.setDescription(dto.getDescription());
        team.setManager(manager);

        TeamEntity saved = teamRepo.save(team);
        return toResponseDto(saved);
    }
    
    @Transactional
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER','MEMBER','VIEWER')")
    public List<TeamResponseDto> getTeamsForUser(String email) {
        UserEntity user = userRepo.findByEmail(email)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));

        List<TeamEntity> teams;
        if (user.getRole() == Role.ADMIN) {
            teams = teamRepo.findAll();
        } else if (user.getRole() == Role.MANAGER) {
            teams = teamRepo.findByManagerId(user.getId());
        } else {
            teams = memberRepo.findByUser_Id(user.getId())
                    .stream()
                    .map(TeamMemberEntity::getTeam)
                    .toList();
        }
        return teams.stream().map(this::toResponseDto).toList();
    }
    
    @Transactional
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER','MEMBER','VIEWER')")
    public Optional<TeamResponseDto> getTeamDetail(Long id) {
        return teamRepo.findById(id).map(this::toResponseDto);
    }

/* ═══════════════════════════════════════
    addMember()
═══════════════════════════════════════ */
@PreAuthorize("hasRole('ADMIN') or hasRole('MANAGER')")
@Transactional
public String addMember(Long teamId, Long userId) {

TeamEntity team = teamRepo.findById(teamId)
    .orElseThrow(() -> new RuntimeException("Team not found"));

UserEntity user = userRepo.findById(userId)
    .orElseThrow(() -> new RuntimeException("User not found"));

TeamMemberId id = new TeamMemberId(teamId, userId);

TeamMemberEntity member = new TeamMemberEntity();
//member.setId(id);
member.setTeam(team);
member.setUser(user);

memberRepo.save(member);

return "Add Member Successfull";
}   

/* ═══════════════════════════════════════
removeMember()
═══════════════════════════════════════ */
@PreAuthorize("hasRole('ADMIN') or hasRole('MANAGER')")
@Transactional
public void removeMember(Long teamId, Long userId) {

TeamMemberId id = new TeamMemberId(teamId, userId);

if (!memberRepo.existsById(id)) {
throw new RuntimeException("Member not found in team");
}

memberRepo.deleteById(id);
}

    @PreAuthorize("hasRole('ADMIN') or hasRole('MANAGER')")
    @Transactional
    public void deleteTeam(Long id) {
        teamRepo.deleteById(id);
    }


    
}