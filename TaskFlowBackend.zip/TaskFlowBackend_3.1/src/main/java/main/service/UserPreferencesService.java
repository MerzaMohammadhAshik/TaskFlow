/* ═══════════════════════════════════════
        UserPreferencesService.java
═══════════════════════════════════════ */
package main.service;

import main.dto.UserPreferencesDTO;
import main.entity.UserEntity;
import main.entity.UserPreferencesEntity;
import main.repository.UserPreferencesRepository;
import main.repository.UserRepository;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserPreferencesService {

	private final UserPreferencesRepository preferencesRepo;
	private final UserRepository userRepo;

	public UserPreferencesService(UserPreferencesRepository preferencesRepo, UserRepository userRepo) {
		this.preferencesRepo = preferencesRepo;
		this.userRepo = userRepo;
	}

	@Transactional
	public UserPreferencesDTO getPreferences(String email) {

		UserEntity user = userRepo.findByEmail(email).orElseThrow(() -> new IllegalArgumentException("User not found"));

		UserPreferencesEntity pref = preferencesRepo.findByUserId(user.getId())
		        .orElseGet(() -> {
		            UserPreferencesEntity newPref = new UserPreferencesEntity();
		            newPref.setUser(user); // ✅ MUST SET
		            return preferencesRepo.save(newPref);
		        });

		return mapToDTO(pref);
	}

	@Transactional
	public UserPreferencesDTO updatePreferences(String email, UserPreferencesDTO dto) {
		UserEntity user = userRepo.findByEmail(email).orElseThrow(() -> new IllegalArgumentException("User not found"));

		UserPreferencesEntity pref = preferencesRepo.findByUserId(user.getId()).orElse(new UserPreferencesEntity(user));

		// Update fields
		if (dto.getTheme() != null)
			pref.setTheme(dto.getTheme());
		pref.setNotifyAssigned(dto.isNotifyAssigned());
		pref.setNotifyComment(dto.isNotifyComment());
		pref.setNotifySubtask(dto.isNotifySubtask());
		pref.setNotifyOverdue(dto.isNotifyOverdue());
		pref.setNotifyTeam(dto.isNotifyTeam());
		if (dto.getAvatarColour() != null)
			pref.setAvatarColour(dto.getAvatarColour());
		if (dto.getBio() != null)
			pref.setBio(dto.getBio());

		preferencesRepo.save(pref);

		return mapToDTO(pref);
	}

	private UserPreferencesDTO mapToDTO(UserPreferencesEntity pref) {
		UserPreferencesDTO dto = new UserPreferencesDTO();
		dto.setTheme(pref.getTheme());
		dto.setNotifyAssigned(pref.isNotifyAssigned());
		dto.setNotifyComment(pref.isNotifyComment());
		dto.setNotifySubtask(pref.isNotifySubtask());
		dto.setNotifyOverdue(pref.isNotifyOverdue());
		dto.setNotifyTeam(pref.isNotifyTeam());
		dto.setAvatarColour(pref.getAvatarColour());
		dto.setBio(pref.getBio());
		return dto;
	}

	/*
	 * ───────────────────────────────── Update Bio & Avatar Colour
	 * ─────────────────────────────────
	 */
	@Transactional
	public void updateProfileExtras(String email, String avatarColour, String bio) {

	    UserEntity user = userRepo.findByEmail(email)
	            .orElseThrow(() -> new IllegalArgumentException("User not found"));

	    UserPreferencesEntity pref = preferencesRepo.findByUserId(user.getId())
	            .orElseGet(() -> {
	                UserPreferencesEntity newPref = new UserPreferencesEntity();
	                newPref.setUser(user); // ✅ FIX
	                return newPref;
	            });

	    if (avatarColour != null) {
	        pref.setAvatarColour(avatarColour);
	    }

	    if (bio != null) {
	        pref.setBio(bio);
	    }

	     mapToDTO(preferencesRepo.save(pref));
	}
}