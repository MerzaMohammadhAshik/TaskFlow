/* ═══════════════════════════════════════
            UserService.java
═══════════════════════════════════════ */
package main.service;

import main.dto.PasswordChangeRequestDto;
import main.dto.ProfileUpdateRequestDto;
import main.dto.UserResponseDTO;
import main.dto.UserRoleChangeRequestDto;
import main.entity.Role;
import main.entity.UserEntity;
import main.repository.UserRepository;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class UserService {

	private final UserRepository userRepository;

	private final PasswordEncoder passwordEncoder;
	
	private UserPreferencesService preference;

	public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder,UserPreferencesService preference) {
		this.userRepository = userRepository;
		this.passwordEncoder = passwordEncoder;
		this.preference=preference;
	}

	/*
	 * ───────────────────────────────── Get All Users
	 * ─────────────────────────────────
	 */

	@PreAuthorize("hasRole('ADMIN')")
	@Transactional
	public List<UserResponseDTO> getAllUsers() {

		return userRepository
				.findByIsDeleteFalse().stream().map(user -> new UserResponseDTO(user.getId(), user.getFullname(),
						user.getEmail(), user.getRole(), user.getCreatedAt(), user.isActive()))
				.collect(Collectors.toList());
	}

	/*
	 * ───────────────────────────────── Change User Role
	 * ─────────────────────────────────
	 */

	@PreAuthorize("hasRole('ADMIN')")
	public String changeUserRole(UserRoleChangeRequestDto dto) {

		return userRepository.findById(dto.getUserId()).map(user -> {
			user.setRole(dto.getNewRole());
			userRepository.save(user);
			return "Role updated successfully for user ID " + user.getId();
		}).orElseThrow(() -> new IllegalArgumentException("User not found with ID: " + dto.getUserId()));
	}

	/*
	 * ───────────────────────────────── Activate / Deactivate User
	 * ─────────────────────────────────
	 */

	@PreAuthorize("hasRole('ADMIN')")
	public String toggleUserStatus(Long userId) {

		return userRepository.findById(userId).map(user -> {

			user.setActive(!user.isActive());

			userRepository.save(user);

			return user.isActive() ? "User Activated Successfully" : "User Deactivated Successfully";

		}).orElseThrow(() -> new IllegalArgumentException("User not found with ID: " + userId));
	}

	/*
	 * ───────────────────────────────── Soft Delete User
	 * ─────────────────────────────────
	 */

	@PreAuthorize("hasRole('ADMIN')")
	public String deleteUser(Long userId) {

		return userRepository.findById(userId).map(user -> {

			user.setDelete(true);

			userRepository.save(user);

			return "User deleted successfully";

		}).orElseThrow(() -> new IllegalArgumentException("User not found with ID: " + userId));
	}

	/*
	 * ───────────────────────────────── User Count For Dashboard
	 * ─────────────────────────────────
	 */

	@PreAuthorize("hasRole('ADMIN')")
	public Map<String, Object> getUserStatistics() {

		long totalUsers = userRepository.countByIsDeleteFalse();
		long admins = userRepository.countByRole(Role.ADMIN);
		long managers = userRepository.countByRole(Role.MANAGER);
		long deactivated = userRepository.countByIsActiveFalse();

		return Map.of("totalUsers", totalUsers, "admins", admins, "managers", managers, "deactivated", deactivated);
	}

	/*
	 * ───────────────────────────────── Update Logged-in User Profile
	 * ─────────────────────────────────
	 */

	@Transactional
	public UserResponseDTO updateProfile(ProfileUpdateRequestDto dto, String email) {

//String 
//email = SecurityContextHolder.getContext()
//        .getAuthentication()
//        .getName();

		UserEntity user = userRepository.findByEmail(email)
				.orElseThrow(() -> new IllegalArgumentException("User not found"));

// 🔒 If email is changing → require password
		if (!user.getEmail().equals(dto.getEmail())) {

			if (dto.getPassword() == null || dto.getPassword().isEmpty()) {
				throw new IllegalArgumentException("Password required to change email");
			}

			if (passwordEncoder.matches(dto.getPassword(), user.getPassword())) {
				throw new IllegalArgumentException("Invalid password !");
			}

			if (!passwordEncoder.matches(dto.getPassword(), user.getPassword())) {
				throw new IllegalArgumentException("Invalid password");
			}

			user.setEmail(dto.getEmail());
		}

// Update other fields
		user.setFullname(dto.getFullname());

		System.out.println(user.toString());

		user = userRepository.save(user);

		System.out.println(user.toString());
		
		preference.updateProfileExtras(email,dto.getAvatarColour(),dto.getBio() );
		
		
		return new UserResponseDTO(user.getId(), user.getFullname(), user.getEmail(), user.getRole(),
				user.getCreatedAt(), user.isActive());
	}

	/*
	 * ───────────────────────────────── Delete Own Account
	 * ─────────────────────────────────
	 */

	@Transactional
	public void deleteMyAccount(String email) {

//String email = SecurityContextHolder.getContext()
//    .getAuthentication()
//    .getName();

		UserEntity user = userRepository.findByEmail(email)
				.orElseThrow(() -> new IllegalArgumentException("User not found"));

//		user.setDelete(true); // soft delete
		user.setActive(false);
		userRepository.save(user);
	}

	/*
	 * ───────────────────────────────── Change Password
	 * ─────────────────────────────────
	 */
	@Transactional
	public void changePassword(String email, PasswordChangeRequestDto dto) {

// 1️⃣ Fetch user by email
		UserEntity user = userRepository.findByEmail(email)
				.orElseThrow(() -> new IllegalArgumentException("User not found"));

// 2️⃣ Validate current password
		if (!passwordEncoder.matches(dto.getCurrentPassword(), user.getPassword())) {
			throw new IllegalArgumentException("Current password is incorrect");
		}

// 3️⃣ Validate new password and confirm password
		if (!dto.getNewPassword().equals(dto.getConfirmPassword())) {
			throw new IllegalArgumentException("New password and confirm password do not match");
		}

// 4️⃣ Update password with BCrypt hash
		user.setPassword(passwordEncoder.encode(dto.getNewPassword()));

		userRepository.save(user); // persist the change
	}

}