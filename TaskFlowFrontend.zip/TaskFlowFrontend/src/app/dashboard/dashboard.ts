/* ═══════════════════════════════════════
                dashboard.ts
═══════════════════════════════════════ */

import { Component, inject, OnInit, OnChanges, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

import { TaskService } from '../services/task.service';
import { Auth } from '../services/auth';

import { TaskFormComponent } from '../task-form/task-form';
import { TaskDetailsComponent } from '../task-details/task-details';
import { AnalyticsTaskSummaryComponent } from '../analytics-task-summary/analytics-task-summary';
import { ActivityFeedComponent } from '../activity-feed/activity-feed';
import { TaskDuedateComponent } from '../task-duedate/task-duedate';
import { TeamDetailsComponent } from '../team-details/team-details';
import { AdminPanelComponent } from '../admin-pannel/admin-panel.component';
import { TaskTimerComponent } from '../task-timer/task-timer';
import { SettingsService } from '../services/settings.service';

import { HasRoleDirective } from '../diractive/has-role.directive';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [TaskTimerComponent,TeamDetailsComponent,AdminPanelComponent ,HasRoleDirective , CommonModule, TaskFormComponent, TaskDetailsComponent, AnalyticsTaskSummaryComponent,ActivityFeedComponent,TaskDuedateComponent],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css',
})
export class Dashboard implements OnInit, OnChanges {
  taskService = inject(TaskService);
  auth = inject(Auth);
  router = inject(Router);
  cdr = inject(ChangeDetectorRef);
  seting = inject(SettingsService);
  preferences: any = {};

  isShowAdminDashboard=false;

  isShowDashboard=true;

  isShowTeam=false;

  isShowSetting=false;

  isShowDueDate=false;
  
  isShowAnalytics = false;

  isNotification = false;
  notification: any = null;

  showTaskDetails = false;
  TaskDetails: any = null;

  showTaskTimer = false;
  TaskForTimer: any = null;

  tasks: any[] = [];
  tasksAssigntoMe: any[] = [];

  activeFilter = 'ALL';
  showModal = false;
  editingTask: any = null;

  isLoading = true;
  deleteConfirmId: number | null = null;

  LoginUser: any = null;
  isSortedHighFirst = true;

  // ── Open Settings ─────────────────────────────
OpenSetting() {
  this.router.navigate(['/setting']);
}
  
     // ── ShowDashboard Toggle ─────────────────────────────────────

  ShowAdminDashboard() { 
    this.isShowAdminDashboard =!this.isShowAdminDashboard;
    this.isShowTeam=false;
    this.cdr.detectChanges(); }



 // ── ShowTeam Toggle ─────────────────────────────────────

  ShowTeam() { this.isShowTeam = !this.isShowTeam;
                this.isShowAdminDashboard=false;
                this.isShowDueDate=false;  this.isShowAnalytics = false;
                   this.cdr.detectChanges();}

   // ── ShowDashboard Toggle ─────────────────────────────────────

  ShowDashboard() { this.isShowTeam =false;
                    this.isShowAdminDashboard =false;
                    this.cdr.detectChanges(); }

  // ── Lifecycle ─────────────────────────────────────────────

  ngOnInit() { this.loadTasks(); this.LoginUser = this.auth.getUser(); 

    this.seting.getPreferences().subscribe({
      next: res => this.preferences = res,
      error: err => console.error(err)
    });
  
  }
  ngOnChanges() { this.cdr.detectChanges(); }

  // ── Analytics Toggle ─────────────────────────────────────

  showAnalytics() { this.isShowAnalytics = !this.isShowAnalytics; this.cdr.detectChanges(); }
  toggleSort() { this.isSortedHighFirst = !this.isSortedHighFirst; this.cdr.detectChanges(); }

  get currentUser() { return this.auth.getUser(); }

   // ── ShowDueDate Toggle ─────────────────────────────────────

  ShowDueDate() { this.isShowDueDate = !this.isShowDueDate; this.cdr.detectChanges(); }

  // ── Load Tasks ───────────────────────────────────────────

  loadTasks() {
    this.isLoading = true;

    this.taskService.getTasks().subscribe({
      next: (data) => {
        this.tasks = data;
        this.isLoading = false;
        this.notification = this.getNotification(this.tasks);
        this.cdr.detectChanges(); // force UI update
      }
    });

    // Load tasks assigned to me
    this.taskService.getTasksAssignToMe().subscribe({
      next: (data) => { this.tasksAssigntoMe = data; }
    });
  }

  // ── Filtered Tasks ───────────────────────────────────────

  get filteredTasks(): any[] {
    if (this.activeFilter === 'ALL') {
      const merged = [...this.tasks, ...this.tasksAssigntoMe];
      const uniqueTasks = merged.filter((task, index, self) =>
        index === self.findIndex(t => t.id === task.id)
      );
      if (this.isSortedHighFirst) this.sortByPriority(uniqueTasks);
      return uniqueTasks;
    }

    if (this.activeFilter === 'ASSIGN_TO_ME') {
      const temp = this.tasksAssigntoMe;
      if (this.isSortedHighFirst) this.sortByPriority(temp);
      return temp;
    }

    if (this.isSortedHighFirst) {
      const temp = this.tasks;
      this.sortByPriority(temp);
      return temp.filter(t => t.status === this.activeFilter);
    }

    return this.tasks.filter(t => t.status === this.activeFilter);
  }

  // ── Sorting ──────────────────────────────────────────────

  sortByPriority(tasks: any[]): any[] {
    const priorityOrder: any = { HIGH: 3, MEDIUM: 2, LOW: 1 };
    return tasks.sort((a, b) => priorityOrder[b.priority] - priorityOrder[a.priority]);
  }

  // ── Stats ────────────────────────────────────────────────

  get totalCount() { return this.tasks.length; } // count tasks created by owner
  get todoCount() { return this.tasks.filter(t => t.status === 'TODO').length; }
  get inProgressCount() { return this.tasks.filter(t => t.status === 'IN_PROGRESS').length; }
  get doneCount() { return this.tasks.filter(t => t.status === 'DONE').length; }
  get assignToMeCount() { return this.tasksAssigntoMe.length; }

  // ── Create / Edit Modal ──────────────────────────────────

  openCreateModal() { this.editingTask = null; this.showModal = true; }
  openEditModal(task: any) { this.editingTask = { ...task }; this.showModal = true; }
  closeModal() { this.showModal = false; this.editingTask = null; }
  onTaskSaved() { this.loadTasks(); this.closeModal(); }

  // ── Task Details Modal ───────────────────────────────────

  openTaskDetails(task: any) { this.showTaskDetails = true; this.TaskDetails = { ...task }; }
  closetaskDetails() { this.showTaskDetails = false; }




  // ── Task Timer Modal ───────────────────────────────────

  openTaskTimer(task: any) { this.showTaskTimer = true; this.TaskForTimer = { ...task }; }
  closetaskTimer() { this.showTaskTimer = false; }




  // ── Delete ───────────────────────────────────────────────

  confirmDelete(id: number) { this.deleteConfirmId = id; }
  cancelDelete() { this.deleteConfirmId = null; }

  executeDelete(id: number) {
    this.deleteConfirmId = null;
    this.taskService.deleteTask(id).subscribe(() => {
      this.deleteConfirmId = null;
      this.loadTasks();
    });
  }

  // ── Auth ─────────────────────────────────────────────────

  logout() { this.auth.logout(); this.router.navigate(['/login']); }

  // ── UI Helpers ───────────────────────────────────────────

  statusBadgeClass(status: string): string {
    return { TODO: 'bg-secondary', IN_PROGRESS: 'bg-warning text-dark', DONE: 'bg-success' }[status] ?? 'bg-secondary';
  }

  priorityBadgeClass(status: string): string {
    return { HIGH: 'bg-danger', MEDIUM: 'bg-warning text-dark', LOW: 'bg-success' }[status] ?? 'bg-secondary';
  }

  statusLabel(status: string): string {
    return { TODO: 'To-Do', IN_PROGRESS: 'In Progress', DONE: 'Done' }[status] ?? status;
  }

  // ── Date Helpers ─────────────────────────────────────────

  isOverdue(dueDate: string): boolean {
    const today = new Date();
    const due = new Date(dueDate);
    const todayOnly = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    const dueOnly = new Date(due.getFullYear(), due.getMonth(), due.getDate());
    return dueOnly < todayOnly;
  }

  getNotification(tasks: any[]): string {
    const today = new Date();
    const todayOnly = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    let overdue = 0, dueToday = 0;

    tasks.filter(t => t.status !== 'DONE').forEach(t => {
      const d = new Date(t.dueDate);
      const due = new Date(d.getFullYear(), d.getMonth(), d.getDate());
      if (due < todayOnly) overdue++;
      else if (due.getTime() === todayOnly.getTime()) dueToday++;
    });

    if (!(overdue === 0 && dueToday === 0)) this.isNotification = true;

    return overdue || dueToday
      ? `You have ${overdue} overdue and ${dueToday} due today.`
      : 'No tasks due today or overdue.';
  }

  isAssignToMe(task: any): boolean {
    if (task.userId == this.LoginUser.userId) return false;
    if (task.assignedToId == this.LoginUser.userId) return true;
    else return false;
  }
}