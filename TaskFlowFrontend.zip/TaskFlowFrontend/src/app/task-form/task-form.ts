/* |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
             task-form.ts
||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||| */

import { Component, Input, Output, EventEmitter, OnInit, inject, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { TaskService } from '../services/task.service';
import { Auth } from '../services/auth';
@Component({
  selector: 'app-task-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './task-form.html',
})
export class TaskFormComponent implements OnInit {

  /* -------------------- Inputs / Outputs -------------------- */
  @Input() task: any = null; // null → create mode; object → edit mode
  @Output() taskSaved  = new EventEmitter<void>();
  @Output() cancelForm = new EventEmitter<void>();

  /* -------------------- Injected Services -------------------- */
  fb = inject(FormBuilder);
  taskService = inject(TaskService);
  change = inject(ChangeDetectorRef);
  auth = inject(Auth);

  /* -------------------- State -------------------- */
  isSaving = false;
  errorMsg = '';
  currentUser: any = null;
  users: any[] = [];

  /* -------------------- Form -------------------- */
  task_form = this.fb.group({
    title: ['', [Validators.required]],
    description: [''],
    dueDate: ['', [Validators.required]],
    status: ['TODO'],
    priority: ['MEDIUM'],
    assignedToId: ['']
  });

  /* -------------------- Lifecycle -------------------- */
  ngOnInit() {
    this.currentUser = this.auth.getUser();

    this.taskService.fetchUser().subscribe({
      next: (res: any[]) => { this.users = res; this.change.detectChanges(); },
      error(err) {
        error: (err: any) => {
          // alert(err);
        }
      }
    });

    if (this.task) {
      this.task_form.patchValue({
        title: this.task.title,
        description: this.task.description || '',
        dueDate: this.task.dueDate,
        status: this.task.status,
        priority: this.task.priority,
        assignedToId: this.task.assignedToId,
      });
    }

    if (this.isAssignToMe()) {
      this.task_form.get('title')?.disable();
      this.task_form.get('description')?.disable();
      this.task_form.get('dueDate')?.disable();
      this.task_form.get('priority')?.disable();
      this.task_form.get('assignedToId')?.disable();
    }
  }

  /* -------------------- Role Check -------------------- */
  isAssignToMe(): boolean {
    if (this.task == null) return false;
    if (this.task.userId == this.currentUser.userId) return false;
    if (this.task.assignedToId == this.currentUser.userId) return true;
    else return false;
  }

  /* -------------------- Save -------------------- */
  save() {
    if (this.task_form.invalid) { this.task_form.markAllAsTouched(); return; }

    this.errorMsg = '';
    this.isSaving = true;
    const data = this.task_form.value;

    console.log("   VALUE OF FROM  ");
    console.table(data);

    const req$ = this.task
      ? this.taskService.updateTask(this.task.id, data)
      : this.taskService.createTask(data);

    req$.subscribe({
      next: () => { this.isSaving = false; this.taskSaved.emit(); },
      error: (err: any) => {
        this.isSaving = false;
        this.errorMsg = err.error?.message || 'Failed to save. Please try again.';
      }
    });
  }

  /* -------------------- Cancel -------------------- */
  cancel() { this.cancelForm.emit(); }

}