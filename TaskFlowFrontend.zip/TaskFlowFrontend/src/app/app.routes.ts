// import { Routes } from '@angular/router';

// export const routes: Routes = [];



import { Routes } from '@angular/router';
import { Login }     from './auth/login/login';
import { Register }  from './auth/register/register';
import { Dashboard } from './dashboard/dashboard';
import { NotFound }  from './not-found/not-found';
import { SettingComponent } from './setting/setting';
import { authGuard, guestGuard } from './guards/auth.guard';

export const routes: Routes = [
  { path: '',          redirectTo: 'login', pathMatch: 'full' },
  { path: 'login',     component: Login,     canActivate: [guestGuard] },
  { path: 'register',  component: Register,  canActivate: [guestGuard] },
  { path: 'dashboard', component: Dashboard, canActivate: [authGuard]  },
  { path: 'setting',   component: SettingComponent, canActivate: [authGuard]  },
  { path: '**',        component: NotFound },      // ← MUST be last
];