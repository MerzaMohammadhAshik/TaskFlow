/* ═══════════════════════════════════════
            not-found.ts
═══════════════════════════════════════ */

import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-not-found',
  standalone: true,
  imports: [RouterLink],
  template: `
    <div class="d-flex flex-column align-items-center justify-content-center
                vh-100 text-center px-3"
         style="background:#F4F6FA;">

      <!-- Large icon -->
      <div class="mb-2" style="font-size:5rem;">🔍</div>

      <!-- 404 Title -->
      <h1 class="fw-bold mb-1" style="font-size:6rem; color:#2563EB; line-height:1;">
        404
      </h1>

      <!-- Subtitle -->
      <h3 class="fw-semibold mb-2" style="color:#1E293B;">Page Not Found</h3>

      <!-- Description -->
      <p class="text-muted mb-4" style="max-width:380px;">
        The page you're looking for doesn't exist or has been moved.
      </p>

      <!-- Action Buttons -->
      <div class="d-flex gap-3 flex-wrap justify-content-center">
        <a routerLink="/dashboard"
           class="btn btn-primary rounded-3 px-4 fw-semibold">
          Go to Dashboard
        </a>
        <a routerLink="/login"
           class="btn btn-outline-secondary rounded-3 px-4">
          Back to Login
        </a>
      </div>

    </div>
  `,
})
export class NotFound {}