/* ═══════════════════════════════════════
                team-details.ts
═══════════════════════════════════════ */

import { Component, OnInit, ChangeDetectorRef, ViewChild, ElementRef ,} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TeamService, UserIdNameDTO, TeamDTO, UserDTO } from '../team.service';
import { HasRoleDirective } from '../diractive/has-role.directive';
@Component({
  selector: 'app-team-details',
  standalone: true,
  imports: [CommonModule, FormsModule, HasRoleDirective],
  templateUrl: './team-details.html',
  styleUrls: ['./team-details.css']
})
export class TeamDetailsComponent implements OnInit {

  @ViewChild('teamDetail') teamDetail!: ElementRef;

removeConfirmId: number | null = null;
removeConfirmName: string | null = null;
  
  displayMembers: any[] = [];
  
  teams: TeamDTO[] = [];
  members: UserDTO[] = [];

  selectedTeam: TeamDTO | null = null;

  stats = { teams: 0, members: 0, tasks: 0 };

  createModal = false;
  addMemberModal = false;

  managers: UserIdNameDTO[] = [];
  users: UserIdNameDTO[] = [];

  newTeam = { name: '', description: '', managerId: null as number | null };
  newMemberId: number | null = null;

  constructor(private teamService: TeamService, private cd: ChangeDetectorRef) {}

  ngOnInit() {
    this.loadTeams();
    this.loadManagers();
    this.loadMembers();
  }

  /* ═══════════════════════════════════════
                  Load Teams
  ═══════════════════════════════════════ */

  loadTeams() {
    this.teamService.getTeams().subscribe(res => {
      this.teams = res;
      this.stats.teams = res.length;
      this.cd.detectChanges();
    });
  }

  /* ═══════════════════════════════════════
                Load Managers
  ═══════════════════════════════════════ */

  loadManagers() {
    this.teamService.getManagers().subscribe(res => {
      this.managers = res;
    });
  }

  /* ═══════════════════════════════════════
                Load Members
  ═══════════════════════════════════════ */

  loadMembers() {
    this.teamService.getMembers().subscribe(res => {
      this.users = res;
    });
  }

  /* ═══════════════════════════════════════
              Open Team Detail
  ═══════════════════════════════════════ */

openTeam(team: TeamDTO) {

  this.selectedTeam = team;

  this.teamService.getTeamDetails(team.id).subscribe(res => {

    const manager = res.manager ? [{ ...res.manager, isManager: true }] : [];

    const members = (res.members || []).map(m => ({
      ...m,
      isManager: false
    }));

    this.displayMembers = [...manager, ...members];

    this.stats.members = this.displayMembers.length;
    this.stats.tasks = res.taskIds?.length || 0;

    this.cd.detectChanges();   // ✅ refresh UI

    setTimeout(() => {
      this.teamDetail.nativeElement.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
      });
    }, 100);

  });

}

  /* ═══════════════════════════════════════
                Create Team
  ═══════════════════════════════════════ */

  createTeam() {

    if (!this.newTeam.name || !this.newTeam.managerId) return;

    this.teamService.createTeam({
      name: this.newTeam.name,
      description: this.newTeam.description,
      managerId: this.newTeam.managerId
    }).subscribe(() => {

      
      this.newTeam = { name: '', description: '', managerId: null };
      this.loadTeams();

    });

          this.createModal = false;
          this.cd.detectChanges();   // ✅ refresh UI 
  }

  /* ═══════════════════════════════════════
                  Add Member
  ═══════════════════════════════════════ */

  addMember() {

    if (!this.newMemberId || !this.selectedTeam) return;

    this.teamService.addMember(
      this.selectedTeam.id,
      { userId: this.newMemberId }
    ).subscribe(() => {

      
      this.newMemberId = null;

     
      this.openTeam(this.selectedTeam!);
    });
            this.addMemberModal = false;
          this.cd.detectChanges();   // ✅ refresh UI 
    
  }

  /* ═══════════════════════════════════════
          Open Remove Confirmation
═══════════════════════════════════════ */

confirmRemove(member: any) {

  this.removeConfirmId = member.id;
  this.removeConfirmName = member.fullname;

}

cancelRemove() {

  this.removeConfirmId = null;
  this.removeConfirmName = null;

}

  /* ═══════════════════════════════════════
                Remove Member
  ═══════════════════════════════════════ */

  executeRemove() {

  if (!this.selectedTeam || !this.removeConfirmId) return;

  this.teamService.removeMember(
    this.selectedTeam.id,
    this.removeConfirmId
  ).subscribe(() => {

    this.cancelRemove();

    this.openTeam(this.selectedTeam!);

    

  });
  this.cd.detectChanges();

}
}