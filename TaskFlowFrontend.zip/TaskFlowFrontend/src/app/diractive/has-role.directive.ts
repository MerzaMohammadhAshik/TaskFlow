/* ═══════════════════════════════════════
   has-role.directive.ts
════════════════════════════════════════ */

import { Directive, Input, OnInit, TemplateRef, ViewContainerRef } from '@angular/core';
import { Auth } from '../services/auth';

@Directive({
  selector: '[appHasRole]',
  standalone: true // Angular 14+ standalone directive
})
export class HasRoleDirective implements OnInit {
  private hasView = false;

  /**
   * Input setter that triggers the role check whenever the roles array is passed.
   * Usage example: *appHasRole="['ADMIN', 'MANAGER']"
   */
  @Input() set appHasRole(roles: string[]) {
    this.checkRole(roles);
  }

  // Store the current user role for reference
  private currentUserRole: string | undefined = '';

  constructor(
    private templateRef: TemplateRef<any>,
    private viewContainer: ViewContainerRef,
    private authService: Auth
  ) {}

  ngOnInit(): void {
    // Initialize current user role from AuthService
    this.currentUserRole = this.authService.getUser()?.role;
    // The initial check is handled by the @Input setter
  }

  /**
   * Compares the current user role to allowed roles and manages the view container.
   * - If the user has access, the template is rendered.
   * - If not, the template is removed.
   */
  private checkRole(roles: string[]): void {
    const user = this.authService.getUser();
    const userRole = user?.role;

    // Ensure boolean result: true if userRole exists and is in the allowed roles
    const canAccess = !!userRole && roles.includes(userRole);

    if (canAccess && !this.hasView) {
      // Add the template to the DOM if user has access and it's not already there
      this.viewContainer.createEmbeddedView(this.templateRef);
      this.hasView = true;
    } else if (!canAccess && this.hasView) {
      // Remove the template from the DOM if user no longer has access
      this.viewContainer.clear();
      this.hasView = false;
    }
  }
}