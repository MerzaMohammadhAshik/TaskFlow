/* ============================================================
                    TASK DETAILS COMPONENT
============================================================ */

import {
  Component,
  Input,
  Output,
  EventEmitter,
  OnInit,
  OnChanges,
  SimpleChanges,
  inject,
} from '@angular/core';

import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ChangeDetectorRef } from '@angular/core';
import { HttpEventType } from '@angular/common/http';

import { TaskService } from '../services/task.service';
import { CommentService } from '../services/comment.service';
import { Auth } from '../services/auth';
import { AttachmentService, AttachmentListDTO } from '../services/attachment.service';


import { SubtaskService } from '../services/subtask.service'; import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-task-details',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  templateUrl: './task-details.html',
  styleUrl: './task-details.css',
})
export class TaskDetailsComponent implements OnInit, OnChanges {

  /* ============================================================
                        INPUTS / OUTPUTS
  ============================================================ */
  @Input() task: any = null;

  @Output() comment = new EventEmitter<void>();
  @Output() closeTaskDetailsView = new EventEmitter<void>();
  @Output() editTask = new EventEmitter<any>();
  @Output() deleteTask = new EventEmitter<number>();


  /* ============================================================
                        SERVICES
  ============================================================ */
  fb = inject(FormBuilder);
  taskService = inject(TaskService);
  commentService = inject(CommentService);
  auth = inject(Auth);
  reload = inject(ChangeDetectorRef);
  attachmentService = inject(AttachmentService);


  /* ============================================================
                        COMMENTS + TASK STATE
  ============================================================ */
  comments: any[] = [];
  currentUser: any = null;
  deleteConfirmId: number | null = null;

  title = '';
  description = '';
  dueDate = '';
  status = '';
  priority = '';
  assignedToId: number = 0;
  assignedToname = 'Unassign';


  /* ============================================================
                        UI STATE
  ============================================================ */
  showSubtask = true;


  /* ============================================================
                        ATTACHMENTS STATE
  ============================================================ */
  attachments: AttachmentListDTO[] = [];
  selectedFile?: File | null = null;

  maxFiles = 5;
  maxFileSizeMB = 5;

  dragOver = false;
  lastError = '';

  uploadingQueue: { file: File; progress: number }[] = [];

  acceptedTypes = [
    'application/pdf',
    'image/png',
    'image/jpeg',
    'image/gif',
    'image/webp',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/zip',
    'application/x-zip-compressed',
  ];


  /* ============================================================
                        FORM
  ============================================================ */
  comment_form = this.fb.group({
    body: ['', [Validators.required, Validators.minLength(3)]],
  });


  /* ============================================================
                        LIFECYCLE
  ============================================================ */
  ngOnInit() {
    this.loadUsers(); // 

    this.initializeTask();
    this.currentUser = this.auth.getUser();


  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes['task'] && this.task) {
      this.initializeTask();
    }
  }


  /* ============================================================
                        INITIALIZE TASK
  ============================================================ */
  initializeTask() {
    this.title = this.task?.title ?? '';
    this.description = this.task?.description ?? '';
    this.dueDate = this.task?.dueDate ?? '';
    this.status = this.task?.status ?? '';
    this.priority = this.task?.priority ?? '';
    this.assignedToId = this.task?.assignedToId ?? 0;
    this.assignedToname = this.task?.assignedUserName ?? 'Unassign';

    if (this.task?.id) {
      this.loadComments(this.task.id);
      this.loadAttachments(this.task.id);
      this.loadSubtasks(this.task.id);
      this.reload.detectChanges();
    }


  }


  /* ============================================================
                        COMMENTS
  ============================================================ */
  loadComments(taskId: number) {
    this.commentService.getAllComments(taskId).subscribe({
      next: (res) => {
        this.comments = res ?? [];
        this.reload.detectChanges();
      }
    });
  }

  commentSave() {
    if (this.comment_form.invalid) {
      this.comment_form.markAllAsTouched();
      return;
    }

    const body = this.comment_form.value.body!;

    this.commentService.sendComment(this.task.id, body).subscribe({
      next: () => {
        this.comment_form.reset();
        this.loadComments(this.task.id);
      }
    });
  }

  isOwner(c: any) {
    return c?.authorId === this.currentUser?.userId;
  }

  confirmDelete(id: number) {
    this.deleteConfirmId = id;
  }

  cancelDelete() {
    this.deleteConfirmId = null;
  }

  executeDelete(id: number) {
    this.commentService.deleteComment(id).subscribe({
      next: () => {
        this.comments = this.comments.filter(c => c.id !== id);
        this.deleteConfirmId = null;
        this.reload.detectChanges();
      }
    });
    this.reload.detectChanges();
  }


  /* ============================================================
                        TASK ACTIONS
  ============================================================ */
  edit() {
    this.closeTaskDetailsView.emit();
    this.editTask.emit(this.task);
  }

  delete() {
    this.closeTaskDetailsView.emit();
    this.deleteTask.emit(this.task.id);
  }

  cancel() {
    this.closeTaskDetailsView.emit();
  }


  /* ============================================================
                        HELPERS
  ============================================================ */
  formatDate(value: string) {
    const d = new Date(value);
    const now = new Date();

    const isToday =
      d.getDate() === now.getDate() &&
      d.getMonth() === now.getMonth() &&
      d.getFullYear() === now.getFullYear();

    return isToday
      ? `Today ${d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`
      : d.toLocaleString();
  }

  isAssignToMe(): boolean {
    if (!this.task || !this.currentUser) return false;
    if (this.task.userId === this.currentUser.userId) return false;
    return this.task.assignedToId === this.currentUser.userId;
  }

  isOverdue(d: string | null) {
    if (!d) return false;

    const A = new Date(d);
    const B = new Date();

    A.setHours(0, 0, 0, 0);
    B.setHours(0, 0, 0, 0);

    return A < B;
  }


  /* ============================================================
                        TOGGLE
  ============================================================ */
  toggleSection(checked: boolean) {
    this.showSubtask = !checked;

    if (!this.showSubtask && this.task?.id) {
      this.loadAttachments(this.task.id);
    }
  }


  /* ============================================================
                        ATTACHMENTS LOAD
  ============================================================ */
  loadAttachments(taskId: number) {
    this.attachmentService.list(taskId).subscribe({
      next: (list) => {
        this.attachments = list ?? [];
        this.reload.detectChanges();
      }
    });
  }


  /* ============================================================
                        FILE TYPE HELPERS
  ============================================================ */
  fileTypeLabel(mime: string | null): string {
    if (!mime) return 'FILE';
    if (mime === 'application/pdf') return 'PDF';
    if (mime.startsWith('image/')) return 'IMG';
    if (mime.includes('msword') || mime.includes('wordprocessingml')) return 'DOC';
    if (mime.includes('zip')) return 'ZIP';
    return 'FILE';
  }

  fileTypeClass(mime: string | null): string {
    const map: any = {
      PDF: 'pill-pdf',
      IMG: 'pill-img',
      DOC: 'pill-doc',
      ZIP: 'pill-zip',
    };

    return map[this.fileTypeLabel(mime)] ?? 'pill-other';
  }


  /* ============================================================
                        VALIDATION
  ============================================================ */
  canAddMore(): boolean {
    return this.attachments.length + this.uploadingQueue.length < this.maxFiles;
  }

  validateFile(file: File): string | null {
    const s = file.size / 1024 / 1024;

    if (s > this.maxFileSizeMB) {
      return `File "${file.name}" exceeds ${this.maxFileSizeMB} MB.`;
    }

    if (!this.acceptedTypes.includes(file.type) && !file.type.startsWith('image/')) {
      return `File "${file.name}" type "${file.type}" is not allowed.`;
    }

    if (!this.canAddMore()) {
      return `Max ${this.maxFiles} files allowed.`;
    }

    return null;
  }


  /* ============================================================
                        DRAG & DROP
  ============================================================ */
  onDragOver(e: DragEvent) {
    e.preventDefault();
    this.dragOver = true;
  }

  onDragLeave(e: DragEvent) {
    e.preventDefault();
    this.dragOver = false;
  }

  onDrop(e: DragEvent) {
    e.preventDefault();
    this.dragOver = false;

    const fs = e.dataTransfer?.files;
    if (!fs?.length) return;

    this.handleFiles(Array.from(fs));
  }


  /* ============================================================
                        FILE INPUT
  ============================================================ */
  onFileSelected(e: Event) {
    const input = e.target as HTMLInputElement;
    const fs = input.files ? Array.from(input.files) : [];

    if (fs.length) this.handleFiles(fs);

    input.value = '';
  }


  /* ============================================================
                        PROCESS FILES
  ============================================================ */
  handleFiles(files: File[]) {
    this.lastError = '';

    for (const f of files) {
      const err = this.validateFile(f);

      if (err) {
        this.lastError = err;
        return;
      }

      this.queueAndUpload(f);
    }
  }


  /* ============================================================
                        UPLOAD WITH PROGRESS
  ============================================================ */
  queueAndUpload(file: File) {

    if (!this.task?.id) {
      this.lastError = 'Task not ready.';
      return;
    }

    this.lastError = '';

    const entry = { file, progress: 0 };
    this.uploadingQueue.push(entry);

    this.attachmentService.uploadWithProgress(this.task.id, file)
      .subscribe({

        next: (event) => {

          if (event?.type === HttpEventType.UploadProgress) {
            const total = event.total ?? file.size;
            entry.progress = Math.round((event.loaded / total) * 100);
            this.reload.detectChanges();
          }

          if (event?.type === HttpEventType.Response) {
            entry.progress = 100;
            this.reload.detectChanges();
          }
        },

        error: (err) => {
          this.lastError = err?.error?.message || 'Upload failed';
          this.uploadingQueue = this.uploadingQueue.filter(x => x !== entry);
          this.reload.detectChanges();
        },

        complete: () => {
          this.uploadingQueue = this.uploadingQueue.filter(x => x !== entry);
          this.loadAttachments(this.task.id);
          this.reload.detectChanges();
        }
      });
  }


  /* ============================================================
                        DOWNLOAD / DELETE
  ============================================================ */
  download(file: AttachmentListDTO) {
    this.attachmentService.download(file.id).subscribe({
      next: (res) => {
        const fn = this.attachmentService.extractFileName(res, file.originalName);
        this.attachmentService.saveBlob(res.body!, fn);
        this.reload.detectChanges();
      }
    });
  }

  deleteAttachment(file: AttachmentListDTO) {
    this.attachmentService.delete(file.id).subscribe({
      next: () => {
        this.attachments = this.attachments.filter(x => x.id !== file.id);
        this.reload.detectChanges();
      }
    });
  }

  canDelete(file: AttachmentListDTO): boolean {
    return true;
  }







  /* ═══════════════════════════════════════
        Subtask Component Logic
═══════════════════════════════════════ */

  subtasks: any[] = [];
  summary: any = { total: 0, completed: 0 };
  newSubtask: string = '';

  users: any[] = [];
  selectedUserId: number | null = null;

  private subtaskService = inject(SubtaskService);

  /* LOAD SUBTASKS */
  loadSubtasks(taskId: number) {
    this.subtaskService.getSubtasks(taskId).subscribe(res => {
      this.subtasks = res;
      this.loadSummary(taskId); // ✅ call AFTER data load
    });
  }

  /* LOAD USERS */
  loadUsers() {
    this.taskService.fetchUser().subscribe({
      next: (res: any[]) => {
        this.users = res;
      },
      error: (err) => {
        console.error(err);
      }
    });
  }

  /* ADD SUBTASK */
  addSubtask() {
    if (!this.newSubtask.trim()) return;

    const payload: any = {
      title: this.newSubtask
    };

    if (this.selectedUserId) {
      payload.assignedTo = this.selectedUserId;
    }

    this.subtaskService.createSubtask(this.task.id, payload)
      .subscribe(() => {

        // ✅ INSTANT UI UPDATE (no wait)
        this.subtasks.push({
          id: Date.now(), // temp id
          title: this.newSubtask,
          complete: false,
          assignedTo: this.selectedUserId
        });

        // ✅ optional: sync with backend
        this.loadSubtasks(this.task.id);
      });

    this.newSubtask = '';
    this.selectedUserId = null;

  }

  /* TOGGLE */
  toggleSubtask(id: number) {

    // ✅ instant UI toggle
    const sub = this.subtasks.find(s => s.id === id);
    if (sub) sub.complete = !sub.complete;

    this.subtaskService.toggleSubtask(id)
      .subscribe({
        error: () => {
          // rollback if failed
          if (sub) sub.complete = !sub.complete;
        }
      });
  }

  /* DELETE */
  deleteSubtask(id: number) {

    // ✅ instant remove from UI
    this.subtasks = this.subtasks.filter(s => s.id !== id);

    this.subtaskService.deleteSubtask(id)
      .subscribe({
        error: () => {
          // rollback (optional: reload)
          this.loadSubtasks(this.task.id);
        }
      });
  }

  /* SUMMARY */
  loadSummary(taskId: number) {
    this.subtaskService.getSummary(taskId)
      .subscribe(res => this.summary = res);
  }

  /* PROGRESS */
  getProgress(): number {
    if (!this.summary.total) return 0;
    return (this.summary.completed / this.summary.total) * 100;
  }

  /* PERMISSION */
  canDeleteSubTask(s: any): boolean {
    return true;
  }















  // style


  /* Subtask Row Style */
  getSubtaskRowStyle(s: any) {
    return {
      'display': 'flex',
      'align-items': 'center',
      'gap': '10px',
      'padding': '8px 10px',
      'border-radius': '8px',
      'margin-bottom': '6px',
      'background': s.complete ? '#f3f4f6' : '#ffffff',
      'border': '1px solid #eee',
      'transition': '0.2s'
    };
  }

  /* Chip Style */
  getChipStyle(assigned: boolean) {
    return {
      'padding': '3px 8px',
      'border-radius': '20px',
      'font-size': '12px',
      'background': assigned ? '#dbeafe' : '#fef3c7',
      'color': assigned ? '#1d4ed8' : '#92400e'
    };
  }

  /* Delete Icon */
  getDeleteStyle() {
    return {
      'cursor': 'pointer',
      'font-size': '16px',
      'margin-left': '10px',
      'color': '#ef4444',
      'transition': '0.2s'
    };
  }





}
