/* ============================================================
   File: task-timer.ts
   Optimized with Change Detection (OnPush + detectChanges)
============================================================ */

import {
  Component,
  Input,
  OnInit,
  OnDestroy,
  ChangeDetectorRef,
  ChangeDetectionStrategy
} from '@angular/core';

import { TaskTimerService } from '../services/task-timer.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-task-timer',
  imports: [CommonModule, FormsModule],
  templateUrl: './task-timer.html',
  styleUrls: ['./task-timer.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TaskTimerComponent implements OnInit, OnDestroy {

  constructor(
    private api: TaskTimerService,
    private cdr: ChangeDetectorRef
  ) {}

  @Input() taskId!: number;
  @Input() role: string = 'USER';

  isRunning = false;
  startTime: number = 0;
  timerInterval: any = null;
  displayTime = '00:00:00';

  totalMinutes = 0;
  logs: any[] = [];

  // Manual log
  hours = 0;
  minutes = 0;
  logDate = new Date().toISOString().split('T')[0];
  note = '';

  ngOnInit(): void {
    if (!this.taskId) return;

    this.fetchBeforeTime();
    this.loadLogs();
    this.loadTotal();
    this.checkActiveTimer();
  }

  ngOnDestroy(): void {
    this.clearTimer();
  }

  // =======================================================
  // TIMER
  // =======================================================

  fetchBeforeTime() {
    this.api.fetchBeforeTimeOfTask(this.taskId).subscribe({
      next: (res: any) => {

        const time = res?.time;
        if (!time) return;

        const parsedTime = new Date(time).getTime();
        if (isNaN(parsedTime)) return;

        this.isRunning = true;
        this.startTime = parsedTime;
        this.runTimer();

        this.cdr.detectChanges();
      }
    });
  }

  startTimer() {
    this.api.startTimer(this.taskId).subscribe({
      next: () => {
        this.isRunning = true;
        this.startTime = Date.now();
        this.runTimer();
        this.cdr.detectChanges();
      },
      error: (err) => {
        if (err.status === 409) {
          alert('⚠️ A timer is already running!');
        }
      }
    });
  }

  stopTimer() {
    this.api.stopTimer(this.taskId).subscribe({
      next: () => {

        this.isRunning = false;
        this.clearTimer();
        this.displayTime = '00:00:00';

        this.loadLogs();
        this.loadTotal();

        this.cdr.detectChanges();
      }
    });
  }

  runTimer() {
    this.clearTimer();

    this.timerInterval = setInterval(() => {

      const diff = Date.now() - this.startTime;

      const hrs = Math.floor(diff / 3600000);
      const mins = Math.floor((diff % 3600000) / 60000);
      const secs = Math.floor((diff % 60000) / 1000);

      this.displayTime =
        `${this.pad(hrs)}:${this.pad(mins)}:${this.pad(secs)}`;

      this.cdr.detectChanges();

    }, 1000);
  }

  clearTimer() {
    if (this.timerInterval) {
      clearInterval(this.timerInterval);
      this.timerInterval = null;
    }
  }

  pad(n: number): string {
    return n.toString().padStart(2, '0');
  }

  // =======================================================
  // ACTIVE TIMER
  // =======================================================

  checkActiveTimer() {
    this.api.getActiveTimer(this.taskId).subscribe({
      next: (timer) => {

        if (timer?.start_time) {
          this.isRunning = true;
          this.startTime = new Date(timer.start_time).getTime();
          this.runTimer();
          this.cdr.detectChanges();
        }

      }
    });
  }

  // =======================================================
  // MANUAL LOGGING
  // =======================================================

  addManualLog() {

    const total = (this.hours || 0) * 60 + (this.minutes || 0);

    if (total <= 0) return alert('Enter valid time');
    if (this.minutes > 59) return alert('Minutes must be between 0–59');

    this.api.addManualLog(this.taskId, {
      durationMinutes: total,
      logDate: this.logDate,
      note: this.note
    }).subscribe({
      next: () => {

        this.hours = 0;
        this.minutes = 0;
        this.note = '';
        this.logDate = new Date().toISOString().split('T')[0];

        this.loadLogs();
        this.loadTotal();

        this.cdr.detectChanges();
      }
    });
  }

  deleteLog(id: number) {
    this.api.deleteLog(id).subscribe({
      next: () => {
        this.loadLogs();
        this.loadTotal();
        this.cdr.detectChanges();
      }
    });
  }

  // =======================================================
  // LOAD DATA
  // =======================================================

  loadLogs() {
    this.api.getLogs(this.taskId).subscribe({
      next: (data) => {
        this.logs = data || [];
        this.cdr.detectChanges();
      }
    });
  }

  loadTotal() {
    this.api.getTotal(this.taskId).subscribe({
      next: (res) => {
        this.totalMinutes = res?.totalMinutes || 0;
        this.cdr.detectChanges();
      }
    });
  }

  // =======================================================
  // FORMATTER
  // =======================================================

  formatDuration(mins: number): string {

    if (!mins) return 'No time logged';

    const h = Math.floor(mins / 60);
    const m = mins % 60;

    if (mins < 60) return `${mins}m`;
    if (mins < 120) return `1h ${m}m`;

    return `${h}h ${m}m`;
  }
}