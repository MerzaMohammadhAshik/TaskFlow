/* ═══════════════════════════════════════
   admin-panel.component.ts
═══════════════════════════════════════ */

import {Component,inject,OnInit,ChangeDetectorRef} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import { UserService } from '../services/user.service';
@Component({
 selector:'app-admin-panel',
 standalone:true,
 imports:[CommonModule,FormsModule],
 templateUrl:'./admin-panel.component.html',
 styleUrls:['./admin-panel.component.css']
})

export class AdminPanelComponent implements OnInit{

 private userService=inject(UserService);
 private cdr=inject(ChangeDetectorRef);

 users:any[]=[];
 filteredUsers:any[]=[];
 pagedUsers:any[]=[];

 stats:any={};

 searchText='';
 roleFilter='ALL';

 roles=['ADMIN','MANAGER','MEMBER','VIEWER'];
 statuses=['ACTIVE','INACTIVE'];

 /* pagination */
 page=1;
 pageSize=10;
 totalPages=1;

 removeConfirmId:number|null=null;
 removeConfirmName='';

 /* ───────── INIT ───────── */

 ngOnInit(){
  this.loadUsers();
  this.loadStats();
 }

 /* ───────── LOAD USERS ───────── */

 loadUsers(){
  this.userService.getUsers().subscribe(res=>{
   this.users=res.map(u=>({
    ...u,
    selectedRole:u.role,
    selectedStatus:u.active?'ACTIVE':'INACTIVE',
    changed:false
   }));
   this.filteredUsers=this.users;
   this.updatePagination();
   this.cdr.detectChanges();
  });
 }

 /* ───────── LOAD STATS ───────── */

 loadStats(){
  this.userService.getStats().subscribe(res=>{
   this.stats=res;
   this.cdr.detectChanges();
  });
 }

 /* ───────── SEARCH ───────── */

 searchUsers(){
  const txt=this.searchText.toLowerCase();
  this.filteredUsers=this.users.filter(u=>
   u.fullname.toLowerCase().includes(txt) ||
   u.email?.toLowerCase().includes(txt)
  );
  this.page=1;
  this.updatePagination();
 }

 /* ───────── FILTER ───────── */

 filter(role:string){
  this.roleFilter=role;

  if(role==='ALL') this.filteredUsers=this.users;

  else if(role==='INACTIVE')
   this.filteredUsers=this.users.filter(u=>!u.active);

  else
   this.filteredUsers=this.users.filter(u=>u.role===role);

  this.page=1;
  this.updatePagination();
 }

 /* ───────── ROLE CHANGE ───────── */

 roleChanged(user:any){
  user.changed=
   user.selectedRole!==user.role ||
   (user.selectedStatus==='ACTIVE')!==user.active;
 }

 /* ───────── STATUS CHANGE ───────── */

 statusChanged(user:any){
  user.changed=
   user.selectedRole!==user.role ||
   (user.selectedStatus==='ACTIVE')!==user.active;
 }

 /* ───────── UPDATE USER ───────── */

 updateUser(user:any){

  if(user.selectedRole!==user.role){
   this.userService.changeRole({
    userId:user.id,
    newRole:user.selectedRole
   }).subscribe(()=>{
    user.role=user.selectedRole;
    user.changed=false;
    this.loadStats();
    this.cdr.detectChanges();
   });
  }

  if((user.selectedStatus==='ACTIVE')!==user.active){
   this.userService.toggleStatus(user.id).subscribe(()=>{
    user.active=!user.active;
    user.changed=false;
    this.loadStats();
    this.cdr.detectChanges();
   });
  }

 }

 /* ───────── DELETE ───────── */

 confirmDelete(user:any){
  this.removeConfirmId=user.id;
  this.removeConfirmName=user.fullname;
 }

 cancelRemove(){
  this.removeConfirmId=null;
 }

 executeRemove(){
  if(!this.removeConfirmId) return;

  this.userService.deleteUser(this.removeConfirmId).subscribe(()=>{
   this.users=this.users.filter(u=>u.id!==this.removeConfirmId);
   this.filteredUsers=this.users;
   this.removeConfirmId=null;
   this.updatePagination();
   this.loadStats();
   this.cdr.detectChanges();
  });
 }

 /* ───────── PAGINATION ───────── */

 updatePagination(){
  this.totalPages=Math.ceil(this.filteredUsers.length/this.pageSize);
  const start=(this.page-1)*this.pageSize;
  const end=start+this.pageSize;
  this.pagedUsers=this.filteredUsers.slice(start,end);
 }

 nextPage(){
  if(this.page<this.totalPages){
   this.page++;
   this.updatePagination();
  }
 }

 prevPage(){
  if(this.page>1){
   this.page--;
   this.updatePagination();
  }
 }

 getRoleStyle(role: string) {
  return {
    'padding': '5px 8px',
    'border-radius': '6px',
    'border': '1px solid #ccc',
    'font-weight': 'bold',
    'color': this.getRoleColor(role),
    'background': this.getRoleBg(role)
  };
}

getRoleColor(role: string) {
  switch(role) {
    case 'ADMIN': return '#b91c1c';     // red
    case 'MANAGER': return '#7c3aed';   // purple
    case 'MEMBER': return '#2563eb';    // blue
    case 'VIEWER': return '#374151';    // gray
    default: return '#000';
  }
}

getRoleBg(role: string) {
  switch(role) {
    case 'ADMIN': return '#fee2e2';
    case 'MANAGER': return '#ede9fe';
    case 'MEMBER': return '#dbeafe';
    case 'VIEWER': return '#f3f4f6';
    default: return '#fff';
  }
}

getFilterStyle(type: string) {
  const isActive = this.roleFilter === type;

  return {
    'padding': '6px 12px',
    'border-radius': '20px',
    'border': 'none',
    'cursor': 'pointer',
    'font-weight': '500',
    'transition': '0.2s',

    /* Active style */
    'background': isActive ? this.getFilterColor(type) : '#e5e7eb',
    'color': isActive ? '#fff' : '#111'
  };
}

getFilterColor(type: string) {
  switch(type) {
    case 'ADMIN': return '#ef4444';     // red
    case 'MANAGER': return '#8b5cf6';   // purple
    case 'MEMBER': return '#3b82f6';    // blue
    case 'VIEWER': return '#6b7280';    // gray
    case 'INACTIVE': return '#111827';  // dark
    default: return '#10b981';          // ALL → green
  }
}


isFocused = false;

getSearchStyle() {
  return {
    'padding': '8px 12px',
    'border-radius': '20px',
    'border': this.isFocused ? '1px solid #3b82f6' : '1px solid #ccc',
    'outline': 'none',
    'width': '240px',
    'transition': '0.2s',
    'box-shadow': this.isFocused ? '0 0 6px rgba(59,130,246,0.4)' : 'none',
    'background': this.searchText ? '#f0f9ff' : '#fff'
  };
}

getPageBtnStyle(disabled: boolean) {
  return {
    'padding': '6px 12px',
    'border-radius': '6px',
    'border': '1px solid #ccc',
    'background': disabled ? '#e5e7eb' : '#f8fafc',
    'cursor': disabled ? 'not-allowed' : 'pointer',
    'opacity': disabled ? '0.6' : '1',
    'transition': '0.2s'
  };
}
}