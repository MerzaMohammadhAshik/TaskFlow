/* ═══════════════════════════════════════
                team.service.ts
═══════════════════════════════════════ */

import { Injectable ,inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Auth } from './services/auth';
import { UrlProviderService } from './services/url.service';
import { ChangeDetectorRef } from '@angular/core';

/* ═══════════════════════════════════════
                DTO Models
═══════════════════════════════════════ */

export interface UserDTO {

  id: number
  fullname: string
  email: string
  role: string
  createdAt: string

}

export interface TeamDTO {

  id: number
  name: string
  description: string

  manager: UserDTO
  createdAt: string

  members: UserDTO[]
  taskIds: number[]

}


export interface CreateTeamDTO {

  name: string
  description?: string
  managerId: number

}

export interface AddMemberDTO {

  userId: number

}


export interface UserIdNameDTO {

  id: number
  fullname: string

}


@Injectable({
  providedIn: 'root'
})
export class TeamService {

  urlService = inject(UrlProviderService);

  private BASE_URL =this.urlService.getUrl();
  private baseUrl = this.BASE_URL+"/api";

  constructor(private http: HttpClient, private auth: Auth) {}

  /* ═══════════════════════════════════════
                JWT Header
  ═══════════════════════════════════════ */

  private headers(): HttpHeaders {
    return new HttpHeaders({
      'Authorization': `Bearer ${this.auth.getToken()}`,
      'Content-Type': 'application/json'
    });
  }



 /* ═══════════════════════════════════════
                API Calls
═══════════════════════════════════════ */

getTeams(): Observable<TeamDTO[]> {

  return this.http.get<TeamDTO[]>(
    `${this.baseUrl}/teams`,
    { headers: this.headers() }
  );

}


getTeamDetails(teamId: number): Observable<TeamDTO> {

  return this.http.get<TeamDTO>(
    `${this.baseUrl}/teams/${teamId}`,
    { headers: this.headers() }
  );

}


createTeam(data: CreateTeamDTO): Observable<TeamDTO> {

  return this.http.post<TeamDTO>(
    `${this.baseUrl}/teams`,
    data,
    { headers: this.headers() }
  );

}


addMember(teamId: number, dto: AddMemberDTO): Observable<any> {

  return this.http.post(
    `${this.baseUrl}/teams/${teamId}/members`,
    dto,
    { headers: this.headers() }
  );

}


removeMember(teamId: number, userId: number): Observable<any> {

  return this.http.delete(
    `${this.baseUrl}/teams/${teamId}/members/${userId}`,
    { headers: this.headers() }
  );

}


getManagers(): Observable<UserIdNameDTO[]> {

  return this.http.get<UserIdNameDTO[]>(
    `${this.baseUrl}/users/MANAGER`,
    { headers: this.headers() }
  );

}
getMembers(): Observable<UserIdNameDTO[]> {

  return this.http.get<UserIdNameDTO[]>(
    `${this.baseUrl}/users/MEMBER`,
    { headers: this.headers() }
  );

}



}