// /* |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
//              analytics-task-summary.ts
// ||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||| */

// import { Component, OnInit, AfterViewInit, ViewChild, ElementRef, inject, ChangeDetectorRef, OnDestroy, ɵɵqueryRefresh } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { TaskService } from '../services/task.service';
// import { Chart, ArcElement, Tooltip, Legend, BarElement, CategoryScale, LinearScale, DoughnutController, BarController } from 'chart.js';
// import { timer, Subscription, switchMap } from 'rxjs';

// Chart.register(ArcElement, Tooltip, Legend, BarElement, CategoryScale, LinearScale, DoughnutController, BarController);

// @Component({
//   selector: 'app-analytics-task-summary',
//   standalone: true,
//   imports: [CommonModule],
//   templateUrl: './analytics-task-summary.html',
//   styleUrls: ['./analytics-task-summary.css']
// })
// export class AnalyticsTaskSummaryComponent implements OnInit, AfterViewInit, OnDestroy {
//   private cdr = inject(ChangeDetectorRef);
//   private taskService = inject(TaskService);

//   summaryData: any;
//   private viewReady = false;
//   private refreshSub!: Subscription;

//   @ViewChild('statusCanvas') statusCanvas!: ElementRef<HTMLCanvasElement>;
//   @ViewChild('priorityCanvas') priorityCanvas!: ElementRef<HTMLCanvasElement>;

//   private statusChart!: Chart;
//   private priorityChart!: Chart;

//   ngOnInit(): void {
//     // Refresh every 30 seconds (30000ms)
//     this.refreshSub = timer(0, 10).pipe(
//       switchMap(() => 
//         this.taskService.getTaskSummary())
//     ).subscribe({
//       next: (res) => {
//         this.summaryData = res;
//         this.updateCharts();
//       },
//       error: (err) => console.error('Refresh Error:', err)
//     });
//   }

//   ngAfterViewInit(): void {
//     this.viewReady = true;
//     if (this.summaryData) {
//       this.createCharts();
//     }
//   }

//   private updateCharts() {
//     setTimeout(() => {
//       if (this.viewReady) {
//         this.createCharts(); 
//         this.cdr.detectChanges();
//       }
//     }, 0);
//   }

//   createCharts() {
//     if (!this.statusCanvas || !this.priorityCanvas) return;

//     // Destroy existing instances
//     [this.statusChart, this.priorityChart].forEach(chart => chart?.destroy());

//     // 1. Status Doughnut Chart
//     this.statusChart = new Chart(this.statusCanvas.nativeElement, {
//       type: 'doughnut',
//       data: {
//         labels: ['To-Do', 'In Progress', 'Done'],
//         datasets: [{
//           data: [
//             this.summaryData.byStatus.todo,
//             this.summaryData.byStatus.inProgress,
//             this.summaryData.byStatus.done
//           ],
//           backgroundColor: ['#6366f1', '#f59e0b', '#10b981'],
//           borderWidth: 0
//         }]
//       },
//       options: { cutout: '75%', plugins: { legend: { position: 'bottom' } } }
//     });

//     // 2. Priority Bar Chart
//     this.priorityChart = new Chart(this.priorityCanvas.nativeElement, {
//       type: 'bar',
//       data: {
//         labels: ['High', 'Medium', 'Low'],
//         datasets: [{
//           label: 'Tasks',
//           data: [
//             this.summaryData.byPriority.high,
//             this.summaryData.byPriority.medium,
//             this.summaryData.byPriority.low
//           ],
//           backgroundColor: ['#ef4444', '#f59e0b', '#3b82f6'],
//           borderRadius: 12
//         }]
//       },
//       options: { 
//         plugins: { legend: { display: false } },
//         scales: { y: { beginAtZero: true, grid: { display: false } } }
//       }
//     });
//   }

//   ngOnDestroy(): void {
//     if (this.refreshSub) {
//       this.refreshSub.unsubscribe();
//     }
//   }
// }













///////////////////////////////////////////////////////////
// No Refresh
//////////////////////////////////////////////////////////

//  














/* |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
             analytics-task-summary.ts
||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*/

// import { Component, AfterViewChecked, ViewChild, ElementRef, inject, ChangeDetectorRef } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { TaskService } from '../services/task.service';
// import { Chart } from 'chart.js/auto';

// @Component({
//   selector: 'app-analytics-task-summary',
//   standalone: true,
//   imports: [CommonModule],
//   templateUrl: './analytics-task-summary.html',
//   styleUrls: ['./analytics-task-summary.css']
// })
// export class AnalyticsTaskSummaryComponent implements AfterViewChecked {

//   /* -------------------- Inject -------------------- */
//   refresh = inject(ChangeDetectorRef);

//   /* -------------------- Data -------------------- */
//   summaryData: any;

//   /* -------------------- ViewChild -------------------- */
//   @ViewChild('statusCanvas') statusCanvas!: ElementRef<HTMLCanvasElement>;
//   @ViewChild('priorityCanvas') priorityCanvas!: ElementRef<HTMLCanvasElement>;

//   /* -------------------- Charts -------------------- */
//   private statusChart!: Chart;
//   private priorityChart!: Chart;

//   private chartsInitialized = false;
//   private refreshedOnce = false;

//   constructor(private taskService: TaskService) {

//     this.taskService.getTaskSummary().subscribe({
//       next: (res) => {
//         this.summaryData = res;

//         // Refresh UI only once
//         // Inside your method
// setTimeout(() => {
//   if (!this.refreshedOnce) {
//     this.refreshedOnce = true;
//     this.refresh.detectChanges();
//   }
// }, 2000); // 2000ms = 2 seconds
//       },
//       error: (err) => console.error(err)
//     });

//   }

//   /* -------------------- Lifecycle -------------------- */
//   ngAfterViewChecked(): void {

//     if (
//       this.statusCanvas &&
//       this.priorityCanvas &&
//       this.summaryData &&
//       !this.chartsInitialized
//     ) {
//       this.chartsInitialized = true;
//       this.createCharts();
//     }

//   }

//   /* -------------------- Charts Creation -------------------- */
//   private createCharts(): void {

//     this.statusChart = new Chart(this.statusCanvas.nativeElement, {
//       type: 'doughnut',
//       data: {
//         labels: ['To-Do', 'In Progress', 'Done'],
//         datasets: [{
//           data: [
//             this.summaryData.byStatus.todo,
//             this.summaryData.byStatus.inProgress,
//             this.summaryData.byStatus.done
//           ],
//           backgroundColor: ['#2F80ED', '#F2994A', '#27AE60']
//         }]
//       },
//       options: { cutout: '70%' }
//     });

//     this.priorityChart = new Chart(this.priorityCanvas.nativeElement, {
//       type: 'bar',
//       data: {
//         labels: ['HIGH', 'MEDIUM', 'LOW'],
//         datasets: [{
//           data: [
//             this.summaryData.byPriority.high,
//             this.summaryData.byPriority.medium,
//             this.summaryData.byPriority.low
//           ],
//           backgroundColor: ['#EB5757', '#F2994A', '#27AE60'],
//           borderRadius: 8
//         }]
//       },
//       options: {
//         responsive: true,
//         plugins: { legend: { display: false } }
//       }
//     });

//   }

// }



//////////////////////////////////////////////////////////////////////
// exactly 5 times at a 2-second interval
////////////////////////////////////////////////////////////////////////


import { Component, OnInit, AfterViewInit, ViewChild, ElementRef, inject, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TaskService } from '../services/task.service';
import { Chart, ArcElement, Tooltip, Legend, BarElement, CategoryScale, LinearScale, DoughnutController, BarController } from 'chart.js';
import { timer, Subscription, switchMap, take } from 'rxjs';

Chart.register(ArcElement, Tooltip, Legend, BarElement, CategoryScale, LinearScale, DoughnutController, BarController);

@Component({
  selector: 'app-analytics-task-summary',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './analytics-task-summary.html',
  styleUrls: ['./analytics-task-summary.css']
})
export class AnalyticsTaskSummaryComponent implements OnInit, AfterViewInit, OnDestroy {
  private cdr = inject(ChangeDetectorRef);
  private taskService = inject(TaskService);

  summaryData: any;
  private viewReady = false;
  private refreshSub!: Subscription;
  private refreshedCount = 0; // Track refresh cycles

  @ViewChild('statusCanvas') statusCanvas!: ElementRef<HTMLCanvasElement>;
  @ViewChild('priorityCanvas') priorityCanvas!: ElementRef<HTMLCanvasElement>;

  private statusChart!: Chart;
  private priorityChart!: Chart;

  ngOnInit(): void {
    // timer(initialDelay, period)
    // take(5) ensures it runs 5 times then automatically unsubscribes
    this.refreshSub = timer(0, 2000).pipe(
      take(2), 
      switchMap(() => this.taskService.getTaskSummary())
    ).subscribe({
      next: (res) => {
        this.summaryData = res;
        this.refreshedCount++;
        console.log(`Refresh ${this.refreshedCount} of 5 completed.`);
        this.updateCharts();
      },
      error: (err) => console.error('Refresh Error:', err),
      complete: () => console.log('Sequence completed: Refreshed 5 times.')
    });
  }

  ngAfterViewInit(): void {
    this.viewReady = true;
    if (this.summaryData) {
      this.createCharts();
    }
  }

  private updateCharts() {
    // Using a 0ms delay to push to the next Macrotask, ensuring NG0100 is avoided
    setTimeout(() => {
      if (this.viewReady) {
        this.createCharts(); 
        this.cdr.detectChanges();
      }
    }, 0);
  }

  createCharts() {
    if (!this.statusCanvas || !this.priorityCanvas) return;

    // Destroy existing instances to prevent memory leaks and hover glitches
    [this.statusChart, this.priorityChart].forEach(chart => chart?.destroy());

    this.statusChart = new Chart(this.statusCanvas.nativeElement, {
      type: 'doughnut',
      data: {
        labels: ['To-Do', 'In Progress', 'Done'],
        datasets: [{
          data: [
            this.summaryData.byStatus.todo,
            this.summaryData.byStatus.inProgress,
            this.summaryData.byStatus.done
          ],
          backgroundColor: ['#6366f1', '#f59e0b', '#10b981'],
          borderWidth: 0
        }]
      },
      options: { cutout: '75%', plugins: { legend: { position: 'bottom' } } }
    });

    this.priorityChart = new Chart(this.priorityCanvas.nativeElement, {
      type: 'bar',
      data: {
        labels: ['High', 'Medium', 'Low'],
        datasets: [{
          label: 'Tasks',
          data: [
            this.summaryData.byPriority.high,
            this.summaryData.byPriority.medium,
            this.summaryData.byPriority.low
          ],
          backgroundColor: ['#ef4444', '#f59e0b', '#3b82f6'],
          borderRadius: 12
        }]
      },
      options: { 
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true, grid: { display: false } } }
      }
    });
  }

  ngOnDestroy(): void {
    if (this.refreshSub) {
      this.refreshSub.unsubscribe();
    }
  }
}