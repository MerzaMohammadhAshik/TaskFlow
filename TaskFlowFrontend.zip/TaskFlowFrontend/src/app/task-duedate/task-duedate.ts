/* ═══════════════════════════════════════
            task-card.ts
═══════════════════════════════════════ */

import { Component, Input,Output, OnInit, OnDestroy ,EventEmitter} from '@angular/core';
import { CommonModule } from '@angular/common';
import { TaskDueDatePipe } from '../pipes/task-due-date.pipe';

@Component({
  selector: 'app-task-duedate',
  standalone: true,
  imports: [CommonModule,  TaskDueDatePipe], // Import here
  templateUrl: './task-duedate.html',
  styleUrls: ['./task-duedate.css']
})
export class TaskDuedateComponent {
  @Input() tasks!: any[];
// Create the emitter to send data to the dashboard
  @Output() taskClicked = new EventEmitter<any>();

  onCardClick(task: any) {
    this.taskClicked.emit(task);
  }
}