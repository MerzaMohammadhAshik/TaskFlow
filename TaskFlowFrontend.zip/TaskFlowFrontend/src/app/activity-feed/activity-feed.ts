/* ═══════════════════════════════════════
            activity-feed.ts
═══════════════════════════════════════ */

import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TaskService,ActivityLog } from '../services/task.service';
import { ChangeDetectorRef } from '@angular/core';

@Component({
  selector: 'app-activity-feed',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './activity-feed.html',
  styleUrls: ['./activity-feed.css']
})
export class ActivityFeedComponent implements OnInit {
  
  activityLogs: ActivityLog[] = [];
  isLoading = false;
  private refreshChange = inject(ChangeDetectorRef);

  constructor(private service: TaskService) {}

  ngOnInit(): void {
    this.loadActivity();
  }

  // ── Load activity logs from the service ──
  loadActivity(): void {
    this.isLoading = true;
    this.service.getActivity().subscribe({
      next: logs => {
        this.activityLogs = logs;
        this.isLoading = false;
        this.refreshChange.detectChanges();
      },
      error: err => {
        console.error('Failed to fetch activity logs', err);
        this.isLoading = false;
        this.refreshChange.detectChanges();
      }
    });
  }

  // ── Refresh feed manually ──
  refresh(): void {
    this.loadActivity();
    setTimeout(() => {
      this.refreshChange.detectChanges();
    }, 1500);
  }

  // ── Map action codes to icons ──
  actionIcon(actionCode: string): string {
    switch (actionCode) {
      case 'TASK_CREATED': return '➕';
      case 'TASK_UPDATED': return '✏️';
      case 'TASK_DELETED': return '🗑️';
      case 'TASK_ASSIGNED': return '👤';
      default: return 'ℹ️';
    }
  }

  // ── Map action codes to border classes ──
  actionClass(actionCode: string): string {
    switch (actionCode) {
      case 'TASK_CREATED': return 'border-success';
      case 'TASK_UPDATED': return 'border-warning';
      case 'TASK_DELETED': return 'border-danger';
      case 'TASK_ASSIGNED': return 'border-info';
      default: return 'border-secondary';
    }
  }

  // ── Compute relative time string ──
  relativeTime(timestamp: string): string {
    const diff = Date.now() - new Date(timestamp).getTime();

    if (diff < 60_000) return 'Just now';
    if (diff < 3_600_000) return `${Math.floor(diff / 60_000)} minutes ago`;
    if (diff < 86_400_000) return `${Math.floor(diff / 3_600_000)} hours ago`;
    return `${Math.floor(diff / 86_400_000)} days ago`;
  }
}