/* ═══════════════════════════════════════
        profile-settings.ts
═══════════════════════════════════════ */

import { Component, inject, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';

import { Auth } from '../../services/auth';
import { SettingsService } from '../../services/settings.service';

@Component({
  selector: 'app-profile-settings',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  templateUrl: './profile-settings.html',
  styleUrl: './profile-settings.css'
})
export class ProfileSettingsComponent implements OnInit {

  // ── Inject ───────────────────────────
  fb = inject(FormBuilder);
  auth = inject(Auth);
  settingsService = inject(SettingsService);
  cdr = inject(ChangeDetectorRef);

  user: any;
  preferences: any = {};
  loading = false;

  // ── Form ─────────────────────────────
  profileForm = this.fb.group({
    fullname: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    avatarColour: ['#2563EB'],
    bio: ['', [Validators.maxLength(200)]],
    password: ['']
  });

  // ── Init ─────────────────────────────
  ngOnInit() {

    // ✅ Load user
    this.user = this.auth.getUser();

    if (this.user) {
      this.profileForm.patchValue({
        fullname: this.user.fullname,
        email: this.user.email
      });
    }

    // ✅ Load preferences
    this.settingsService.getPreferences().subscribe({
      next: (res) => {
        this.preferences = res;

        this.profileForm.patchValue({
          avatarColour: res.avatarColour || '#2563EB',
          bio: res.bio || ''
        });

        // 🔄 Trigger UI update safely
        this.cdr.detectChanges();
      },
      error: (err) => console.error(err)
    });

    // ✅ Live avatar update
    this.profileForm.get('avatarColour')?.valueChanges.subscribe(() => {
      this.cdr.detectChanges(); // safe UI refresh
    });
  }

  // ── Avatar Initial ───────────────────
  get initial() {
    return this.profileForm.get('fullname')?.value?.charAt(0)?.toUpperCase() || 'U';
  }

  // ── Save Profile ─────────────────────
  saveProfile() {

    if (this.profileForm.invalid) return;

    const formValue = this.profileForm.value;

    // 🔒 Email change → password required
    if (formValue.email !== this.user.email && !formValue.password) {
      alert('Password required to change email');
      return;
    }

    const payload = {
      fullname: formValue.fullname,
      email: formValue.email,
      avatarColour: formValue.avatarColour,
      bio: formValue.bio,
      password: formValue.password
    };

    this.loading = true;

    this.settingsService.updateProfile(payload).subscribe({
      next: (res) => {

        // ✅ Update localStorage user
        this.auth.saveUser(res);

        // ✅ Sync local state (VERY IMPORTANT)
        this.preferences.avatarColour = formValue.avatarColour;
        this.preferences.bio = formValue.bio;

        // ✅ Re-patch form to ensure UI sync
        this.profileForm.patchValue({
          avatarColour: formValue.avatarColour,
          bio: formValue.bio
        });

        this.loading = false;

        // 🔄 Force UI update (important for avatar preview)
        this.cdr.detectChanges();

        alert('Profile updated successfully ✅');
      },
      error: (err) => {
        console.error(err);
        this.loading = false;
        alert(err?.error?.message || 'Update failed ❌');
      }
    });
  }

  // ── Delete Account ───────────────────
  confirmEmail = '';

  deleteAccount() {

    if (this.confirmEmail !== this.user.email) {
      alert('Email does not match');
      return;
    }

    if (!confirm('Are you sure to delete account?')) return;

    this.loading = true;

    this.settingsService.deleteAccount().subscribe({
      next: () => {
        this.loading = false;

        this.auth.logout();
        location.href = '/register';
      },
      error: (err) => {
        console.error(err);
        this.loading = false;
        alert(err?.error?.message || 'Delete failed ❌');
      }
    });
  }
}