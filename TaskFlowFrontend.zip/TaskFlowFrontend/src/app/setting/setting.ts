/* ═══════════════════════════════════════
            setting.ts
═══════════════════════════════════════ */

import {
  Component,
  inject,
  OnInit
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';

import { Auth } from '../services/auth';

import { TeamDetailsComponent } from '../team-details/team-details';
import { AdminPanelComponent } from '../admin-pannel/admin-panel.component';

import { HasRoleDirective } from '../diractive/has-role.directive';

// ✅ IMPORT THESE (REQUIRED for tabs)
import { ProfileSettingsComponent } from './profile-settings/profile-settings';
import { SecuritySettingsComponent } from './security-settings/security-settings';
import { ThemeSettingsComponent } from './theme-settings/theme-settings';
import { NotificationSettingsComponent } from './notification-settings/notification-settings';
import { TeamSettingsComponent } from './team-settings/team-settings';
import { SettingsService } from '../services/settings.service';

@Component({
  selector: 'app-setting',
  standalone: true,
  imports: [
    CommonModule,

    // ✅ Tabs
    ProfileSettingsComponent,
    SecuritySettingsComponent,
    ThemeSettingsComponent,
    NotificationSettingsComponent,
    TeamSettingsComponent,

    // Existing
    TeamDetailsComponent,
    AdminPanelComponent,
    HasRoleDirective
  ],
  templateUrl: './setting.html',
  styleUrl: './setting.css',
})
export class SettingComponent implements OnInit {

  // ── Inject Services ─────────────────────────────────────
  auth = inject(Auth);
  router = inject(Router);
  route = inject(ActivatedRoute);
    seting = inject(SettingsService);
  preferences: any = {};

  // ── UI State ────────────────────────────────────────────
  isShowTeam = false;
  isShowAdminDashboard = false;

  isNotification = false;
  notification: any = null;

  isOpenSetting = true;

  // ── Tabs ─────────────────────────────
  activeTab: 'profile' | 'security' | 'theme' | 'notifications' | 'team' = 'profile';

  // ── Lifecycle ─────────────────────────
  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      const tab = params['tab'];
      if (tab) {
        this.activeTab = tab;
      }
    });

        this.seting.getPreferences().subscribe({
      next: res => this.preferences = res,
      error: err => console.error(err)
    });
  }

  // ── Tab Switch ───────────────────────
  setTab(tab: 'profile' | 'security' | 'theme' | 'notifications' | 'team') {
    this.activeTab = tab;

    this.router.navigate([], {
      queryParams: { tab },
      queryParamsHandling: 'merge'
    });
  }

  // ── Current User ─────────────────────
  get currentUser() {
    return this.auth.getUser();
  }

  // ── Navigation ───────────────────────
  OpenSetting() {
    this.isOpenSetting = true;
    this.isShowAdminDashboard = false;
    this.isShowTeam = false;

    this.router.navigate(['/setting']);
  }

  ShowDashboard() {
    this.router.navigate(['/dashboard']);
  }

  ShowTeam() {
    this.isOpenSetting = false;
    this.isShowTeam = !this.isShowTeam;
    this.isShowAdminDashboard = false;
  }

  ShowAdminDashboard() {
    this.isOpenSetting = false;
    this.isShowAdminDashboard = !this.isShowAdminDashboard;
    this.isShowTeam = false;
  }

  // ── Auth ─────────────────────────────
  logout() {
    this.auth.logout();
    this.router.navigate(['/login']);
  }

}