/* ═══════════════════════════════════════
        theme-settings.component.ts
═══════════════════════════════════════ */

import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SettingsService } from '../../services/settings.service';

@Component({
  selector: 'app-theme-settings',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './theme-settings.html',
  styleUrl: './theme-settings.css',
})
export class ThemeSettingsComponent implements OnInit {

  settingsService = inject(SettingsService);

  selectedTheme = 'LIGHT';

  ngOnInit() {
    const saved = localStorage.getItem('taskflow_theme');
    if (saved) {
      this.selectedTheme = saved;
      this.applyTheme(saved);
    }
  }

  selectTheme(theme: string) {
    this.selectedTheme = theme;

    // ✅ Apply instantly
    this.applyTheme(theme);

    // ✅ Save local
    localStorage.setItem('taskflow_theme', theme);

    // ✅ Save to DB
    this.settingsService.updatePreferences({ theme }).subscribe();
  }

  applyTheme(theme: string) {
    const html = document.documentElement;

    if (theme === 'DARK') {
      html.setAttribute('data-theme', 'dark');
    } else if (theme === 'LIGHT') {
      html.setAttribute('data-theme', 'light');
    } else {
      // SYSTEM
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      html.setAttribute('data-theme', prefersDark ? 'dark' : 'light');
    }
  }
}