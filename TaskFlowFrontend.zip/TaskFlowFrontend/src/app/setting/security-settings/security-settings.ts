// <!-- ═══════════════════════════════════════
//         security-settings.ts
// ═══════════════════════════════════════ -->


import { Component, inject } from '@angular/core';
import { FormBuilder, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { SettingsService } from '../../services/settings.service';

@Component({
  selector: 'app-security-settings',
   imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './security-settings.html',
  styleUrl: './security-settings.css',
})
export class SecuritySettingsComponent {



  fb = inject(FormBuilder);
  settingsService = inject(SettingsService);

  loading = false;

  passwordForm = this.fb.group({
    currentPassword: ['', Validators.required],
    newPassword: ['', [Validators.required, Validators.minLength(8)]],
    confirmPassword: ['', Validators.required]
  });

changePassword() {
  if (this.passwordForm.invalid) return;
if ((this.passwordForm.value.newPassword || '') !== (this.passwordForm.value.confirmPassword || '')) {
  alert("New Password and Confirm New Password do not match ❌");
  return;
}
  // ✅ Extract and assert non-null strings
  const payload: { currentPassword: string; newPassword: string; confirmPassword: string } = {
    currentPassword: this.passwordForm.value.currentPassword || '',
    newPassword: this.passwordForm.value.newPassword || '',
    confirmPassword: this.passwordForm.value.confirmPassword || ''
  };

  this.loading = true;

  this.settingsService.changePassword(payload).subscribe({
    next: (res) => {
      alert(res.message || 'Password updated successfully ✅');
      this.passwordForm.reset();
      this.loading = false;
    },
    error: (err) => {
      console.error(err);
      alert(err?.error?.message || 'Password change failed ❌');
      this.loading = false;
    }
  });
}
}