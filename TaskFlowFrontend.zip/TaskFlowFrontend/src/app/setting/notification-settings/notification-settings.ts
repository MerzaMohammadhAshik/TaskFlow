/* ═══════════════════════════════════════
        notification-settings.component.ts
═══════════════════════════════════════ */

import { Component, inject, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { SettingsService } from '../../services/settings.service';

@Component({
  selector: 'app-notification-settings',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './notification-settings.html',
  styleUrl: './notification-settings.css',
})
export class NotificationSettingsComponent implements OnInit {

  settingsService = inject(SettingsService);
  cdr = inject(ChangeDetectorRef);

  loading = false;

  // ✅ start as null (IMPORTANT)
  prefs: any = null;

  // ── Init ─────────────────────────────
  ngOnInit() {
    this.settingsService.getPreferences().subscribe({
      next: (res) => {
        this.prefs = { ...res }; // ✅ new reference

        this.cdr.detectChanges(); // optional but safe
      },
      error: (err) => console.error(err)
    });
  }

  // ── Toggle ───────────────────────────
  toggle() {
    if (!this.prefs) return;

    this.loading = true;

    this.settingsService.updatePreferences(this.prefs).subscribe({
      next: () => {
        this.loading = false;
      },
      error: () => {
        this.loading = false;
      }
    });
  }
}