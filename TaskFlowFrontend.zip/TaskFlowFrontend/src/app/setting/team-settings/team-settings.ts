/* ===============================
          team-settings.ts
   =============================== */

import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TeamService } from '../../team.service';
import { HasRoleDirective } from '../../diractive/has-role.directive';

@Component({
  selector: 'app-team-settings',
  standalone: true,
  imports: [CommonModule, FormsModule, HasRoleDirective],
  templateUrl: './team-settings.html',
  styleUrl: './team-settings.css',
})
export class TeamSettingsComponent implements OnInit {

  teams: any[] = [];
  users: any[] = [];
  managers: any[] = [];   // ✅ separate managers

  createModal = false;

  // ✅ delete confirmation
  removeTeam: any = null;
  removeMemberData: any = null;

  newTeam = {
    name: '',
    description: '',
    managerId: null as number | null
  };

  constructor(
    private teamService: TeamService,
    private cd: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.loadTeams();
    this.loadUsers();
    this.loadManagers();   // ✅ load managers separately
  }

  /* =============================== */
  loadTeams() {

    this.teams = [];

    this.teamService.getTeams().subscribe(res => {

      res.forEach(team => {

        this.teamService.getTeamDetails(team.id).subscribe(detail => {

          const manager = detail.manager
            ? [{ ...detail.manager, role: 'MANAGER', isManager: true }]
            : [];

          const members = (detail.members || []).map((m: any) => ({
            ...m,
            role: 'MEMBER',
            isManager: false
          }));

          this.teams.push({
            ...team,
            members: [...manager, ...members],
            tasks: detail.taskIds?.length || 0,
            inviteUserId: null
          });

          this.cd.detectChanges();
        });

      });

    });
  }

  /* =============================== */
  loadUsers() {
    this.teamService.getMembers().subscribe(res => {
      this.users = res;
    });
  }

  /* =============================== */
  loadManagers() {
    this.teamService.getManagers().subscribe(res => {
      this.managers = res;   // ✅ only managers
    });
  }

  /* =============================== */
  createTeam() {

    if (!this.newTeam.name || this.newTeam.managerId === null) return;

    this.teamService.createTeam({
      name: this.newTeam.name,
      description: this.newTeam.description,
      managerId: this.newTeam.managerId!
    }).subscribe(() => {

      this.newTeam = { name: '', description: '', managerId: null };
      this.createModal = false;

      this.loadTeams();
      this.cd.detectChanges();
    });
  }

  /* =============================== */
  inviteMember(team: any) {

    if (!team.inviteUserId) return;

    this.teamService.addMember(team.id, {
      userId: team.inviteUserId
    }).subscribe(() => {

      team.inviteUserId = null;
      this.refreshTeam(team);
    });
  }

  /* =============================== */
  confirmRemove(team: any, member: any) {
    this.removeTeam = team;
    this.removeMemberData = member;
  }

  cancelRemove() {
    this.removeTeam = null;
    this.removeMemberData = null;
  }

  /* =============================== */
  executeRemove() {

    if (!this.removeTeam || !this.removeMemberData) return;

    this.teamService.removeMember(
      this.removeTeam.id,
      this.removeMemberData.id
    ).subscribe(() => {

      this.refreshTeam(this.removeTeam);
      this.cancelRemove();
      this.cd.detectChanges();
    });
  }

  /* =============================== */
  refreshTeam(team: any) {

    this.teamService.getTeamDetails(team.id).subscribe(detail => {

      const manager = detail.manager
        ? [{ ...detail.manager, role: 'MANAGER', isManager: true }]
        : [];

      const members = (detail.members || []).map((m: any) => ({
        ...m,
        role: 'MEMBER',
        isManager: false
      }));

      team.members = [...manager, ...members];
      team.tasks = detail.taskIds?.length || 0;

      this.cd.detectChanges();
    });
  }

}