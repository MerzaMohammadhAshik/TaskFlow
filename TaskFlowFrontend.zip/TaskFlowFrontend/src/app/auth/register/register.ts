/* ═══════════════════════════════════════
                register.ts
═══════════════════════════════════════ */
import { Component, inject } from '@angular/core';
import {
  FormBuilder,
  ReactiveFormsModule,
  Validators,
  AbstractControl,
  ValidationErrors
} from '@angular/forms';
import { Auth } from '../../services/auth';
import { CommonModule } from '@angular/common';
import { RouterLink, Router } from '@angular/router';
import { ChangeDetectorRef } from '@angular/core';

/* ═════════════ Custom Validator ═════════════ */
function passwordsMatch(
  group: AbstractControl
): ValidationErrors | null {
  const pw  = group.get('password')?.value;
  const cpw = group.get('confirmPassword')?.value;
  if (!pw || !cpw) return null;
  return pw === cpw
    ? null
    : { passwordMismatch: true };
}

/* ═════════════ Component ═════════════ */
@Component({
  selector:    'app-register',
  standalone:  true,
  imports:     [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './register.html',
  styleUrl:    './register.css',
})
export class Register {
  fb      = inject(FormBuilder);
  auth    = inject(Auth);
  router  = inject(Router);
  refresh = inject(ChangeDetectorRef);
  errorMsg   = '';
  successMsg = '';
  isLoading  = false;

  /* ═════════════ Form Definition ═════════════ */
  form = this.fb.group(
    {
      name:            ['', [Validators.required]],
      email:           ['', [Validators.required, Validators.email]],
      password:        ['', [Validators.required, Validators.minLength(8)]],
      confirmPassword: ['', [Validators.required]],
    },
    { validators: passwordsMatch }
  );

  /* ═════════════ Password Strength (0–4) ═════════════ */
  get passwordStrength(): number {
    const pw: string = this.form.get('password')?.value || '';
    let score = 0;
    if (pw.length >= 8)           score++;
    if (/[A-Z]/.test(pw))         score++;
    if (/[0-9]/.test(pw))         score++;
    if (/[^A-Za-z0-9]/.test(pw))  score++;
    return score;
  }

  get strengthLabel(): string {
    return ['', 'Weak', 'Fair', 'Good', 'Strong'][this.passwordStrength] || '';
  }

  get strengthClass(): string {
    return ['', 'bg-danger', 'bg-warning', 'bg-info', 'bg-success'][this.passwordStrength] || '';
  }

  /* ═════════════ Register Method ═════════════ */
  register() {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.errorMsg  = '';
    this.isLoading = true;
    const { confirmPassword, ...payload } = this.form.value as any;
    // Map Angular field → backend field
    payload.fullname = payload.name;
    delete payload.name;
    this.auth.register(payload).subscribe({
      next: () => {
        this.isLoading = false;
        this.router.navigate(['/login']);
      },
      error: (err: any) => {
        this.isLoading = false;
        this.errorMsg  =
          err.error?.message ||
          'Registration failed. Please try again.';
        // ⏳ Delay change detection
        setTimeout(() => {
          this.refresh.detectChanges();
        }, 1000);
      }
    });
  }
}