/* |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
             login.ts
||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||| */

import { Component, inject, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { Auth ,User } from '../../services/auth';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './login.html',
  styleUrl: './login.css',
})
export class Login {

  /* -------------------- Inject -------------------- */
  fb = inject(FormBuilder);
  auth = inject(Auth);
  router = inject(Router);
  refresh = inject(ChangeDetectorRef);

  /* -------------------- State -------------------- */
  errorMsg = '';
  isLoading = false;

  /* -------------------- Form -------------------- */
  login_form = this.fb.group({
    email: ['biswaprakashmandal22@gmail.com', [Validators.required, Validators.email]],
    password: ['12345678', [Validators.required]],  //   $2a$10$LT2ukQsNIe2pMpXXhCA5z.JiUu0QUHK9N9x/BMkd1ZjHtCFkOKZ3.
  });

  /* -------------------- Login -------------------- */
  login() {
    if (this.login_form.invalid) { this.login_form.markAllAsTouched(); return; }

    this.errorMsg = '';
    this.isLoading = true;

    this.auth.login(this.login_form.value).subscribe({
      next: (res: any) => {
        this.auth.saveToken(res.token);
        this.auth.saveUser({ fullname: res.fullname, email: res.email, userId: res.id ,role:res.role });
        this.router.navigate(['/dashboard']);
      },
      error: (err: any) => {
        this.isLoading = false;
        this.errorMsg = err.error?.message || 'Invalid email or password. Please try again . Try after some time .';
        setTimeout(() => { this.refresh.detectChanges(); }, 2000);
      },
    });
  }

}

// all password     :   12345678
// -- 1 Admin
// INSERT INTO users (full_name, email, password_hash, role, is_active, is_delete, created_at)
// VALUES ('Admin1', 'admin1@admin1.admin1', '$2a$10$LT2ukQsNIe2pMpXXhCA5z.JiUu0QUHK9N9x/BMkd1ZjHtCFkOKZ3.', 'ADMIN', 1, 0, NOW());

// -- 2 Managers
// INSERT INTO users (full_name, email, password_hash, role, is_active, is_delete, created_at)
// VALUES ('Manager1', 'manager1@manager1.manager1', '$2a$10$LT2ukQsNIe2pMpXXhCA5z.JiUu0QUHK9N9x/BMkd1ZjHtCFkOKZ3.', 'MANAGER', 1, 0, NOW());

// INSERT INTO users (full_name, email, password_hash, role, is_active, is_delete, created_at)
// VALUES ('Manager2', 'manager2@manager2.manager2', '$2a$10$LT2ukQsNIe2pMpXXhCA5z.JiUu0QUHK9N9x/BMkd1ZjHtCFkOKZ3.', 'MANAGER', 1, 0, NOW());

// -- 6 Members
// INSERT INTO users (full_name, email, password_hash, role, is_active, is_delete, created_at)
// VALUES ('Member1', 'member1@member1.member1', '$2a$10$LT2ukQsNIe2pMpXXhCA5z.JiUu0QUHK9N9x/BMkd1ZjHtCFkOKZ3.', 'MEMBER', 1, 0, NOW());
// INSERT INTO users (full_name, email, password_hash, role, is_active, is_delete, created_at)
// VALUES ('Member2', 'member2@member2.member2', '$2a$10$LT2ukQsNIe2pMpXXhCA5z.JiUu0QUHK9N9x/BMkd1ZjHtCFkOKZ3.', 'MEMBER', 1, 0, NOW());
// INSERT INTO users (full_name, email, password_hash, role, is_active, is_delete, created_at)
// VALUES ('Member3', 'member3@member3.member3', '$2a$10$LT2ukQsNIe2pMpXXhCA5z.JiUu0QUHK9N9x/BMkd1ZjHtCFkOKZ3.', 'MEMBER', 1, 0, NOW());
// INSERT INTO users (full_name, email, password_hash, role, is_active, is_delete, created_at)
// VALUES ('Member4', 'member4@member4.member4', '$2a$10$LT2ukQsNIe2pMpXXhCA5z.JiUu0QUHK9N9x/BMkd1ZjHtCFkOKZ3.', 'MEMBER', 1, 0, NOW());
// INSERT INTO users (full_name, email, password_hash, role, is_active, is_delete, created_at)
// VALUES ('Member5', 'member5@member5.member5', '$2a$10$LT2ukQsNIe2pMpXXhCA5z.JiUu0QUHK9N9x/BMkd1ZjHtCFkOKZ3.', 'MEMBER', 1, 0, NOW());
// INSERT INTO users (full_name, email, password_hash, role, is_active, is_delete, created_at)
// VALUES ('Member6', 'member6@member6.member6', '$2a$10$LT2ukQsNIe2pMpXXhCA5z.JiUu0QUHK9N9x/BMkd1ZjHtCFkOKZ3.', 'MEMBER', 1, 0, NOW());

// -- 6 Viewers
// INSERT INTO users (full_name, email, password_hash, role, is_active, is_delete, created_at)
// VALUES ('Viewer1', 'viewer1@viewer1.viewer1', '$2a$10$LT2ukQsNIe2pMpXXhCA5z.JiUu0QUHK9N9x/BMkd1ZjHtCFkOKZ3.', 'VIEWER', 1, 0, NOW());
// INSERT INTO users (full_name, email, password_hash, role, is_active, is_delete, created_at)
// VALUES ('Viewer2', 'viewer2@viewer2.viewer2', '$2a$10$LT2ukQsNIe2pMpXXhCA5z.JiUu0QUHK9N9x/BMkd1ZjHtCFkOKZ3.', 'VIEWER', 1, 0, NOW());
// INSERT INTO users (full_name, email, password_hash, role, is_active, is_delete, created_at)
// VALUES ('Viewer3', 'viewer3@viewer3.viewer3', '$2a$10$LT2ukQsNIe2pMpXXhCA5z.JiUu0QUHK9N9x/BMkd1ZjHtCFkOKZ3.', 'VIEWER', 1, 0, NOW());
// INSERT INTO users (full_name, email, password_hash, role, is_active, is_delete, created_at)
// VALUES ('Viewer4', 'viewer4@viewer4.viewer4', '$2a$10$LT2ukQsNIe2pMpXXhCA5z.JiUu0QUHK9N9x/BMkd1ZjHtCFkOKZ3.', 'VIEWER', 1, 0, NOW());
// INSERT INTO users (full_name, email, password_hash, role, is_active, is_delete, created_at)
// VALUES ('Viewer5', 'viewer5@viewer5.viewer5', '$2a$10$LT2ukQsNIe2pMpXXhCA5z.JiUu0QUHK9N9x/BMkd1ZjHtCFkOKZ3.', 'VIEWER', 1, 0, NOW());
// INSERT INTO users (full_name, email, password_hash, role, is_active, is_delete, created_at)
// VALUES ('Viewer6', 'viewer6@viewer6.viewer6', '$2a$10$LT2ukQsNIe2pMpXXhCA5z.JiUu0QUHK9N9x/BMkd1ZjHtCFkOKZ3.', 'VIEWER', 1, 0, NOW());