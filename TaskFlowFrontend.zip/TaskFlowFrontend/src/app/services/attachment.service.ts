import { Injectable, inject } from '@angular/core';
import {
  HttpClient,
  HttpHeaders,
  HttpResponse,
  HttpEvent,
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Auth } from './auth';

/**
 * DTO representing an attachment from the backend.
 */
export interface AttachmentListDTO {
  id: number;
  taskId: number;
  uploaderId: number;
  originalName: string;
  mimeType: string;
  fileSizeBytes: number;
  uploadedAt: string; // ISO string
}

@Injectable({ providedIn: 'root' })
export class AttachmentService {
  // Dependencies
  private http = inject(HttpClient);
  private auth = inject(Auth);

  // Base API URL (consider moving to environment.ts)
  private readonly baseUrl = 'http://localhost:8888/api';

  // ---------------------------------------------------------------------------
  // Utility: Build headers with JWT
  // ---------------------------------------------------------------------------
  private authHeaders(contentType?: string): HttpHeaders {
    const token = this.auth.getToken();
    let headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });

    if (contentType) {
      headers = headers.set('Content-Type', contentType);
    }
    return headers;
  }

  // ---------------------------------------------------------------------------
  // CRUD Operations
  // ---------------------------------------------------------------------------

  /** Get all attachments of a task */
  list(taskId: number): Observable<AttachmentListDTO[]> {
    return this.http.get<AttachmentListDTO[]>(
      `${this.baseUrl}/tasks/${taskId}/attachments`,
      { headers: this.authHeaders() }
    );
  }

  /** Upload a file (simple, no progress bar) */
  upload(taskId: number, file: File): Observable<string> {
    const form = new FormData();
    form.append('file', file, file.name);

    return this.http.post(
      `${this.baseUrl}/tasks/${taskId}/attachments`,
      form,
      {
        headers: this.authHeaders(), // Do not set Content-Type manually
        responseType: 'text',        // backend returns plain text
      }
    ) as Observable<string>;
  }

  /**
   * Upload with progress events (for drag & drop progress bar).
   * Consumers can subscribe to HttpEventType.UploadProgress.
   */
  uploadWithProgress(taskId: number, file: File): Observable<HttpEvent<any>> {
    const form = new FormData();
    form.append('file', file, file.name);

    return this.http.post<HttpEvent<any>>(
      `${this.baseUrl}/tasks/${taskId}/attachments`,
      form,
      {
        headers: this.authHeaders(), // JWT only
        observe: 'events',           // needed for progress
        reportProgress: true,        // enables progress events
      }
    );
  }

  /** Download attachment as Blob */
  download(id: number): Observable<HttpResponse<Blob>> {
    return this.http.get(`${this.baseUrl}/attachments/${id}/download`, {
      headers: this.authHeaders(),
      observe: 'response',
      responseType: 'blob',
    });
  }

  /** Delete attachment (responseType must be text to avoid JSON parse errors) */
  delete(id: number): Observable<string> {
    return this.http.delete(
      `${this.baseUrl}/attachments/${id}`,
      {
        headers: this.authHeaders(),
        responseType: 'text',
      }
    ) as Observable<string>;
  }

  // ---------------------------------------------------------------------------
  // Helpers
  // ---------------------------------------------------------------------------

  /** Extract filename from Content-Disposition header */
  extractFileName(res: HttpResponse<Blob>, fallback = 'download'): string {
    const dispo =
      res.headers.get('content-disposition') ||
      res.headers.get('Content-Disposition');

    if (!dispo) return fallback;

    const match = /filename\*=UTF-8''([^;]+)|filename="([^"]+)"/i.exec(dispo);
    if (match) {
      const encoded = match[1] || match[2];
      try {
        return decodeURIComponent(encoded.trim());
      } catch {
        return encoded.trim();
      }
    }
    return fallback;
  }

  /** Save Blob to disk */
  saveBlob(blob: Blob, filename: string) {
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    window.URL.revokeObjectURL(url);
  }
}