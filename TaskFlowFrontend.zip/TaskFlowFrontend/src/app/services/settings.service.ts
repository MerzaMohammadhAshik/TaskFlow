/* ═══════════════════════════════════════
        settings.service.ts
═══════════════════════════════════════ */

import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

import { Auth } from './auth';
import { UrlProviderService } from './url.service';

@Injectable({ providedIn: 'root' })
export class SettingsService {

  private http = inject(HttpClient);
  private auth = inject(Auth);
  private urlService = inject(UrlProviderService);

  // 🌐 Base URL from environment/service
  private BASE_URL = this.urlService.getUrl();

  // 👉 Example:
  // http://localhost:8888/api
  private API = this.BASE_URL + "/api";

  // ── JWT Headers ─────────────────────
  private headers(): HttpHeaders {
    return new HttpHeaders({
      'Authorization': `Bearer ${this.auth.getToken()}`,
      'Content-Type': 'application/json'
    });
  }

  // ────────────────────────────────────
  // 🧑‍💼 UPDATE PROFILE
  // PATCH /api/users/me/profile
  // ────────────────────────────────────
  updateProfile(payload: any): Observable<any> {
    return this.http.patch(
      `${this.API}/users/me/profile`,
      payload,
      { headers: this.headers() }
    );
  }

  // ────────────────────────────────────
  // ❌ DELETE ACCOUNT
  // DELETE /api/users/me
  // ────────────────────────────────────
  deleteAccount(): Observable<any> {
    return this.http.delete(
      `${this.API}/users/me`,
      { headers: this.headers() }
    );
  }


  ///////////////////////////////////////////////////////////////

  changePassword(payload: { currentPassword: string, newPassword: string, confirmPassword: string }) {
  return this.http.patch<{message: string}>(this.API + '/users/me/password', payload, {
    headers: this.headers()
  });
}

//////////////////////////////////////////////////


  /* ─────────────────────────────────
        Settings API Methods
───────────────────────────────── */


  getPreferences(): Observable<any> {
    return this.http.get<any>(`${this.API}/preferences`, { headers: this.headers() });
  }

  updatePreferences(payload: any): Observable<any> {
    return this.http.patch<any>(`${this.API}/preferences`, payload, { headers: this.headers() });
  }

  /* ─────────────────────────────────
        Settings API Methods
───────────────────────────────── */

// // GET preferences
// getPreferences() {
//   return this.http.get<any>(
//     `${this.API}/users/me/preferences`,
//     { headers: this.headers() }
//   );
// }

// // PATCH preferences
// updatePreferences(payload: any) {
//   return this.http.patch(
//     `${this.API}/users/me/preferences`,
//     payload,
//     { headers: this.headers() }
//   );
// }


}

