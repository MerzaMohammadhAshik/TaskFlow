/* ═══════════════════════════════════════
            comment.service.ts
═══════════════════════════════════════ */

import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Auth } from './auth';
import { UrlProviderService } from './url.service';

@Injectable({ providedIn: 'root' })
export class CommentService {
  private http = inject(HttpClient);
  private auth = inject(Auth);
  private urlService = inject(UrlProviderService);

  private BASE_URL =this.urlService.getUrl();

  private API = this.BASE_URL+"/api";
  // private API = 'http://localhost:8888/api';

  private headers(): HttpHeaders {
    return new HttpHeaders({
      'Authorization': `Bearer ${this.auth.getToken()}`,
      'Content-Type': 'application/json',
    });
  }

  getAllComments(taskId: number): Observable<any> {
    this.http
      .get<any[]>(this.API + '/tasks/' + taskId + '/comments', { headers: this.headers() })
      .subscribe(data => {
        console.table(data);
      });

    return this.http.get<any[]>(
      this.API + '/tasks/' + taskId + '/comments',
      { headers: this.headers() }
    );
  }

  sendComment(taskId: number, body: string): Observable<any> {
    const payload = { body: body };

    return this.http.post<any>(
      this.API + '/tasks/' + taskId + '/comments',
      payload,
      { headers: this.headers() }
    );
  }

  deleteComment(commentId: number) {
    return this.http.delete(
      `${this.API}/comments/${commentId}`,
      { headers: this.headers() }
    );
  }
}
