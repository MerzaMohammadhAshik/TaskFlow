/* ═══════════════════════════════════════
            user.service.ts
═══════════════════════════════════════ */

import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

import { Auth } from './auth';
import { UrlProviderService } from './url.service';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private http = inject(HttpClient);
  private auth = inject(Auth);
  private urlService = inject(UrlProviderService);

  private BASE_URL = this.urlService.getUrl();

  private API_USERS = this.BASE_URL + "/api/admin/users";
  private API_ADMIN = this.BASE_URL + "/api/admin";

  private headers(): HttpHeaders {
    return new HttpHeaders({
      'Authorization': `Bearer ${this.auth.getToken()}`,
      'Content-Type': 'application/json'
    });
  }

  /* ─────────────────────────────
        Get All Users
  ───────────────────────────── */

  getUsers(): Observable<any[]> {
    return this.http.get<any[]>(this.API_USERS, {
      headers: this.headers()
    });
  }

  /* ─────────────────────────────
        Dashboard Stats
  ───────────────────────────── */

  getStats(): Observable<any> {
    return this.http.get<any>(this.API_ADMIN + "/stats", {
      headers: this.headers()
    });
  }

  /* ─────────────────────────────
        Change Role
  ───────────────────────────── */

  changeRole(data:any): Observable<any> {
    return this.http.put(
      this.API_USERS + "/change-role",
      data,
      { headers: this.headers() }
    );
  }

  /* ─────────────────────────────
        Activate / Deactivate
  ───────────────────────────── */

  toggleStatus(id:number): Observable<any> {
    return this.http.put(
      this.API_USERS + "/toggle-status/" + id,
      {},
      { headers: this.headers() }
    );
  }

  /* ─────────────────────────────
        Delete User
  ───────────────────────────── */

  deleteUser(id:number): Observable<any> {
    return this.http.delete(
      this.API_USERS + "/" + id,
      { headers: this.headers() }
    );
  }

}