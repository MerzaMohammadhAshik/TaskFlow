/* ═══════════════════════════════════════
                url.service.ts
═══════════════════════════════════════ */


import { Injectable ,inject } from "@angular/core";

@Injectable({providedIn:"root"})
export class UrlProviderService{
    private DIFAULT_URL="http://192.168.29.16:8888";
    // private DIFAULT_URL="http://localhost:8888";
    getUrl():string{
        return this.DIFAULT_URL;
    }
}