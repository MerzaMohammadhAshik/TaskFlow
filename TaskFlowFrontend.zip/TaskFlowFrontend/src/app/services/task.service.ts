/* ═══════════════════════════════════════
            task.service.ts
═══════════════════════════════════════ */

import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UrlProviderService } from './url.service';
import { Auth } from './auth';

export interface TaskSummary {
  totalTasks: number;
  byStatus: {
    todo: number;
    inProgress: number;
    done: number;
  };
  byPriority: {
    high: number;
    medium: number;
    low: number;
  };
  completionRate: number;
  overdueCount: number;
  tasksThisWeek: number;
}

export interface ActivityLog {
  id: number;
  taskId: number | null;
  actionCode: string;
  message: string;
  createdAt: string;
}

@Injectable({ providedIn: 'root' })
export class TaskService {
  private http = inject(HttpClient);
  private auth = inject(Auth);

  private urlService = inject(UrlProviderService);

  private BASE_URL =this.urlService.getUrl();

  private API = this.BASE_URL+'/api/tasks';
  private API_FOR_USERS = this.BASE_URL+"/api/users";
  // private API = 'http://localhost:8888/api/tasks';
  // private API_FOR_USERS = 'http://localhost:8888/api/users';


  private headers(): HttpHeaders {
    return new HttpHeaders({
      'Authorization': `Bearer ${this.auth.getToken()}`,
      'Content-Type': 'application/json',
    });
  }

  getTasks(): Observable<any[]> {
    this.http.get<any[]>(this.API, { headers: this.headers() })
      .subscribe(data => {
        console.table(data);
      });

    return this.http.get<any[]>(this.API, { headers: this.headers() });
  }

  getTasksAssignToMe(): Observable<any[]> {
    this.http.get<any[]>(this.API + '/assigntome', { headers: this.headers() })
      .subscribe(data => {
        console.table(data);
      });

    return this.http.get<any[]>(this.API + '/assigntome', { headers: this.headers() });
  }

  getTaskSummary(): Observable<TaskSummary> {
    return this.http.get<TaskSummary>(
      this.API + '/summary',
      { headers: this.headers() }
    );
  }

  createTask(data: any): Observable<any> {
    return this.http.post(this.API, data, { headers: this.headers() });
  }

  getTask(id: number): Observable<any> {
    return this.http.get(`${this.API}/${id}`, { headers: this.headers() });
  }

  updateTask(id: number, data: any): Observable<any> {
    return this.http.put(`${this.API}/${id}`, data, { headers: this.headers() });
  }

  deleteTask(id: number): Observable<any> {
    return this.http.delete(`${this.API}/${id}`, { headers: this.headers() });
  }

  fetchUser(): Observable<any[]> | Observable<any> {
    return this.http.get<any[]>(
      this.API_FOR_USERS,
      { headers: this.headers() }
    );
  }

  fetchUserFullnameById(id: number): Observable<{ fullname: string }> {
    return this.http.get<{ fullname: string }>(
      this.API_FOR_USERS +'/'+id,
      { headers: this.headers() }
    );
  }

  getActivity(): Observable<ActivityLog[]> {
    return this.http.get<ActivityLog[]>(this.BASE_URL+"/api/activity",{ headers: this.headers() });
  }

}