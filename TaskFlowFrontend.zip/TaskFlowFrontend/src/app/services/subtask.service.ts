/* ═══════════════════════════════════════
            subtask.service.ts
═══════════════════════════════════════ */

import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UrlProviderService } from './url.service';
import { Auth } from './auth';

@Injectable({
  providedIn: 'root'
})
export class SubtaskService {

  private http = inject(HttpClient);
  private auth = inject(Auth);
  private urlService = inject(UrlProviderService);

  private BASE_URL = this.urlService.getUrl();
  private API = this.BASE_URL + '/api';

  /* ═══════════════════════════════════════
                JWT HEADER
  ═══════════════════════════════════════ */
  private headers(): HttpHeaders {
    return new HttpHeaders({
      'Authorization': `Bearer ${this.auth.getToken()}`,
      'Content-Type': 'application/json',
    });
  }

  /* GET */
  getSubtasks(taskId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.API}/tasks/${taskId}/subtasks`, {
      headers: this.headers()
    });
  }

  /* CREATE */
  createSubtask(taskId: number, data: any): Observable<any> {
    return this.http.post(`${this.API}/tasks/${taskId}/subtasks`, data, {
      headers: this.headers()
    });
  }

  /* TOGGLE */
  toggleSubtask(id: number): Observable<any> {
    return this.http.patch(`${this.API}/subtasks/${id}/toggle`, {}, {
      headers: this.headers()
    });
  }

  /* DELETE */
  deleteSubtask(id: number): Observable<any> {
    return this.http.delete(`${this.API}/subtasks/${id}`, {
      headers: this.headers()
    });
  }

  /* SUMMARY */
  getSummary(taskId: number): Observable<any> {
    return this.http.get(`${this.API}/tasks/${taskId}/subtasks/summary`, {
      headers: this.headers()
    });
  }
}