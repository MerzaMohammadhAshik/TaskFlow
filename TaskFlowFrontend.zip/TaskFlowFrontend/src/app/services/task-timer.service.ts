/* ═══════════════════════════════════════
        task-timer.service.ts
═══════════════════════════════════════ */

import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

import { Auth } from './auth';
import { UrlProviderService } from './url.service';

@Injectable({
  providedIn: 'root'
})
export class TaskTimerService {

  private http = inject(HttpClient);
  private auth = inject(Auth);
  private urlService = inject(UrlProviderService);

  private BASE_URL = this.urlService.getUrl();

  private headers(): HttpHeaders {
    return new HttpHeaders({
      'Authorization': `Bearer ${this.auth.getToken()}`,
      'Content-Type': 'application/json'
    });
  }

  // ================= TIMER =================

  fetchBeforeTimeOfTask(taskId:number):Observable<any>{
    return this.http.get<any>(`${this.BASE_URL}/api/tasks/${taskId}/timer/fetchBeforeTime`,
      { headers: this.headers() });
  }

  startTimer(taskId: number): Observable<any> {
    return this.http.post(
      `${this.BASE_URL}/api/tasks/${taskId}/timer/start`,
      {},
      { headers: this.headers() }
    );
  }

  stopTimer(taskId: number): Observable<any> {
    return this.http.post(
      `${this.BASE_URL}/api/tasks/${taskId}/timer/stop`,
      {},
      { headers: this.headers() }
    );
  }

  getActiveTimer(taskId: number): Observable<any> {
    return this.http.get(
      `${this.BASE_URL}/api/tasks/${taskId}/timer/active`,
      { headers: this.headers() }
    );
  }

  // ================= LOGS =================

  addManualLog(taskId: number, body: any): Observable<any> {
    return this.http.post(
      `${this.BASE_URL}/api/tasks/${taskId}/time-logs`,
      body,
      { headers: this.headers() }
    );
  }

  getLogs(taskId: number): Observable<any[]> {
    return this.http.get<any[]>(
      `${this.BASE_URL}/api/tasks/${taskId}/time-logs`,
      { headers: this.headers() }
    );
  }

  getTotal(taskId: number): Observable<any> {
    return this.http.get(
      `${this.BASE_URL}/api/tasks/${taskId}/time-logs/total`,
      { headers: this.headers() }
    );
  }

  deleteLog(id: number): Observable<any> {
    return this.http.delete(
      `${this.BASE_URL}/api/time-logs/${id}`,
      { headers: this.headers() }
    );
  }
}