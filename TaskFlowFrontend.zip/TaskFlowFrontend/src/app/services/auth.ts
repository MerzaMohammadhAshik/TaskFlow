/* ═══════════════════════════════════════
                auth.ts
═══════════════════════════════════════ */

import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UrlProviderService } from './url.service';
export interface User {
  fullname: string;
  email: string;
  userId: number;
  role: string;
}
@Injectable({ providedIn: 'root' })
export class Auth {
  private http = inject(HttpClient);
  private urlService = inject(UrlProviderService);

  private BASE_URL =this.urlService.getUrl();

  private API = this.BASE_URL+'/api/auth';
  
  private TOKEN_KEY = 'taskflow_token';
  private USER_KEY = 'taskflow_user';

  // ── API calls ──────────────────────────────────────────

  register(data: any): Observable<any> | Observable<string> {
    return this.http.post(`${this.API}/register`, data);
  }

  login(data: any): Observable<any> {
    return this.http.post(`${this.API}/login`, data);
  }

  // ── Token helpers ──────────────────────────────────────

  saveToken(token: string): void {
    localStorage.setItem(this.TOKEN_KEY, token);
  }

  getToken(): string | null {
    // alert(localStorage.getItem(this.TOKEN_KEY));
    console.log(localStorage.getItem(this.TOKEN_KEY));
    return localStorage.getItem(this.TOKEN_KEY);
  }

  saveUser(user: { fullname: string; email: string; userId: number ; role : string}): void {
    localStorage.setItem(this.USER_KEY, JSON.stringify(user));
  }

  getUser(): { fullname: string; email: string; userId: number; role : string} | null {
    const raw = localStorage.getItem(this.USER_KEY);
    return raw ? JSON.parse(raw) : null;
  }

  isLoggedIn(): boolean {
    return !!this.getToken();
  }

  logout(): void {
    localStorage.removeItem(this.TOKEN_KEY);
    localStorage.removeItem(this.USER_KEY);
  }
}