/* ═══════════════════════════════════════
            task-due-date.pipe.ts
═══════════════════════════════════════ */

import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'taskFilter',
  standalone: true
})
export class TaskDueDatePipe implements PipeTransform {
  transform(tasks: any[], type: 'OVERDUE' | 'TODAY' | 'UPCOMING' | 'DONE'): any[] {
    if (!tasks) return [];
    
    // Using your current system date: March 6, 2026
    const today = new Date().setHours(0,0,0,0);

    return tasks.filter(task => {
      const taskDate = new Date(task.dueDate).setHours(0,0,0,0);
      
      if (type === 'DONE') return task.status === 'DONE';
      if (task.status === 'DONE') return false; // Exclude done from other columns

      if (type === 'OVERDUE') return taskDate < today;
      if (type === 'TODAY') return taskDate === today;
      if (type === 'UPCOMING') return taskDate > today;
      
      return false;
    });
  }
}